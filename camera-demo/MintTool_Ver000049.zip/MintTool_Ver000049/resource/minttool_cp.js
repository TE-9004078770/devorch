
var TARGET_PATH_CP_TOMCO_TXT = "/cp/tomco.txt";

///////////////////////////////////////////////////////////////////////////////
// Get tomco.txt by String
///////////////////////////////////////////////////////////////////////////////
function GetTomcoByStr()
{
	var tomcoFilePath = CurrentDir + "\\tomco\\" + GetDateStrForFileName() + "_tomco_tmp.txt";
	var tomcoStr = "";
	var fso = new ActiveXObject("Scripting.FileSystemObject");

	if( !Connect() ) {
		mintole.error("Fail to connect");
		return "";
	}

	// Delete temporary file, if already exists
	if( fso.FileExists(tomcoFilePath) ) {
		fso.DeleteFile(tomcoFilePath);
	}

	if( FileCtl.FileRead(tomcoFilePath, TARGET_PATH_CP_TOMCO_TXT) ) {
		var file = fso.OpenTextFile(tomcoFilePath, 1); // 1:ForRead
		if( !file.AtEndOfStream ) {
			tomcoStr = file.ReadAll();
		}
		else {
			mintole.warning("Gotten tomco.txt is empty");
		}
		file.Close();
		delete file;

		fso.DeleteFile(tomcoFilePath);
	}
	else {
		mintole.error("Fail to get tomco.txt from target");
	}

	delete fso;
	Disconnect();

	return tomcoStr;
}

///////////////////////////////////////////////////////////////////////////////
// Put tomco.txt by String
///////////////////////////////////////////////////////////////////////////////
function PutTomcoByStr( tomcoStr )
{
	var modFilePath = CurrentDir + "\\tomco\\" + "tomco_mod.txt";
	var fso = new ActiveXObject("Scripting.FileSystemObject");

	if( !Connect() ) {
		mintole.error("Fail to connect");
		return false;
	}

	// Delete temporary file, if already exists
	if( fso.FileExists(modFilePath) ) {
		fso.DeleteFile(modFilePath);
	}

	var file = fso.OpenTextFile(modFilePath, 8, true); // 1:ForWrite
	file.Write(tomcoStr);
	file.Close();
	delete file;

	if( !FileCtl.FileWrite(TARGET_PATH_CP_TOMCO_TXT, modFilePath) ) {
		mintole.alert("Write Tomco File Error!");
	}

	fso.DeleteFile(modFilePath);

	delete fso;
	Disconnect();
}

///////////////////////////////////////////////////////////////////////////////
// Get tomco.txt from SET
///////////////////////////////////////////////////////////////////////////////
function GetTomcoByFile( DirectryName )
{
	var fso = new ActiveXObject("Scripting.FileSystemObject");

	if( !fso.FolderExists(DirectryName) ) {
		mintole.alert("Destination:" + DirectryName + " Not Found");
		return false;
	}
	
	if( !Connect() ) {
		mintole.error("Fail to connect");
		return false;
	}

	// If a relative path, it changes to the absolute path
	DirectryName = fso.GetAbsolutePathName(DirectryName);

	// Create a folder with the date
	var filePath = DirectryName + "\\" + GetDateStrForFileName() + "_" + GetCategoryName() + "_" + GetHeadVersion() +"_tomco.txt";

	// When "tomco.txt" exists, it is deleted
	if( fso.FileExists(filePath) ) {
		fso.DeleteFile(filePath);
	}

	if( FileCtl.FileRead(filePath, TARGET_PATH_CP_TOMCO_TXT) ) {
		mintole.alert("Get tomco.txt Success");
	}
	else {
		mintole.alert("Get Tomco File FAIL!");
	}

	delete fso;
	Disconnect();
}

///////////////////////////////////////////////////////////////////////////////
// Put tomco.txt to SET
///////////////////////////////////////////////////////////////////////////////
function PutTomcoByFile( sndTomcoPath )
{
	var fso = new ActiveXObject("Scripting.FileSystemObject");

	if( !fso.FileExists(sndTomcoPath) ) {
		mintole.alert("Sending tomco file NOT Found:" + sndTomcoPath);
		return false;
	}

	if( !Connect() ) {
		mintole.error("Fail to connect");
		return false;
	}

	if( !FileCtl.FileWrite(TARGET_PATH_CP_TOMCO_TXT, sndTomcoPath) ) {
		mintole.alert("Put tomco.txt Error!");
	}
	else {
		mintole.alert("Put tomco.txt Success. Must Reboot to reflect it.");
	}

	delete fso;
	Disconnect();
}

///////////////////////////////////////////////////////////////////////////////
// Thread Monitor Function for CP
///////////////////////////////////////////////////////////////////////////////
function GetThreadMonitorCPInfo()
{
	var addr = 0;
	var size = 0;
	var tomcoStr = GetTomcoByStr();

	var mAddr = tomcoStr.match(/tmon_addr=(\w+)/);
	if( mAddr ) {
		addr = mAddr[1];
	}

	var mSize = tomcoStr.match(/tmon_size=(\w+)/);
	if( mSize ) {
		size = mSize[1];
	}

	return {addr : addr, size : size};
}
function SetThreadMonitorCPInfoToForm()
{
	var tmonInfo = GetThreadMonitorCPInfo();

	document.getElementById("ThreadMonitor_addressNum").value = tmonInfo.addr;
	document.getElementById("ThreadMonitor_sizeNum").value = tmonInfo.size;
}
function Progress(_cb)
{
	// this.logAreaObj = document.getElementById("ThreadMonitor").appendChild(document.createElement("div"));;
	this.currNum = 0;
	this.maxNum = 0;
	this.cb = _cb;

	// this.logAreaObj.id = "ThreadMonitor_dbglog";
	
	
	//==================================================
	//	Set max num
	//==================================================
	this.setMaxNum = function(_totalNum)
	{
		this.maxNum = _totalNum;
	}
	
	
	//==================================================
	//	Update
	//==================================================
	this.update = function(_cnt)
	{
		if( !_cnt ) { this.currNum++; }
		else { this.currNum += _cnt; }
		// this.logAreaObj.innerHTML = "parsing... " + this.currNum + "/" + this.maxNum;
	}
	
	//==================================================
	//	End
	//==================================================
	this.end = function()
	{
		this.cb();
		// this.logAreaObj.parentNode.removeChild(this.logAreaObj);
	}
}
function ConvertThreadMonitorBin2Text( dstFileName, srcFilePath )
{
	var fso = new ActiveXObject('Scripting.FileSystemObject');
	if( !fso.FileExists(srcFilePath) ) {
		mintole.error("File NOT found: " + srcFilePath);
		return;
	}
	delete fso;

	var dstTmpFileName = dstFileName + "_utf16bom";
	var xhr = new ActiveXObject("Microsoft.XMLHTTP");
	xhr.open('GET', "file://" + srcFilePath, true);
	xhr.onreadystatechange = function() {
		if( xhr.readyState === 4 ) {
			var res = xhr.responseBody.toArray();
			if( res != null ) {
				var tmonParser = new ThreadMonitorParser(true, true);
				var prgs = new Progress(function() {
					// Once, output UTF-16 w/ BOM (avoid error at character corruption)
					var fso = new ActiveXObject('Scripting.FileSystemObject');
					var file = fso.OpenTextFile(dstTmpFileName, 2, true, -1);
					try {
						file.Write(tmonParser.getString(null));
					}
					catch (e) {
						mintole.error("Fail to write Thread monitor text log");
					}
					file.Close();
					delete file;
					
					// Translate UTF-16 w/ BOM -> UTF-8
					var wsh = new ActiveXObject("WScript.Shell");
					wsh.Run("cmd /c chcp.com 65001 & type \"" + dstTmpFileName + "\" > \"" + dstFileName + "\"", 0, true);
					delete wsh;

					// Delete temporary file
					fso.DeleteFile(dstTmpFileName);
					delete fso;

					mintole.info("Finished converting Thread monitor bin to text");
				});

				var arybuf = new ArrayBuffer(res.length);
				new Uint8Array(arybuf).set(res);
				tmonParser.initByData(arybuf, prgs);
			}
		}
	};
	xhr.send(null);
}
function SuspendThreadMonitorCP( sus )
{
	if (!Connect()) {
		mintole.alert("Fail to Connect()...");
		return;
	}
	AdjustCmd.DataSize = 0;	// parameter size.
	if ( sus ) {
		if( !AdjustCmd.CmdIssue(0x060B, 0x0022) ) {	// [0022] SUSPEND_THREAD_MONITOR
			mintole.error("Fail to suspend Thread monitor on CP");
		}
	}
	else {
		if( !AdjustCmd.CmdIssue(0x060B, 0x0023) ) {	// [0023] RESUME_THREAD_MONITOR
			mintole.error("Fail to resume Thread monitor on CP");
		}
	}
	Disconnect();
}
function ReadThreadMonitorCP( addr, size )
{
	// Create a folder with the date.
	var fileName = CurrentDir + "\\tmon\\" + GetDateStrForFileName();
	var filePath = fileName + "_tmon.bin";

	mintole.debug("Get Thread monitor log: " + addr + "/" + size + " -> " + filePath);

	SuspendThreadMonitorCP( true );
	if( MemDumpSaveToFileCP(filePath, parseInt(addr, 16) , parseInt(size, 16)) ) {
		mintole.alert("Get Thread monitor log Success");
		
		ConvertThreadMonitorBin2Text(fileName + "_tmon.txt", filePath);
	}
	else {
		mintole.alert("Get Thread monitor log FAIL!");
	}
	SuspendThreadMonitorCP( false );
}

///////////////////////////////////////////////////////////////////////////////
// Boottime log conversion from Bin to Text
///////////////////////////////////////////////////////////////////////////////
function ConvertBoottimeLogBin2Text( dstFilePath, srcFilePath )
{
	var fso = new ActiveXObject('Scripting.FileSystemObject');
	if( !fso.FileExists(srcFilePath) ) {
		mintole.error("File NOT found: " + srcFilePath);
		return;
	}
	delete fso;

	var xhr = new ActiveXObject("Microsoft.XMLHTTP");
	xhr.open('GET', "file://" + srcFilePath, true);
	xhr.onreadystatechange = function() {
		if( xhr.readyState === 4 ) {
			var res = xhr.responseBody.toArray();
			if( res != null ) {
				var tlogParser = new BoottimeLogParser();
				var arybuf = new ArrayBuffer(res.length);
				new Uint8Array(arybuf).set(res);
				tlogParser.initByData(arybuf);
				
				var fso = new ActiveXObject('Scripting.FileSystemObject');
				var file = fso.OpenTextFile(dstFilePath, 2, true, -2);
				try {
					file.Write(tlogParser.getString());
				}
				catch (e) {
					mintole.alert("Fail to write text tlog");
				}
				file.Close();
				delete file;
				delete fso;
			}
		}
	};
	xhr.send(null);
}

///////////////////////////////////////////////////////////////////////////////
// Snapshot debug image Function for CP
///////////////////////////////////////////////////////////////////////////////
var SSDI_HEADER_ADDR_SIZE = 8;
var SSDI_HEADER_SIZE_SIZE = 8;
var SSDI_HEADER_MAGIC_WORD_SIZE = 12;
var SSDI_HEADER_MAGIC_WORD = "SOLID_SSHOT\0";
function CalMemDumpToDec() {
	var tmp = 0;
	for( var i = 0; i < MemDump.ReadDataSize; i++ ) {
		tmp += MemDump.GetData(i) *Math.pow(0x100, i);
	}
	return tmp;
}
function IsSSDIMagicOK() {
	for( var i = 0; i < MemDump.ReadDataSize; i++ ) {
		if(MemDump.GetData(i) != SSDI_HEADER_MAGIC_WORD.charCodeAt(i)) {
			return false
		}
	}
	return true;
}
function RemoveSSDIMagic() {
	mintole.open();

	var ssdiInfo = GetSnapshotDebugImageCPInfo();
	if( ssdiInfo == null ) { return; }

	if( ssdiInfo.addr == 0 || ssdiInfo.size == 0 ) {
		mintole.info("Snapshot Debug Image is NOT available.");
		return;
	}

	if( !Connect() ) {
		mintole.error("Fail to connect");
		return;
	}

	MemDump.WriteDataSize = SSDI_HEADER_MAGIC_WORD_SIZE;
	for( var i = 0; i < SSDI_HEADER_MAGIC_WORD_SIZE; i++ ) {
		MemDump.PutData(i, 0);
	}
	if( !MemDump.WriteDataEX(ssdiInfo.addr, 0x1)) {
		mintole.error("Fail to delete Snapshot Debug Image");
	}
	
	mintole.info("Complete to delete SSDI\n");

	Disconnect();
}
function GetSnapshotDebugImageCPInfo()
{
	var addr = 0;
	var size = 0;
	var tomcoStr = GetTomcoByStr();

	if( !Connect() ) {
		mintole.error("Fail to connect");
		return null;
	}

	var m = tomcoStr.match(/snapshotdbg_addr=(\w+)/);
	if( m ) {
		addr = parseInt(m[1], 16);

		m = tomcoStr.match(/snapshotdbg_size=(\w+)/);
		if( m ) {
			size = parseInt(m[1], 16);
		}
	}
	mintole.debug("SSDI area address by tomco.txt: " + addr.toString(16) + "/size: " + size.toString(16));

	// Snapshot debug is available, then read its header
	if( addr != 0 && size != 0 ) {
		if(MemDump.ReadDataEX(addr, SSDI_HEADER_ADDR_SIZE, 0x1)) {
			var tmp_addr = CalMemDumpToDec();
			addr += SSDI_HEADER_ADDR_SIZE;
			
			if(MemDump.ReadDataEX(addr, SSDI_HEADER_SIZE_SIZE, 0x1)) {
				size = CalMemDumpToDec();
				
				addr = tmp_addr;
				
				mintole.debug("Real SSDI area address: " + addr.toString(16) + "/size: " + size.toString(16));
			
				if(MemDump.ReadDataEX(addr, SSDI_HEADER_MAGIC_WORD_SIZE, 0x1)) {
					if( !IsSSDIMagicOK() ) {
						mintole.debug("SSDI Magic word is invalid");
						addr = 0;
						size = 0;
					}
				}
			}
		}
	}
	Disconnect();

	return {addr : addr, size : size};
}
function GetSnapshotDebugImageCPToSSDIDir()
{
	// Create a folder with the date.
	var fileName = CurrentDir + "\\snapshot_debug\\" + GetDateStrForFileName();
	var filePath = fileName + "_snapshot_debug.sdmp";

	GetSnapshotDebugImageCP(filePath);
}
function GetSnapshotDebugImageCP(filePath)
{
	mintole.open();

	var ssdiInfo = GetSnapshotDebugImageCPInfo();
	if( ssdiInfo == null ) { return; }

	if( ssdiInfo.addr == 0 || ssdiInfo.size == 0 ) {
		mintole.alert("Snapshot Debug Image is NOT available.");
		return;
	}

	mintole.info("Start Dump addr: 0x" + ssdiInfo.addr.toString(16) + " / size: 0x" + ssdiInfo.size.toString(16));
	
	if (MemDumpSaveToFileCP(filePath, ssdiInfo.addr, ssdiInfo.size)) {
		mintole.info("Get Snapshot Debug Image Success");
		mintole.info("File: " + filePath);
	}
	else {
		mintole.error("Get Snapshot Debug Image FAIL!");
	}
}

/*--------------------------------------------------------------------------------
 * Switch SSDI
--------------------------------------------------------------------------------*/
function switchSSDIbyRST( enable )
{
	var tomco = GetTomcoByStr();

	if( enable ) {
		PutTomcoByStr( tomco.replace("snapshotdbg_rst_create=N", "snapshotdbg_rst_create=Y") );
		mintole.alert("enable SSDI creation by RST_REQ");
	}
	else {
		PutTomcoByStr( tomco.replace("snapshotdbg_rst_create=Y", "snapshotdbg_rst_create=N") );
		mintole.alert("disable SSDI creation by RST_REQ");
	}
}
