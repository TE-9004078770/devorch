var DispLang = "en";

window.addEventListener("load", setLangSetting);

/*================================================================================
 * Set language setting by file
================================================================================*/
function setLangSetting()
{
	DispLang = settings.get("lang");

	// ユーザ設定情報がない場合
	if( !DispLang ) {
		// ブラウザの言語設定を初期値とする
		if (window.navigator.browserLanguage == "ja") {
			DispLang = "en";
		}
		else {
			DispLang = "ja";
		}
	}

	setTexts();
}

/*================================================================================
 * Set text with set language to each element
================================================================================*/
function setTexts()
{
	var frameDocument = null;
	if( document.getElementById("main_frame") ) { frameDocument = document.getElementById("main_frame").contentWindow.document; }

	for( var id in langData ) {
		var text = langData[id][DispLang];
		var node = document.getElementById(id);
		if( !node && frameDocument ) { node = frameDocument.getElementById(id); }
		if( !text ) { continue; }
		if( !node ) { continue; }
		
		switch(node.tagName.toLowerCase()) {
		case "input":
			node.value = langData[id][DispLang];
			break;
		default:
			node.innerHTML = langData[id][DispLang];
			break;
		}
	}
}

/*================================================================================
 * Change language (toggle)
================================================================================*/
function changeLang()
{
	switch (DispLang) {
	case "ja":
		DispLang = "en";
		break;
	case "en":
		DispLang = "ja";
		break;
	default:
		DispLang = "en";
		break;
	}

	setTexts();
	saveLang();
}

/*================================================================================
 * Save language setting to file
================================================================================*/
function saveLang()
{
	settings.set("lang", DispLang);
	settings.write();
}
