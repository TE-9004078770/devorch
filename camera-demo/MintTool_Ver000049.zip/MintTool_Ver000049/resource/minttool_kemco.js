
///////////////////////////////////////////////////////////////////////////////
// CA の存在チェック
///////////////////////////////////////////////////////////////////////////////
function IsGetCaVer()
{
	if (! Connect()) {
		return false;
	}

	var ret = 0;

	//------------------------------------------------------------------------
	// boo ver取得
	//------------------------------------------------------------------------
	// BOO ver vXX.**.**.**
	AdjustCmd.DataSize = 8;							// parameter size
	AdjustCmd.SetParam32(0, 0x003000f4);			// DataOffset
	AdjustCmd.SetParam32(1, 0x00000001);			// DataSize
	ret |= !AdjustCmd.CmdIssue( 0x0421, 0x00FE);	// RAM READ

	// BOO ver v**.XX.**.**
	AdjustCmd.DataSize = 8;							// parameter size
	AdjustCmd.SetParam32(0, 0x003000f5);			// DataOffset
	AdjustCmd.SetParam32(1, 0x00000001);			// DataSize
	ret |= !AdjustCmd.CmdIssue( 0x0421, 0x00FE);	// RAM READ

	// BOO ver v**.**.XX.**
	AdjustCmd.DataSize = 8;							// parameter size
	AdjustCmd.SetParam32(0, 0x003000f6);			// DataOffset
	AdjustCmd.SetParam32(1, 0x00000001);			// DataSize
	ret |= !AdjustCmd.CmdIssue( 0x0421, 0x00FE);	// RAM READ

	// BOO ver v**.**.**.XX
	AdjustCmd.DataSize = 8;							// parameter size
	AdjustCmd.SetParam32(0, 0x003000f7);			// DataOffset
	AdjustCmd.SetParam32(1, 0x00000001);			// DataSize
	ret |= !AdjustCmd.CmdIssue( 0x0421, 0x00FE);	// RAM READ

	Disconnect();

	if (ret) {
		// Error: 「boo ver」のログ取得に失敗
		return false;
	}

	// エラーが発生しなかった時点で「boo ver」の取得に成功したと見なす
	return true;
}

///////////////////////////////////////////////////////////////////////////////
// Get kemco.txt to SET Function
///////////////////////////////////////////////////////////////////////////////
function kemGetKemco(
	DirectryName
)
{
	if (! WshFs.FolderExists(DirectryName)) {
		alert("Destination:" + DirectryName + " Not Found");
		return false;
	}

	// If a relative path, it changes to the absolute path.
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	DirectryName = fso.GetAbsolutePathName(DirectryName);
	delete fso;

	if (! Connect()) {
		return false;
	}

	// Create a folder with the date.
	var now = new Date();
	DirectryName = DirectryName + "\\" + GetDateStrForFileName();

	var kemcoFilePath = DirectryName + "_" + GetCategoryName() + "_" + GetHeadVersion() +"_kemco.txt";

	// When "kemco.txt" exists, it is deleted.
	if (WshFs.FileExists(kemcoFilePath)) {
		WshFs.DeleteFile(kemcoFilePath);
	}

	if (FileCtl.FileRead(kemcoFilePath, "/setting/kemco.txt")) {
	   alert("Get kemco.txt Success");
	}
	else {
	   alert("Get Kemco File FAIL !");
	}

	delete now;
	Disconnect();
}

///////////////////////////////////////////////////////////////////////////////
// Put kemco.txt in SET Function
///////////////////////////////////////////////////////////////////////////////
function kemPutKemco(
	sndKemcoPath
)
{
	if (! WshFs.FileExists(sndKemcoPath)) {
		alert("Input:" + sndKemcoPath + " Not Found");
		return false;
	}

	if (! Connect()) {
		return false;
	}

	if (! FileCtl.FileWrite("/setting/kemco.txt", sndKemcoPath)) {
		alert("Write Kemco File Error !");
	}

	alert("Put kemco.txt Success. Must Reboot.\n*SET corresponding with SSB must re-create SSBI.");

	Disconnect();
}

///////////////////////////////////////////////////////////////////////////////
// 退避ログ機能
///////////////////////////////////////////////////////////////////////////////
function kemEscapeLog(
	getEscape	 // 退避ログ取得 (ON:取得/ OFF:取得しない)
)
{
	var escape = 0x01;

	if (getEscape == "ON") {
		escape = 0x01;
	}
	else {
		escape = 0x00;
	}

	if (! UpdateBackupData8(0x510015, escape, 0)) {
		return false;
	}
	if (! UpdateBackupData8CP(0x510015, escape, 0)) {
		return false;
	}

	alert("Change Debug Mode To EscapeLog. Must Reboot.");

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// デッドロック監視機能
// 
// 機能：バックアップ値にデッドロック監視モードを設定
// 処理：バックアップ値更新関数(UpdateBackupData8)を使用して更新している
//       更新時のUSB接続/バックアップ値更新(read,write,save)/USB切断は
//       エラー処理も含めてバックアップ値更新関数内で行っている
///////////////////////////////////////////////////////////////////////////////
function kemDeadlockMonitoring(
	SelectMode		// デッドロック監視モード
					//   MONITORING_OFF        : 監視無効／--　（ICE使用者）
					//   MONITORING_ON_TESTING : 監視有効／手動リブート　（Testing用）
					//   MONITORING_ON_MASS_PRO  : 監視有効／自動リブート　（量産向け）
)
{

	if (SelectMode == "MONITORING_OFF") {
		// for Darwin
		if (! UpdateBackupDataOffsetCP(0x01850003, 0x0031, 1, 1)) {
			return false;
		}

		if (! UpdateBackupDataOffsetCP(0x01850003, 0x0032, 1, 1)) {
			return false;
		}

		if (! UpdateBackupData8       (0x00510038, 0x0C,   0 ))		return false;

		alert("Set Monitoring  off Success \nTo reflect the setting, you must reboot.");
		return true;
	}

	if ( SelectMode == "MONITORING_ON_TESTING" ){
		if (! UpdateBackupDataOffsetCP(0x01850003, 0x0031, 1, 0))	return false;
		if (! UpdateBackupDataOffsetCP(0x01850003, 0x0032, 1, 1))	return false;
		if (! UpdateBackupData8       (0x00510038, 0x1F,   0 ))		return false;

		alert("Set Monitoring  on (for Testing) Success \nTo reflect the setting, you must reboot.");
		return true;
	}

	if ( SelectMode == "MONITORING_ON_MASS_PRO" ){
		if (! UpdateBackupDataOffsetCP(0x01850003, 0x0031, 1, 0))	return false;
		if (! UpdateBackupDataOffsetCP(0x01850003, 0x0032, 1, 0))	return false;
		if (! UpdateBackupData8       (0x00510038, 0x0D,   0 ))		return false;

		alert( "Set Monitoring  on (for Mass-Production) Success \nTo reflect the setting, you must reboot." );
		return true;
	}

	return false;
}

///////////////////////////////////////////////////////////////////////////////
// 緊急再起動機能
///////////////////////////////////////////////////////////////////////////////
function kemUrgentReboot(
	rebootMode	// 再起動モード (ON:再起動する/ OFF:再起動しない)
)
{
	if(isDisableSenserIF(true)){
		return false;
	}

	// Read kemco.txt
	var kemco = kemReadKemcoFile();
	if (kemco == "") {
		return false;
	}
	// Read kemco.txt
	var tomco = GetTomcoByStr();
	if (tomco == "") {
		return false;
	}

	var kemcoReplaceStr = kemco;
	var tomcoReplaseStr = tomco;

	// Rewrite kemco.txt & tomco.txt
	if (rebootMode == "OFF") {
		kemcoReplaceStr = kemcoReplaceStr.replace("exception.reboot=1", "exception.reboot=0");
		//kemcoReplaceStr = kemcoReplaceStr.replace("wdt.mode=1", "wdt.mode=0");
		tomcoReplaseStr = tomcoReplaseStr.replace("wdt_on=1", "wdt_on=0");
	}
	else {
		kemcoReplaceStr = kemcoReplaceStr.replace("exception.reboot=0", "exception.reboot=1");
		//kemcoReplaceStr = kemcoReplaceStr.replace("wdt.mode=0", "wdt.mode=1");
		tomcoReplaseStr = tomcoReplaseStr.replace("wdt_on=0", "wdt_on=1");
	}

	if (kemWriteKemcoFile(kemcoReplaceStr) == false) {
		return false;
	}
	if (PutTomcoByStr(tomcoReplaseStr) == false) {
		return false;
	}

	alert("Change Debug Mode To Reboot. Must Reboot.\n*SET corresponding with SSB must re-create SSBI.");

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// 治具からのUART出力
///////////////////////////////////////////////////////////////////////////////
function kemUARTout(
	UARTout		// UART出力
				//   (MP: MPを出力する(UART0をMPコンソールに設定する)/
				//    CP: CPを出力する(UART0をCPコンソールに設定する)/
				//    MP+CP: MP/CP両方を出力する(検端からMP/CPコンソールを出力する)/
				//    OFF: 出力しない(UART0をアクセサリ通信に設定する))
)
{
	if(isDisableSenserIF(true)){
		return false;
	}

	// Read kemco.txt
	var kemco = kemReadKemcoFile();
	if (kemco == "") {
		return false;
	}
	// Read tomco.txt
	var tomco = GetTomcoByStr();
	if (tomco == "") {
		return false;
	}

	var kemcoReplaceStr = kemco;
	var tomcoReplaseStr = tomco;
	var ulogioTermMode = -1;	// -1: get value/ 0: Disable/ 1: UART/ 2: USB/ 4: Ether

	// MP ON
	if (UARTout == "MP" || UARTout == "MP+CP") {
		if (! UpdateBackupData8(0x510003, 0x06, 0)) {
			return false;
		}
		kemcoReplaceStr = kemcoReplaceStr.replace("console=ttynull","console=ttyAMA0,460800n8");
		ulogioTermMode = 1;
	}

	// MP OFF
	if (UARTout == "CP" || UARTout == "OFF") {
		if (! UpdateBackupData8(0x510003, 0x00, 0)) {
			return false;
		}
		kemcoReplaceStr = kemcoReplaceStr.replace("console=ttyAMA0,460800n8","console=ttynull");
		ulogioTermMode = 0;
	}

	// CP ON
	if (UARTout == "CP" || UARTout == "MP+CP") {
		if (! UpdateBackupData8CP(0x510003, 0x06, 0)) {
			return false;
		}
		tomcoReplaseStr = tomcoReplaseStr.replace("console_enable=N","console_enable=Y");
	}

	// CP OFF
	if (UARTout == "MP" || UARTout == "OFF") {
		if (! UpdateBackupData8CP(0x510003, 0x00, 0)) {
			return false;
		}
		tomcoReplaseStr = tomcoReplaseStr.replace("console_enable=Y","console_enable=N");
	}

	// UM ON/OFF
	if (UARTout == "OFF") {
		if (! UpdateBackupData8CP(0x760000, 0x00, 0)) {
			return false;	
		}
		if (! UpdateBackupData8CP(0x5D0007, 0x00, 0)) {
			return false;	
		}
	}else {
		if (! UpdateBackupData8CP(0x760000, 0x01, 0)) {
			return false;	
		}
		if (! UpdateBackupData8CP(0x5D0007, 0x01, 0)) {
			return false;	
		}
	}

	if (kemWriteKemcoFile(kemcoReplaceStr) == false) {
		return false;
	}

	if (PutTomcoByStr(tomcoReplaseStr) == false) {
		return false;
	}

	if (ChangeUlogioTermMode(ulogioTermMode) == false) {
		return false;
	}

	alert("Change UART Output By Jig. Must Reboot.\n*SET corresponding with SSB must re-create SSBI.");

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// HotBoot
///////////////////////////////////////////////////////////////////////////////
function kemHotBootMode(
	hotModeVal		// HotBoot (ON: 設定する/ OFF: 解除する)
)
{
	var hotmode = 0x01;

	if (hotModeVal == "ON") {
		hotmode = 0x00;
	}
	else {
		hotmode = 0x01;
	}

	if (! UpdateBackupData8(0x00920020, hotmode, 0)) {
		return false;
	}

	alert("Change Hot Boot Mode. Must Reboot.");

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// Kemco読込
///////////////////////////////////////////////////////////////////////////////
function kemReadKemcoFile()
{
	var kemcoFilePath = CurrentDir + "\\kemco\\" + GetDateStrForFileName() + "_kemco_tmp.txt";
	var kemcoStr = "";

	if (! Connect()) {
		return false;
	}

	// Kemcoファイルが存在する場合は削除する
	if (WshFs.FileExists(kemcoFilePath)) {
		WshFs.DeleteFile(kemcoFilePath);
	}

	if (FileCtl.FileRead(kemcoFilePath, "/setting/kemco.txt")) {
		var vf = WshFs.OpenTextFile(kemcoFilePath, 1); // 1:ForRead
		kemcoStr = vf.ReadAll();
		vf.Close();
		WshFs.DeleteFile(kemcoFilePath);
	}

	Disconnect();

	return kemcoStr;
}

///////////////////////////////////////////////////////////////////////////////
// Kemco書き込み
///////////////////////////////////////////////////////////////////////////////
function kemWriteKemcoFile(
	kemcoStr
)
{
	var modFilePath = CurrentDir + "\\Kemco\\" + "kemco_mod.txt";

	if (! Connect()) {
		return false;
	}

	// kemco_modファイルが存在する場合は削除する
	if (WshFs.FileExists(modFilePath)) {
		WshFs.DeleteFile(modFilePath);
	}

	vf = WshFs.OpenTextFile(modFilePath, 8, true); // 1:ForWrite
	vf.Write(kemcoStr);
	vf.Close();

	if (! FileCtl.FileWrite("/setting/kemco.txt", modFilePath)) {
		alert("Write Kemco File Error !");
	}

	WshFs.DeleteFile(modFilePath);
	Disconnect();
}

///////////////////////////////////////////////////////////////////////////////
// Heap Profile Function
///////////////////////////////////////////////////////////////////////////////
function kemReadHeapProfile()
{
	if(isDisableSenserIF(true)){
		return false;
	}

	var kemco = kemReadKemcoFile();
	if (kemco == "") {
		return false;
	}

	var strRecCnt = "heap_profile\.records=";
	var posRecCnt = kemco.indexOf(strRecCnt);
	if (posRecCnt == -1) {
		alert("ERR : heap_profile.records");
		return false;
	}
	posRecCnt += strRecCnt.length;

	var recCnt = "";
	var resRecCnt;
	for (i = 0; i < 5; i++) {		// Max：4桁
		resRecCnt = kemco.charAt(posRecCnt + i);
		if ((resRecCnt == "\n") || (resRecCnt == " ")) {	// 改行 or 空白
			break;
		}
		recCnt += resRecCnt;
	}
	document.form_heapprofile.HeapProfile_count.value = recCnt;

	alert("Success");

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
function kemWriteHeapProfile()
{
	if(isDisableSenserIF(true)){
		return false;
	}

	var kemco = kemReadKemcoFile();
	if (kemco == "") {
		return false;
	}

	var strRecCnt = "heap_profile\.records=";
	var posRecCnt = kemco.indexOf(strRecCnt);
	if (posRecCnt == -1) {
		alert("ERR : heap_profile.records");
		return false;
	}
	posRecCnt += strRecCnt.length;

	var recCnt = "";
	var resRecCnt;
	for (i = 0; i < 5; i++) {		// Max：4桁
		resRecCnt = kemco.charAt(posRecCnt + i);
		if ((resRecCnt == "\n") || (resRecCnt == " ")) {	// 改行 or 空白
			break;
		}
		recCnt += resRecCnt;
	}

	// kemco 書き換え
	var setRecCount = document.form_heapprofile.HeapProfile_count.value;
	//alert("heap_profile.records = " + recCnt + " -> " + setRecCount);

	var kemcoReplaceStr = kemco.replace("heap_profile\.records=" + recCnt, "heap_profile\.records=" + setRecCount);
	kemWriteKemcoFile(kemcoReplaceStr);

	alert("Success\n*SET corresponding with SSB must re-create SSBI.");

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// Get nflasha5 to Set Function 
///////////////////////////////////////////////////////////////////////////////
function kemGetNflasha5(
   DirectryName
)
{
	// ディレクトリーがなければディレクトリーがない旨を通知
	if (! WshFs.FolderExists(DirectryName)) {
		mintole.alert("Destination:" + DirectryName + " Not Found");
		return false;
	}

	// 相対Pathならば絶対Pathに変更
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	DirectryName = fso.GetAbsolutePathName(DirectryName);
	delete fso

	// Firmバージョン
	var prm = "*";
	if (!setVer.readFirmwareVer()) {
		return false;  //取得失敗時
	}
	else {
		prm = setVer.getFirmwareVer();
	}

	// nflasha5の保存時のファイル名を生成
   	var now = new Date();
	var ssbFileName =
			DirectryName + "\\"
			+ prm
			+ "_" + GetCategoryName()	  //ひとまず入れているが不要なら削除
			+ "_" + "nflasha5"
			+ "_" + GetDateStrForFileName();
	delete now;

	if( !Connect() ) {
		return false;
	}
	if (FileCtl.FileRead(ssbFileName, "/dev/nflasha5")) {
		mintole.alert("Get nflasha5 Success.");
	}
	else {
		AdjustCmd.DataSize = 0;
		/* READ_SSBI */
		if (AdjustCmd.CmdIssue_Ddm(0x0601, 0x0032, 0, "", ssbFileName)) {
			mintole.alert("Get nflasha5 Success.");
		}
		else {
			mintole.alert("Get nflasha5 File FAIL !");
		}
	}
	Disconnect();
}

///////////////////////////////////////////////////////////////////////////////
// SSBIを有効にする
///////////////////////////////////////////////////////////////////////////////
function comExecSnapShotBootOnF()
{
	var sndSsbPath ="/dev/nflasha5";
	var invlFile = CurrentDir + "\\config\\" + "invl";

	if (! WshFs.FileExists(invlFile)) {
		alert("invl is not exist!　Please set invl file to config folder.(Mint tool included)");
		return false;
	}

	if (! Connect()) {
		return false;
	}

	if (! FileCtl.FileWrite(sndSsbPath, invlFile)) {
		/* on file control failure try SSBI_MK_MODE */
		AdjustCmd.DataSize = 1;
		AdjustCmd.SetParam8(0, 0);
		if (! AdjustCmd.CmdIssue(0x0601, 0x0031)) {
			alert("Write SSB File Error !");
			Disconnect();
			return false;
		}
	}

	// CA搭載機種はCAのデッドロック監視モードを解除する
	if (IsGetCaVer()) {
		if (! UpdateBackupData8(0x00510038, 0x0C, 0)) {
			Disconnect();
			alert("Failed! Cannot release Deadlock Monitoring.");
			return false;
		}
	}

	alert("Write invl File Success ! Must Reboot.");
	Disconnect();
}

///////////////////////////////////////////////////////////////////////////////
// SSBIを無効にする
///////////////////////////////////////////////////////////////////////////////
function comExecSnapShotBootOffF()
{
	var sndSsbPath ="/dev/nflasha5";
	var ffffFile = CurrentDir + "\\config\\" + "FFFF";

	if (! WshFs.FileExists(ffffFile)) {
		alert("FFFF is not exist! Please set ffff file to config folder.(Mint tool included");
		return false;
	}

	if (! Connect()) {
		return false;
	}

	if (! FileCtl.FileWrite(sndSsbPath ,ffffFile)) {
		/* on file control failure try SSBI_MK_MODE */
		AdjustCmd.DataSize = 1;
		AdjustCmd.SetParam8(0, 1);
		if (! AdjustCmd.CmdIssue(0x0601, 0x0031)) {
			alert("Write SSB File Error !");
			Disconnect();
			return false;
		}
	}

	alert("Write FFFF File Success ! Must Reboot.");
	Disconnect();
}

///////////////////////////////////////////////////////////////////////////////
// コアダンプ機能
///////////////////////////////////////////////////////////////////////////////
function kemCoreDump(
	 CoreDump	// CoreDump出力（ON:出力する/ OFF:出力しない）
)
{
	if(isDisableSenserIF(true)){
		return false;
	}

	// Read kemco.txt
	var kemcoReplaceStr = kemReadKemcoFile();
	if (kemcoReplaceStr == "") {
		return false;
	}

	if (CoreDump == "ON") {
		// CoreDump ON
		kemcoReplaceStr = kemcoReplaceStr.replace("coredump\.core=/log/%f\.core\.lz77","coredump\.core=");
		kemcoReplaceStr = kemcoReplaceStr.replace("coredump\.core=","coredump\.core=/log/%f\.core\.lz77");
	}
	else {
		// CoreDump OFF
		kemcoReplaceStr = kemcoReplaceStr.replace("coredump\.core=/log/%f\.core\.lz77","coredump\.core=");
	}

	if (kemWriteKemcoFile(kemcoReplaceStr) == false) {
		return false;
	}

	alert("Succeeded. Must Reboot.\n*SET corresponding with SSB must re-create SSBI.");
	return true;
}

///////////////////////////////////////////////////////////////////////////////
// UART入力有効化
///////////////////////////////////////////////////////////////////////////////

function kemChangeUart() {
		// Read kemco.txt
		var kemco = kemReadKemcoFile();
		if( kemco == "" ) {
				return false;
		}
		
		var kemcoReplaseStr = kemco;
		kemcoReplaseStr = kemcoReplaseStr.replace( "amba-pl011\.mx=32","amba-pl011\.mx=0" );
		if ( kemWriteKemcoFile( kemcoReplaseStr ) == false )
				return false;
		
		alert( "Change Uart Input Enable" ) ;
		
		return true;
}

