
//==================================================
//	Const definition
//==================================================
const TMONITOR_HEADER_SIZE = 12;
const TMONITOR32_ENTRY_SIZE = 32;
const TMONITOR64_ENTRY_SIZE = 40;

const TASK_COMM_LEN = 16;
const USR_COMM_LEN = 28;

const BITSHIFT_INTTIME = (10);
const BITMASK_INTNO = ((1 << BITSHIFT_INTTIME) - 1);
const BITMASK_INTTIME = (~BITMASK_INTNO);

const FMT64_LOG_TYPE_DISP = 0;
const FMT64_LOG_TYPE_INT = 1;
const FMT64_LOG_TYPE_ALM = 2;
const FMT64_LOG_TYPE_CYC = 3;
const FMT64_LOG_TYPE_USR = 0xF;


//==================================================
//	Thread monitor parser
//==================================================
function ThreadMonitorParser(_is_fmt_w_head, _is_fmt_64)
{
	this.binSize = 0;
	this.entrySize = 0;
	this.parseIdx = 0;
	this.maxEntryNum = 0;
	this.headSize = TMONITOR_HEADER_SIZE;
	this.is_fmt_w_head = _is_fmt_w_head;
	this.is_fmt_64 = _is_fmt_64;
	this.logs = new Array();
	this.prgs = null;


	//==================================================
	//	Error & exit
	//==================================================
	function die(msg)
	{
		mintole.error('***Thread monitor parser error: ' + msg);
		// exit();	// Cause syntax error to stop
	}


	//==================================================
	//	Get String from binary
	//==================================================
	function getStrFromBin(dv)
	{
		let log = "";
		for( let j = 0; j < dv.byteLength; j++ ) {
			let byte = dv.getUint8(j, true);
			if( byte == 0 ) { break; }
			log += String.fromCharCode(byte);
		}
	
		return log;
	}

	//==================================================
	//	Get offset
	//==================================================
	function getOffset(n, entrySize) { return (n * entrySize); }

	//==================================================
	//	Parse new format
	//==================================================
	function parseNewFmt(data, baseOffset, size)
	{
		let dve = new DataView(data, baseOffset, size);
		let offset = 0;
		let entry = {};

		entry.ltime = dve.getUint32(offset, true);	offset += 4;
		entry.htime = dve.getUint32(offset, true);	offset += 4;
		let cmn_inf = dve.getUint8(offset, true);			offset += 1;
		entry.cpu = cmn_inf & 0x0F;
		entry.log_type = (cmn_inf >> 4) & 0x0F;

		switch(entry.log_type)
		{
		case FMT64_LOG_TYPE_DISP:
			entry.pri = dve.getUint8(offset, true);			offset += 1;
			entry.state = dve.getUint16(offset, true);		offset += 2;
			entry.ppid = dve.getUint16(offset, true);		offset += 2;
			entry.npid = dve.getUint16(offset, true);		offset += 2;
			entry.disp_pc = (dve.getUint32(offset, true) << 32) | dve.getUint32(offset+4, true);		offset += 8;
			entry.ptsk_name = getStrFromBin(new DataView(data, baseOffset + offset, TASK_COMM_LEN));
			break;
		case FMT64_LOG_TYPE_INT:
		case FMT64_LOG_TYPE_ALM:
		case FMT64_LOG_TYPE_CYC:
			offset += 1;
			offset += 2;
			entry.hdl_id = dve.getUint16(offset, true);		offset += 2;
			offset += 2;
			entry.proc_time = (dve.getUint32(offset, true) << 32) | dve.getUint32(offset+4, true);		offset += 8;
			entry.hdl_name = getStrFromBin(new DataView(data, baseOffset + offset, TASK_COMM_LEN));
			break;
		case FMT64_LOG_TYPE_USR:
			offset += 1;
			offset += 2;
			entry.log_str = getStrFromBin(new DataView(data, baseOffset + offset, USR_COMM_LEN));
			break;
		default:
			die("Invalid format");
			break;
		}

		dve = null;

		return entry;
	}

	//==================================================
	//	Parse old format
	//==================================================
	function parseOldFmt(data, baseOffset, size)
	{
		let dve = new DataView(data, baseOffset, size);
		let offset = 0;
		let entry = {};

		entry.time = dve.getUint32(offset, true);		offset += 4;
		entry.ppid = dve.getUint16(offset, true);		offset += 2;
		entry.npid = dve.getUint16(offset, true);		offset += 2;
		entry.data = dve.getUint32(offset, true);		offset += 4;
		let usr_cpu_pri = dve.getUint16(offset, true);	offset += 2;
		entry.user = (usr_cpu_pri >> 0) & 0x0001;
		entry.cpu = (usr_cpu_pri >> 1) & 0x0007;
		entry.pri = (usr_cpu_pri >> 4) & 0x0FFF;
		entry.state = dve.getUint16(offset, true);		offset += 2;
		entry.prev = getStrFromBin(new DataView(data, baseOffset + offset, TASK_COMM_LEN));

		dve = null;

		return entry;
	}

	//==================================================
	//	Initialize parser by dataArray
	//==================================================
	this.initByData = function(data, _prgs)
	{
		this.logs = new Array();

		// Get entry size
		if( this.is_fmt_64 ) {
			this.entrySize = TMONITOR64_ENTRY_SIZE;
		}
		else {
			this.entrySize = TMONITOR32_ENTRY_SIZE;
		}

		// Get sizes
		if( this.is_fmt_w_head ) {
			let dve = new DataView(data, 0, TMONITOR_HEADER_SIZE);
			let offset = 0;

			let idx = dve.getUint32(offset, true);		offset += 4;
			let ovrflw = dve.getUint32(offset, true);		offset += 4;

			this.binSize = data.byteLength;

			if( ovrflw == 1 ) {
				this.maxEntryNum = parseInt((this.binSize - TMONITOR_HEADER_SIZE) / this.entrySize, 10);
			}
			else {
				this.maxEntryNum = idx;
			}

			// Size check
			if( this.binSize < this.headSize ) {
				die("Invalid Data (binary size is smaller than header size");
				return;
			}
			if( this.binSize < this.maxEntryNum * this.entrySize ) {
				die("Invalid Data (binary size is smaller than expected)");
				return;
			}

			dve = null;
		}
		else {
			this.binSize = data.byteLength;
			this.maxEntryNum = parseInt(this.binSize / this.entrySize, 10);
			this.headSize = 0;
		}

		this.prgs = _prgs;
		if( this.prgs != null ) { this.prgs.setMaxNum(this.maxEntryNum); }
		
		for( let i = 0; i < this.maxEntryNum; i++ ) {
			let baseOffset = getOffset(this.parseIdx, this.entrySize) + this.headSize;
			if( this.is_fmt_64 ) {
				this.logs.push( parseNewFmt(data, baseOffset, this.entrySize) );
			}
			else {
				this.logs.push( parseOldFmt(data, baseOffset, this.entrySize) );
			}
			this.parseIdx++;
			if( this.prgs != null ) { this.prgs.update(); }

			// Reach max NO.
			if( this.parseIdx >= this.maxEntryNum )
			{
				// Sort by time
				this.logs.sort(function(a,b){
					if( (a.htime*0x100000000 + a.ltime) < (b.htime*0x100000000 + b.ltime) ) return -1;
					if( (a.htime*0x100000000 + a.ltime) > (b.htime*0x100000000 + b.ltime) ) return 1;
					return 0;
				});

				// Delete progress info
				if( this.prgs != null ) {
					this.prgs.end();
					this.prgs = null;
				}

				data = null;
			}
		}
	}
	
	//==================================================
	//	Get string by new format
	//==================================================
	function getStrByNewFmt(log, _translateWchan)
	{
		let logStr = "";
		
		let timeStr = ((log.htime*0x100000000 + log.ltime)/1000000).toFixed(6);
		let timeStrLen = timeStr.length;
		// timeStr = " ".repeat(5+1+6 - timeStr.length) + timeStr; // CANNOT use for IE11
		for( let j = 0; j < 5+1+6 - timeStrLen; j++ ) {
			timeStr = " " + timeStr;
		}
		logStr += "[ " + timeStr + " ] -";

		switch (log.log_type)
		{
		case FMT64_LOG_TYPE_DISP:
			let npidStr = String(log.npid);
			let npidStrLen = npidStr.length;
			let ppidStr = String(log.ppid);
			let ppidStrLen = ppidStr.length;
			let wchan = log.disp_pc.toString(16);
			if( _translateWchan ) {
				wchan = _translateWchan(wchan);
			}

			// npidStr = "0".repeat(3 - npidStr.length) + npidStr; // CANNOT use for IE11
			for( let j = 0; j < 3 - npidStrLen; j++ ) {
				npidStr = "0" + npidStr;
			}
			// ppidStr = "0".repeat(3 - ppidStr.length) + ppidStr; // CANNOT use for IE11
			for( let j = 0; j < 3 - ppidStrLen; j++ ) {
				ppidStr = "0" + ppidStr;
			}
			logStr += "sched next:" + npidStr + " < prev:" + ppidStr + " state:" + log.state.toString(16) + " wchan:" + wchan + "(" + log.disp_pc.toString(16) + ") task:" + log.ptsk_name + " cpu:" + log.cpu + " prio:" + (log.pri+1);
			break;
		case FMT64_LOG_TYPE_INT:
			logStr += "profile user irq:" + log.hdl_name + "(" + log.hdl_id + ")," + log.proc_time + " cpu:" + log.cpu;
			break;
		case FMT64_LOG_TYPE_ALM:
			logStr += "profile user alm:" + log.hdl_name + "(" + log.hdl_id + ")," + log.proc_time + " cpu:" + log.cpu;
			break;
		case FMT64_LOG_TYPE_CYC:
			logStr += "profile user cyc:" + log.hdl_name + "(" + log.hdl_id + ")," + log.proc_time + " cpu:" + log.cpu;
			break;
		case FMT64_LOG_TYPE_USR:
			logStr += "profile user " + log.log_str + " cpu:" + log.cpu;
			break;
		default:
			die("Invalid format");
			break;
		}

		logStr += "\r\n";

		return logStr;
	}
	
	//==================================================
	//	Get string by old format
	//==================================================
	function getStrByOldFmt(log, _translateWchan)
	{
		let logStr = "";

		let timeStr = (log.time/1000000).toFixed(6);
		let timeStrLen = timeStr.length;
		// timeStr = " ".repeat(5+1+6 - timeStr.length) + timeStr; // CANNOT use for IE11
		for( let j = 0; j < 5+1+6 - timeStrLen; j++ ) {
			timeStr = " " + timeStr;
		}
		logStr += "[ " + timeStr + " ] -";

		if( log.user ) {
			logStr += "profile user " + log.prev + " cpu:" + log.cpu;
		}
		else if( log.npid == log.ppid ) {
			let irqNo = log.data & BITMASK_INTNO;
			let td = (log.data & BITMASK_INTTIME) >> BITSHIFT_INTTIME;

			logStr += "profile user irq:" + irqNo + "," + td + " cpu:" + log.cpu;
		}
		else {
			let npidStr = String(log.npid);
			let npidStrLen = npidStr.length;
			let ppidStr = String(log.ppid);
			let ppidStrLen = ppidStr.length;
			let wchan = log.disp_pc.toString(16);
			if( _translateWchan ) {
				wchan = _translateWchan(wchan);
			}

			// npidStr = "0".repeat(3 - npidStr.length) + npidStr; // CANNOT use for IE11
			for( let j = 0; j < 3 - npidStrLen; j++ ) {
				npidStr = "0" + npidStr;
			}
			// ppidStr = "0".repeat(3 - ppidStr.length) + ppidStr; // CANNOT use for IE11
			for( let j = 0; j < 3 - ppidStrLen; j++ ) {
				ppidStr = "0" + ppidStr;
			}
			logStr += "sched next:" + npidStr + " < prev:" + ppidStr + " state:" + log.state.toString(16) + " wchan:" + wchan + "(" + log.data.toString(16) + ") task:" + log.prev + " cpu:" + log.cpu + " prio:" + log.pri;
		}

		logStr += "\r\n";

		return logStr;
	}

	//==================================================
	//	Get string
	//==================================================
	this.getString = function(_translateWchan)
	{
		let logStrs = "";

		for( let i = 0; i < this.logs.length; i++ )
		{
			let log = this.logs[i];
			let logStr = "";

			if( this.is_fmt_64 ) {
				logStr = getStrByNewFmt(log, _translateWchan);
			}
			else {
				logStr = getStrByOldFmt(log, _translateWchan);
			}

			logStrs += logStr
		}

		return logStrs;
	}
}
