
/*--------------------------------------------------------------------------------
 * Main
--------------------------------------------------------------------------------*/
function main(args)
{
	var fileName = args[0];
	var reboot_Flag = args[1];

	if(!Connect()) {
		return 1;
	}

	// Update
	if(! FirmUpCtl.Update(fileName)) {
		Disconnect();
		return 1;
	}

	if(reboot_Flag == 1) {
		// Reboot from Updater mode
		if (reboot_Flag) {
			AdjustCmd.DataSize = 0;
			AdjustCmd.CmdIssue(0x0604, 0x4005);
		}
	}

	// Including Reboot
	Disconnect();

	return 0;
}
