
//----------mintole stub----------
function MintoleStub() {
	this.debug = function(x) {};
	this.info = function(x) {};
	this.warning = function(x) {};
	this.alert = function(x) {};
	this.error = function(x) {};
	this.critical = function(x) {};
}
mintole = new MintoleStub();
//----------mintole stub----------

// Main caller
var WSArgs = WScript.Arguments;
var args = [];
for (var c = 0; c < WSArgs.length; c++ ) {
	args.push(WSArgs(c));
}
WScript.Quit(main(args));
