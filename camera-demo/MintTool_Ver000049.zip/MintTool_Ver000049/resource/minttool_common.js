/*
 * temporary handling
 */
var BKID_SYS_MAINLSI              = 0x10D0009;
var BKPRM_SYS_MAINLSI_MIRA_CETUS  = 0x8;
var BKPRM_SYS_MAINLSI_MIRA_CETUS2 = 0x9;

function chkMainLSI()
{
	var bk = new Array();
	if(ReadBackupData8(BKID_SYS_MAINLSI, bk)) {
		if (bk.pop() < BKPRM_SYS_MAINLSI_MIRA_CETUS) {
			var res = window.confirm("IPSX機種以外はサポートされていません。処理を継続しますか？");
			if (res) {
				return true;
			} else {
				return false;
			}
		}
	}
	else {
		return false;
	}

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// USBシリアル番号を取得
///////////////////////////////////////////////////////////////////////////////
function getUSBSerial()
{
	var BKID_USB_SERIAL = 0x00e70003;
	var LEN_USB_SERIAL = 4;
	var serialNo = "";
	var datas = new Array();
	if( ReadBackupData8(BKID_USB_SERIAL, datas) ) {
		for( var i = 0; i < LEN_USB_SERIAL; i++ ) {
			serialNo += zerofillBefore(datas[i].toString(16), 2);
		}
	}

	return serialNo;
}

///////////////////////////////////////////////////////////////////////////////
// データ読み出し先ファイルパスの生成
///////////////////////////////////////////////////////////////////////////////
function generateDataSaveFilePath(baseDir, fileExt)
{
	var filePath = "";

	if( !WshFs.FolderExists(baseDir) ) {
		mintole.alert("Destination: " + baseDir + " Not Found");
		return "";
	}

	// 相対パスの場合は絶対パスに修正
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	var dirName = fso.GetAbsolutePathName(baseDir);
	delete fso;

	// USBシリアル番号を取得する
	var serialNo = getUSBSerial();

	// Category＋FirmwareVerison(先頭5文字)＋USBシリアル番号でフォルダを作成する
	dirName = dirName + "\\" + GetCategoryName() + "_" + GetHeadVersion() + "_" + serialNo;

	try {
		// 当該フォルダが存在しない場合、新規作成する
		if( !WshFs.FolderExists(dirName) ) {
			if( !WshFs.CreateFolder(dirName) ) {
				mintole.alert("Fail to create data save directory: " + dirName + "(" + WshFs.ErrMsg + ")");
				throw "error";
			}
		}

		// ファイル名（日付）
		var filename = GetDateStrForFileName() + "." + fileExt;

		filePath = dirName + "\\" + filename;
	}
	catch(e) {
	}

	return filePath;
}


///////////////////////////////////////////////////////////////////////////////
// 各マイコンバージョン表示
///////////////////////////////////////////////////////////////////////////////
var SET_VER_VALUE_CLASS_NAME = "setVerValue";
function comExecVersion()
{
	if( setVer.readFirmwareVer() != true ) { return; }
	if( setVer.readDefhd() != true ) { return; }

	// セットバージョン
	var usrVer = setVer.getUsrVer();
	if( usrVer != null ) {
		SetVer.innerHTML = usrVer.major + "." + usrVer.minor;
	} else {
		SetVer.innerHTML = "";
	}
	SetVer.className = SET_VER_VALUE_CLASS_NAME;

	// 機種情報
	var modelInfo = setVer.getModelInfo();
	if( modelInfo != null ) {
		MachineVer.innerHTML = modelInfo.year + "."
							+ modelInfo.category + "."
							+ modelInfo.major + "."
							+ modelInfo.minor;
	} else {
		MachineVer.innerHTML = "";
	}
	MachineVer.className = SET_VER_VALUE_CLASS_NAME;

	// 仕向情報
	DestVer.innerHTML = setVer.getDestInfo() || "";
	DestVer.className = SET_VER_VALUE_CLASS_NAME;

	// Firmバージョン
	HosVer.innerHTML = setVer.getFirmwareVer() || "";
	HosVer.className = SET_VER_VALUE_CLASS_NAME;
}

///////////////////////////////////////////////////////////////////////////////
// 各マイコンバージョン表示をリセットする
///////////////////////////////////////////////////////////////////////////////
function comResetVersion()
{
	var prm = "*";

	SetVer.innerHTML = prm;
	SetVer.className = "";
	MachineVer.innerHTML = prm;
	MachineVer.className = "";
	DestVer.innerHTML = prm;
	DestVer.className = "";
	HosVer.innerHTML = prm;
	HosVer.className = "";
}

///////////////////////////////////////////////////////////////////////////////
// Update Mode ON
///////////////////////////////////////////////////////////////////////////////
function comExecMkUpdateOnF()
{
	if (! Connect()) {
		return false;
	}

	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x04);

	if (! AdjustCmd.CmdIssue(0x0604, 0x4001)) {
		alert("Change Update Mode FAIL !");
		Disconnect();
		return false;
	}

	var res = AdjustCmd.GetResponse8(0);

	if (res != 0) {
		alert("Change Update Mode FAIL !");
	}
	else {
		alert("Update Mode ON Complete.");
	}

	Disconnect();

	mintole.debug("Update mode ON");
}

///////////////////////////////////////////////////////////////////////////////
// Update Mode OFF
///////////////////////////////////////////////////////////////////////////////
function comExecMkUpdateOffF()
{
	if (! Connect()) {
		return false;
	}

	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x00);

	if (! AdjustCmd.CmdIssue(0x0604, 0x4001)) {
		alert("Change Update Mode FAIL !");
		Disconnect();
		return false;
	}

	var res = AdjustCmd.GetResponse8(0);

	if (res != 0) {
		alert("Change Update Mode FAIL !");
	}
	else {
		alert("Update Mode OFF Complete.");
	}

	Disconnect();

	mintole.debug("Update mode OFF");
}

///////////////////////////////////////////////////////////////////////////////
// PG ON
///////////////////////////////////////////////////////////////////////////////
function comPGON()
{
	if (! Connect()) {
		return false;
	}

	if(getKindOfImager() == 0x810){
		//設定：LOKI_OFMT パタジェネ設定
		AdjustCmd.DataSize = 21;
		AdjustCmd.SetParam32( 0, 0x00000001);   // operation = WRITE
		AdjustCmd.SetParam32( 1, 0x01650000);   // backupID
		AdjustCmd.SetParam32( 2, 0x00000000);   // offset
		AdjustCmd.SetParam32( 3, 0x00000001);   // size[byte] 
		AdjustCmd.SetParam32( 4, 0x00000001);   // CPU ID
		AdjustCmd.SetParam8 (20, 0x0000008C);   // 設定値
		AdjustCmd.CmdIssue( 0x0603, 0x0042 );   // BACKUP OFFSET ACCESS
		
		//SAVE：SID_R_DFECORE設定値保存 (Diadem-SysCom_191H\export\sidDef.hを参照)
		AdjustCmd.DataSize = 2;                     // parameter size
		AdjustCmd.SetParam16(0, 0x0165);   // backupID
		res = AdjustCmd.CmdIssue( 0x0603, 0x0003 ); // SAVE
	}
	else{
		//設定：CamCore パタジェネ設定（euc_iif_pgon 下位）＊下位8bitがPG_MODE+1　1:カラーバー(IIF)　2:ランプ(IIF)　3:クロスハッチ/クロスドット(IIF)　4:色差平面(IIF)　5:斜め格子(IIF)　6:AF波形(IIF)　7:垂直カラーバー(TST)　8:垂直ランプ(TST)　9:クロスハッチ(TST)　A:垂直FK波形(TST)
		AdjustCmd.DataSize = 21;
		AdjustCmd.SetParam32( 0, 0x00000001);   // operation = WRITE
		AdjustCmd.SetParam32( 1, 0x00080000);   // backupID
		AdjustCmd.SetParam32( 2, 0x00000002);   // offset
		AdjustCmd.SetParam32( 3, 0x00000001);   // size[byte] 
		AdjustCmd.SetParam32( 4, 0x00000001);   // CPU ID
		AdjustCmd.SetParam8 (20, 0x000000FE);   // 設定値
		AdjustCmd.CmdIssue( 0x0603, 0x0042 );   // BACKUP OFFSET ACCESS

		//設定：CamCore パタジェネ設定（euc_iif_pgon 上位）*上位8bitがRAW_OUT_BIT　RAW_10BIT = 0,　RAW_12BIT,　RAW_14BIT,　RAW_16BIT
		AdjustCmd.DataSize = 21;
		AdjustCmd.SetParam32( 0, 0x00000001);   // operation = WRITE
		AdjustCmd.SetParam32( 1, 0x00080000);   // backupID
		AdjustCmd.SetParam32( 2, 0x00000003);   // offset
		AdjustCmd.SetParam32( 3, 0x00000001);   // size[byte] 
		AdjustCmd.SetParam32( 4, 0x00000001);   // CPU ID
		AdjustCmd.SetParam8 (20, 0x00000002);   // 設定値
		AdjustCmd.CmdIssue( 0x0603, 0x0042 );   // BACKUP OFFSET ACCESS

		//設定：CamCoreパタジェネ設定（euc_iif_testgif_on）IIF TEST_GIFを有効にする。0以外ならON※Imagerがない時は必須！
		AdjustCmd.DataSize = 21;
		AdjustCmd.SetParam32( 0, 0x00000001);   // operation = WRITE
		AdjustCmd.SetParam32( 1, 0x00080000);   // backupID
		AdjustCmd.SetParam32( 2, 0x00000005);   // offset
		AdjustCmd.SetParam32( 3, 0x00000001);   // size[byte] 
		AdjustCmd.SetParam32( 4, 0x00000001);   // CPU ID
		AdjustCmd.SetParam8 (20, 0x00000001);   // 設定値
		AdjustCmd.CmdIssue( 0x0603, 0x0042 );   // BACKUP OFFSET ACCESS

		//SAVE：SID_R_CAMCORE(8)設定値保存 (Diadem-SysCom_191H\export\sidDef.hを参照)
		AdjustCmd.DataSize = 2;                     // parameter size
		AdjustCmd.SetParam16(0, 0x0008);   // backupID
		res = AdjustCmd.CmdIssue( 0x0603, 0x0003 ); // SAVE

		//SAVE：SID_R_DARWIN保存
		AdjustCmd.DataSize = 2;                     // parameter size
		AdjustCmd.SetParam16(0, 0x0185);   // backupID
		res = AdjustCmd.CmdIssue( 0x0603, 0x0003 ); // SAVE
	}

	alert("PG ON complete!");
	Disconnect();
}

///////////////////////////////////////////////////////////////////////////////
// PG OFF
///////////////////////////////////////////////////////////////////////////////
function comPGOFF()
{
	if (! Connect()) {
		return false;
	}

	if(getKindOfImager() == 0x810){
		//設定：LOKI_OFMT パタジェネ設定
		AdjustCmd.DataSize = 21;
		AdjustCmd.SetParam32( 0, 0x00000001);   // operation = WRITE
		AdjustCmd.SetParam32( 1, 0x01650000);   // backupID
		AdjustCmd.SetParam32( 2, 0x00000000);   // offset
		AdjustCmd.SetParam32( 3, 0x00000001);   // size[byte] 
		AdjustCmd.SetParam32( 4, 0x00000001);   // CPU ID
		AdjustCmd.SetParam8 (20, 0x00000000);   // 設定値
		AdjustCmd.CmdIssue( 0x0603, 0x0042 );   // BACKUP OFFSET ACCESS
		
		//SAVE：SID_R_DFECORE設定値保存 (Diadem-SysCom_191H\export\sidDef.hを参照)
		AdjustCmd.DataSize = 2;                     // parameter size
		AdjustCmd.SetParam16(0, 0x0165);   // backupID
		res = AdjustCmd.CmdIssue( 0x0603, 0x0003 ); // SAVE
	}
	else{
		//設定：CamCore パタジェネ設定（euc_iif_pgon 下位）＊下位8bitがPG_MODE+1　1:カラーバー(IIF)　2:ランプ(IIF)　3:クロスハッチ/クロスドット(IIF)　4:色差平面(IIF)　5:斜め格子(IIF)　6:AF波形(IIF)　7:垂直カラーバー(TST)　8:垂直ランプ(TST)　9:クロスハッチ(TST)　A:垂直FK波形(TST)
		AdjustCmd.DataSize = 21;
		AdjustCmd.SetParam32( 0, 0x00000001);   // operation = WRITE
		AdjustCmd.SetParam32( 1, 0x00080000);   // backupID
		AdjustCmd.SetParam32( 2, 0x00000002);   // offset
		AdjustCmd.SetParam32( 3, 0x00000001);   // size[byte] 
		AdjustCmd.SetParam32( 4, 0x00000001);   // CPU ID
		AdjustCmd.SetParam8 (20, 0x00000000);   // 設定値
		AdjustCmd.CmdIssue( 0x0603, 0x0042 );   // BACKUP OFFSET ACCESS

		//設定：CamCore パタジェネ設定（euc_iif_pgon 上位）*上位8bitがRAW_OUT_BIT　RAW_10BIT = 0,　RAW_12BIT,　RAW_14BIT,　RAW_16BIT
		AdjustCmd.DataSize = 21;
		AdjustCmd.SetParam32( 0, 0x00000001);   // operation = WRITE
		AdjustCmd.SetParam32( 1, 0x00080000);   // backupID
		AdjustCmd.SetParam32( 2, 0x00000003);   // offset
		AdjustCmd.SetParam32( 3, 0x00000001);   // size[byte] 
		AdjustCmd.SetParam32( 4, 0x00000001);   // CPU ID
		AdjustCmd.SetParam8 (20, 0x00000000);   // 設定値
		AdjustCmd.CmdIssue( 0x0603, 0x0042 );   // BACKUP OFFSET ACCESS

		//設定：CamCoreパタジェネ設定（euc_iif_testgif_on）IIF TEST_GIFを有効にする。0以外ならON※Imagerがない時は必須！
		AdjustCmd.DataSize = 21;
		AdjustCmd.SetParam32( 0, 0x00000001);   // operation = WRITE
		AdjustCmd.SetParam32( 1, 0x00080000);   // backupID
		AdjustCmd.SetParam32( 2, 0x00000005);   // offset
		AdjustCmd.SetParam32( 3, 0x00000001);   // size[byte] 
		AdjustCmd.SetParam32( 4, 0x00000001);   // CPU ID
		AdjustCmd.SetParam8 (20, 0x00000000);   // 設定値
		AdjustCmd.CmdIssue( 0x0603, 0x0042 );   // BACKUP OFFSET ACCESS

		//SAVE：SID_R_CAMCORE(8)設定値保存 (Diadem-SysCom_191H\export\sidDef.hを参照)
		AdjustCmd.DataSize = 2;                     // parameter size
		AdjustCmd.SetParam16(0, 0x0008);   // backupID
		res = AdjustCmd.CmdIssue( 0x0603, 0x0003 ); // SAVE

		//SAVE：SID_R_DARWIN保存
		AdjustCmd.DataSize = 2;                     // parameter size
		AdjustCmd.SetParam16(0, 0x0185);   // backupID
		res = AdjustCmd.CmdIssue( 0x0603, 0x0003 ); // SAVE
	}

	alert("PG OFF complete!");
	Disconnect();
}

function getKindOfImager()
{
	AdjustCmd.DataSize = 20;
	AdjustCmd.SetParam32( 0, 0x00000000);   // operation = READ
	AdjustCmd.SetParam32( 1, 0x00BC0016);   // backupID
	AdjustCmd.SetParam32( 2, 0x00000000);   // offset
	AdjustCmd.SetParam32( 3, 0x00000002);   // size[byte] 
	AdjustCmd.SetParam32( 4, 0x00000001);   // CPU ID
	AdjustCmd.CmdIssue( 0x0603, 0x0042 );   // BACKUP OFFSET ACCESS

	return AdjustCmd.GetResponse16(0);
}

function comInitPreset(
	softresetVal
)
{
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	var dpathTmp = fso.GetAbsolutePathName(".\\tmpInitPreset");
	if (fso.FolderExists(dpathTmp)) {
		fso.DeleteFolder(dpathTmp, true);
    }
	fso.CreateFolder(dpathTmp);

	if (!Connect()) {
		alert("[error] SENSER connect failed.");
		return false;
	}

	var vnameTgt = ""
	var fpathRts = ""
	var fpathZip = ""
	AdjustCmd.DataSize = 0;
	if (!setVer.readFirmwareVer()) {
		alert("[error] Get Firm Version failed.");
		fso = null
		Disconnect();
		return false;
	} else {
		vnameTgt = setVer.getFirmwareVer();
	}
	var fnameTmp = "00000000_" + vnameTgt + "_Backup"
	var fnameTgt = fnameTmp + ".zip"

	var dpathRts = "\\\\dis-nas-public-001.cv.sony.co.jp\\public\\rel-rts\\"
	var dpathCat = new Enumerator((fso.GetFolder(dpathRts)).SubFolders);
	var bFound = false;
	for (; !dpathCat.atEnd(); dpathCat.moveNext()) {
		var dpathSet = new Enumerator(fso.GetFolder(dpathCat.item()).SubFolders);
		for (; !dpathSet.atEnd(); dpathSet.moveNext()) {
			fpathRts = dpathSet.item() + "\\" + vnameTgt + "\\attachment\\" + fnameTgt
			if (fso.FileExists(fpathRts)) {
				bFound = true;
				break;
			}
		}

		if (bFound)
			break;
	}

	if (bFound) {
		fpathZip = dpathTmp + "\\" + fnameTgt;
		fso.CopyFile(fpathRts, fpathZip, true);

		var dpathZip = dpathTmp + "\\" + fnameTmp;
		if (fso.FolderExists(dpathZip)) {
			fso.DeleteFolder(dpathZip, true);
   		}
		fso.CreateFolder(dpathZip);

		var shell = new ActiveXObject("Shell.Application");
        shell.NameSpace(dpathZip).CopyHere(shell.NameSpace(fpathZip).Items(), 20);
		shell = null

		var fpathDest = dpathZip + "\\Backup\\MainDest.txt"
		var FORREADING = 1
		var TRISTATE_FALSE = 0
		var file = fso.OpenTextFile(fpathDest, FORREADING, true, TRISTATE_FALSE);

		var cat = ""
		var set = ""
		var bin = ""
		while (!file.AtEndOfStream) {
   			if (cat == "")
				cat = file.ReadLine();
			else if (set == "")
				set = file.ReadLine();
			else if (bin == "") {
				bin = file.ReadLine();
				break;
			}
		}
		file.Close();

		if (cat != "" && set != "" && bin != "") {
			var fpathBin = dpathZip + "\\Backup\\" + cat + "\\" + set + "\\" + bin
			if (!fso.FileExists(fpathBin)) {
        		alert("[error] Backup-bin-file is NOT found! Backup-initialization skipped.");
				fso = null
				Disconnect();
				return false;
			}
		} else {
        	alert("[error] Main-Dest-info. is invalid! Backup-initialization skipped.");
			fso = null
			Disconnect();
			return false;
		}
	} else {
        alert("[error] Backup-zip-file is NOT found! Backup-initialization skipped.");
		fso = null
		Disconnect();
		return false;
	}

	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x00);
	if (! AdjustCmd.CmdIssue(0x0603, 0x400F)) {
		alert("[error] set failed!");
		Disconnect();
		return false;
	}

	AdjustCmd.DataSize = 4;
	AdjustCmd.SetParam32(0, 0);
	if (! AdjustCmd.CmdIssue_Ddm(0x0603, 0x0004, 0, fpathBin, "")) {
		alert("[error] PDT write failed!");
		Disconnect();
		return false;
	}

	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x01);
	if (! AdjustCmd.CmdIssue(0x0603, 0x400F)) {
		alert("[error] set failed!");
		Disconnect();
		return false;
	}

	if ((softresetVal == "1Cell") || (softresetVal == "2Cell")) {
		AdjustCmd.DataSize = 0;
		if (! AdjustCmd.CmdIssue(0x0D01, 0x4050)) {
			alert("[error] software reset failed!");
			Disconnect();
			return false;
		}
	} else {
        alert("parameter to reset is invalid! Soft-reset skipped.");
		Disconnect();
		return false;
	}

	if (fso.FolderExists(dpathTmp)) {
		fso.DeleteFolder(dpathTmp, true);
    }

	Disconnect();
	return true;
}

///////////////////////////////////////////////////////////////////////////////
// フォルダ選択
///////////////////////////////////////////////////////////////////////////////
function comSelectFolder(
	output_id	// 文字列出力先
)
{
	var WshSellApp = new ActiveXObject("Shell.Application");

	//特殊フォルダ
	//マイコンピュータ"::{20D04FE0-3AEA-1069-A2D8-08002B30309D}"
	//マイネットワーク"::{208D2C60-3AEA-1069-A2D7-08002B30309D}"
	//ごみ箱		  "::{645FF040-5081-101B-9F08-00AA002F954E}"...

	var title = "Please Select Folder for Destination";
	var option = 0x0050;
	var folder = WshSellApp.BrowseForFolder(0, title, option);

	if (folder != null) {
		var folderItems = folder.Items();

		if (folderItems != null ) {
			var folderPass = folderItems.Item();

			if (folderPass != null ) {
				//特殊フォルダチェック
				var CheckSpecialfolderNum = folderPass.Path.indexOf("::{");

				//特殊フォルダチェック
				if (CheckSpecialfolderNum == -1) {
					alert("【Output Folder】\n" + folderPass.Path);
					document.getElementById(output_id).value = folderPass.Path;
					return true;
				}
			}
		}

		alert("Folder Was Not Aable To Be Referred To.");
	}

	WshSellApp = null;
	return false;
}

///////////////////////////////////////////////////////////////////////////////
// バックアップファイルの読み書き
///////////////////////////////////////////////////////////////////////////////
function comBackupFileRead(
	rcvDirname	// 保存先
)
{
	var filePath = generateDataSaveFilePath(rcvDirname, "bin");

	if( filePath == "" ) {
		return false;
	}

	if( !Connect() ) {
		return false;
	}

	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x00);

	if (! AdjustCmd.CmdIssue_Ddm(0x0603, 0x0005, 0, "", filePath)) {
		alert("[0603] PDT_READ Command Error !");
	}
	else {
		alert("Get Backup File Success");
	}

	Disconnect();
}

///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
function comBackupFileWrite(
	sndFilename,	// 送信ファイル
	writeMode		// 書き込みモード
)
{
	if (! WshFs.FileExists(sndFilename)) {
		alert("Input:" + sndFilename + " Not Found");
		return false;
	}

	if (! Connect()) {
		return false;
	}

	AdjustCmd.DataSize = 4;
	if (writeMode == "ALL") {
		if (! window.confirm("Clear adjust value, because overwrite all area. \nDo you want to excute?")) {
			return false;
		}
		AdjustCmd.SetParam32(0, 2);
	}
	else if (writeMode == "EXADJUST") {
		AdjustCmd.SetParam32(0, 0);
	}
	else {
		AdjustCmd.SetParam32(0, 3);
	}

	if (! AdjustCmd.CmdIssue_Ddm(0x0603, 0x0004, 0, sndFilename, "")) {
		alert("[0603] PDT_WRITE Command Error !");
	}
	else {
		// CA搭載機のバックアップ書き戻し.
		AdjustCmd.DataSize = 0;
		AdjustCmd.CmdIssue(0x0421, 0x00E8);
		alert("Write Backup File Success.");
	}

	Disconnect();
}

///////////////////////////////////////////////////////////////////////////////
// SoftwareReset Function
///////////////////////////////////////////////////////////////////////////////
function comSoftReset(
	softresetVal	// 1Cell/ 2Cell
)
{
	if (! Connect()) {
		return false;
	}

	if ((softresetVal == "1Cell") || (softresetVal == "2Cell")) {
		AdjustCmd.DataSize = 0;
		if (! AdjustCmd.CmdIssue(0x0D01, 0x4050)) {
			alert("Software Reset FAIL !");
			Disconnect();
			return false;
		}
	}

	Disconnect();
	return true;
}

///////////////////////////////////////////////////////////////////////////////
// Senser Mode Function
///////////////////////////////////////////////////////////////////////////////
function comSenserMode(
	sensermodeVal,	// Normal/Force USB
	alertMode		// "NoAlert" is not show alert
)
{
	if (! Connect()) {
		return false;
	}

	// Set SenserMode Value (Normal: 0x00/ ForceUSB: 0x01)
	var sensermode = 0x00;

	if (sensermodeVal == "Normal") {
		sensermode = 0x00;
	}
	else {
		sensermode = 0x01;
	}

	AdjustCmd.DataSize = 2;

	AdjustCmd.SetParam8(0, 0x01);
	AdjustCmd.SetParam8(1, sensermode);

	if (! AdjustCmd.CmdIssue(0x0601, 0x0011)) {
		alert("Change SenserMode FAIL !");
		Disconnect();
		return false;
	}

	Disconnect();

	if (alertMode != "NoAlert") {
		alert("Change SenserMode. Must Reboot.");
	}

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// Factory Check Mode Function
///////////////////////////////////////////////////////////////////////////////
function comFactoryCheck(
	fuctoryCheckModeVal 	// ON/ OFF
)
{
	if (! Connect()) {
		return false;
	}

	// Set Factory Check Mode Value (Normal: 0x00/ FactoryCheck: 0x01)
	var factorymode = 0x00;
	if (fuctoryCheckModeVal == "ON") {
		factorymode = 0x01;
	}
	else {
		factorymode = 0x00;
	}

	AdjustCmd.DataSize = 2;
	AdjustCmd.SetParam8(0, 0x01);
	AdjustCmd.SetParam8(1, factorymode);
	if (! AdjustCmd.CmdIssue(0x0601, 0x0012)) {
		alert("Change FactoryCheckMode FAIL !");
		Disconnect();
		return false;
	}

	Disconnect();
	alert("Change FactoryCheckMode. Going To Reboot.");
	return true;
}

///////////////////////////////////////////////////////////////////////////////
// Terminal Mode Function
///////////////////////////////////////////////////////////////////////////////
function comTerminalMode(
	terminalModeVal 	// USB/ UART
)
{
	if (! Connect()) {
		return false;
	}

	// Set Terminal Mode Value (UART:0x01/ USB:0x02)
	var terminalmode = 0x01;
	if (terminalModeVal == "UART") {
		terminalmode = 0x01;
	}
	else {
		terminalmode = 0x02;
	}

	AdjustCmd.DataSize = 2;
	AdjustCmd.SetParam8(0, terminalmode);
	AdjustCmd.SetParam8(1, terminalmode);

	if (! AdjustCmd.CmdIssue(0x0601, 0x801F)) {
		alert("Change TermMode FAIL !");
		Disconnect();
		return false;
	}

	alert("Change TermMode Success.");
	Disconnect();

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// APO Function
///////////////////////////////////////////////////////////////////////////////
function comApo(
	apoVal	// ON/ OFF
)
{
	var apo = 0x00;

	if (apoVal == "ON") {
		apo = 0x00;
	}
	else {
		apo = 0x01;
	}

	if (! UpdateBackupData8(0x00920000, apo, 0)) {
		return false;
	}

	alert("Change APO Setting. Must Reboot.");

	return true;
}


///////////////////////////////////////////////////////////////////////////////
// 設定情報取得コマンド
///////////////////////////////////////////////////////////////////////////////
var SETTING_INFO_SET_VALUE_CLASS_NAME = "setValue";
function comGetSettingInfo()
{
	if(isDisableSenserIF(true)){
		return false;
	}

	/////////////////////////////////////////////////
	// 設定情報の表示を「*」で初期化
	/////////////////////////////////////////////////
	comResetSettingInfo();
	
	if( settingInfo.read() == false ) { return false; }

	/////////////////////////////////////////////////
	// SENSERモード
	/////////////////////////////////////////////////
	SenserInfo.innerHTML = settingInfo.getSenserModeStr();
	SenserInfo.className = SETTING_INFO_SET_VALUE_CLASS_NAME;

	/////////////////////////////////////////////////
	// 退避ログ機能
	/////////////////////////////////////////////////
	EscapeLogInfo.innerHTML = settingInfo.getEscapeLogModeStr();
	EscapeLogInfo.className = SETTING_INFO_SET_VALUE_CLASS_NAME;

	/////////////////////////////////////////////////
	// 緊急再起動モード(Exception再起動)
	/////////////////////////////////////////////////
	RebootInfo.innerHTML = settingInfo.getExceptionRebootModeStr();
	RebootInfo.className = SETTING_INFO_SET_VALUE_CLASS_NAME;

	/////////////////////////////////////////////////
	// UART通信モード
	/////////////////////////////////////////////////
	UartInfo.innerHTML = settingInfo.getUARTModeStr();
	UartInfo.className = SETTING_INFO_SET_VALUE_CLASS_NAME;
}

///////////////////////////////////////////////////////////////////////////////
// 設定情報表示リセットコマンド
///////////////////////////////////////////////////////////////////////////////
function comResetSettingInfo()
{
	var prm = "*";

	/////////////////////////////////////////////////
	// 設定情報の表示を「*」で初期化
	/////////////////////////////////////////////////
	SenserInfo.innerHTML = prm;
	SenserInfo.className = "";
	EscapeLogInfo.innerHTML = prm;
	EscapeLogInfo.className = "";
	RebootInfo.innerHTML = prm;
	RebootInfo.className = "";
	UartInfo.innerHTML = prm;
	UartInfo.className = "";
}

///////////////////////////////////////////////////////////////////////////////
// Mario Function(受光角度分布調整データ)
///////////////////////////////////////////////////////////////////////////////
function comMarioRead(
	rcvDirname
)
{
	var filePath = generateDataSaveFilePath(rcvDirname, "bin");

	if( filePath == "" ) {
		return false;
	}

	if( !Connect() ) {
		return false;
	}

	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x00);

	if (! AdjustCmd.CmdIssue_Ddm(0x0404, 0x0062, 0, "", filePath)) {
		alert("[0404] A_PSD_DATA_READ Command Error !");
	}
	else {
		alert("Get PSD_DATA File Success");
	}

	Disconnect();

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
function comMarioWrite(
	fileName
)
{
	if (! WshFs.FileExists(fileName)) {
		alert("Input:" + fileName + " Not Found");
		return false;
	}

	if (! Connect()) {
		return false;
	}

	// Mario対応機種なら R_ZPD の BackupID を読出し可能.
	AdjustCmd.DataSize = 8;
	AdjustCmd.SetParam32(0, 0x013B0000);		// backupID R_ZPD
	AdjustCmd.SetParam32(1, 0x01);		// ChipSelect
	if (AdjustCmd.CmdIssue(0x0603, 0x0040)) {	// BACKUP READ
		AdjustCmd.DataSize = 0;

		if (! AdjustCmd.CmdIssue_Ddm(0x0404, 0x0063, 0, fileName, "" )) {
			alert("[0404] A_PSD_DATA_WRITE Command Error !");
		}
		else {
			// G_CHK_ERR_PRM で書き込み確認.
			var tempFile = CurrentDir + "\\temp";
			if (! AdjustCmd.CmdIssue_Ddm(0x0404, 0x0002, 0, "", tempFile)) {
				alert("[0404] G_CHK_ERR_PRM Command Error !");
			}
			else {
				// 結果は tmep ファイルに書き出しされているので、読み込み.
				var File = WshFs.OpenTextFile(tempFile, 1, true);
				var result = File.Read(1);	// 1文字読み込み.
				if (result == 0) {		// 0:失敗/ 1:成功.
					alert("[0404] A_PSD_DATA_WRITE Command Error !");
				}
				else {
					alert("Put PSD_DATA File Success");
				}
				File.Close()
				WshFs.DeleteFile(tempFile);
			}
		}
	}
	else {
		alert("Un-Supported function");
	}

	Disconnect();

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
// Defdet Function(欠陥調整データ)
///////////////////////////////////////////////////////////////////////////////
function comDefdetRead(
	rcvDirname
)
{
	var filePath = generateDataSaveFilePath(rcvDirname, "bin");

	if( filePath == "" ) {
		return false;
	}

	if( !Connect() ) {
		return false;
	}

	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x00);

	if (! AdjustCmd.CmdIssue_Ddm(0x0480, 0x0013, 0, "", filePath)) {
		alert("[0480] A_DEFDET_DATA_READ Command Error !");
	}
	else {
		alert("Get Defdet_DATA File Success");
	}

	Disconnect();

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
function comDefdetWrite(
	fileName
)
{
	if (! WshFs.FileExists(fileName)) {
		alert("Input:" + fileName + " Not Found");
		return false;
	}

	if (! Connect()) {
		return false;
	}
	
	AdjustCmd.DataSize = 0;
	if (! AdjustCmd.CmdIssue_Ddm(0x0480, 0x0014, 0, fileName, "" )){
		alert("[0480] A_DEFDET_DATA_WRITE Command Error ! ");
	}
	else {
		// G_CHK_ERR_PRM で書き込み確認.
		var tempFile = CurrentDir + "\\temp";
		if (! AdjustCmd.CmdIssue_Ddm(0x0404, 0x0002, 0, "", tempFile)) {
			alert("[0404] G_CHK_ERR_PRM Command Error !");
		}
		else {
			// 結果は tmep ファイルに書き出しされているので、読み込み.
			var File = WshFs.OpenTextFile(tempFile, 1, true);
			var result = File.Read(1);	// 1文字読み込み.
			if (result == 0) {		
				// 0:成功/ 1（0以外）:失敗.
				alert("Put Defdet_DATA File Success");
			}
			else {
				alert("[0480] A_DEFDET_DATA_WRITE Command Error !");
			}
			File.Close()
			WshFs.DeleteFile(tempFile);
		}
	}

	Disconnect();

	return true;
}
