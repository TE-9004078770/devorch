var fileReadWriteManagerList = [null, null]


window.addEventListener("load", function() {
	fileReadWriteManagerList[0] = new FileReadWriteManager(1);
	fileReadWriteManagerList[1] = new FileReadWriteManager(2);
	for (let i = 1; i < fileReadWriteManagerList.length+1; i++)
	{
		var ins = GetManagerInstance(i);
		if( settings.get("UIBizWriteDirection"+i) == "pc_2_set" ) {
			ins.direction_pc_2_set.checked = true;
			ins.changeDirection(ins.direction_pc_2_set, i, false);
		}
		else {
			ins.direction_set_2_pc.checked = true;
			ins.changeDirection(ins.direction_set_2_pc, i, false);
		}
		ins.srcPath.value = settings.get("UIBizSrcFile"+i);
		ins.dstPath.value = settings.get("UIBizDstFile"+i);
	}
});

GetManagerInstance = function(id)
{
	return fileReadWriteManagerList[id-1]
}

FileReadWriteManager = function(id)
{
	this.id = id;
	this.direction_pc_2_set = document.getElementById("direction_pc_2_set"+id);
	this.direction_set_2_pc = document.getElementById("direction_set_2_pc"+id);
	this.pre_direction_pc_2_set = this.direction_pc_2_set.checked;
	this.pre_direction_set_2_pc = this.direction_set_2_pc.checked;
	this.srcPath = document.getElementById("srcfile_path"+id);
	this.dstPath = document.getElementById("dstfile_path"+id);
	this.exec = document.getElementById("WriteFile_exe"+id);
	
	this.direction_pc_2_set.addEventListener("click", function() {GetManagerInstance(id).changeDirection(this, id, true);});
	this.direction_set_2_pc.addEventListener("click", function() {GetManagerInstance(id).changeDirection(this, id, true);});

	this.exec.addEventListener("click", function() {GetManagerInstance(id).execReadWrite(id);});

}


FileReadWriteManager.prototype.changeDirection = function(self, id, is_save_settings)
{
	var managerInstance = GetManagerInstance(id);
	if (managerInstance.pre_direction_pc_2_set == true
	&&  self.value == "set_2_pc") {
		var tmp = managerInstance.srcPath.value;
		managerInstance.srcPath.value = managerInstance.dstPath.value;
		managerInstance.dstPath.value = tmp;
	}
	else if (managerInstance.pre_direction_set_2_pc == true
	&&  self.value == "pc_2_set")
	{
		var tmp = managerInstance.srcPath.value;
		managerInstance.srcPath.value = managerInstance.dstPath.value;
		managerInstance.dstPath.value = tmp;
	}
	managerInstance.pre_direction_pc_2_set = managerInstance.direction_pc_2_set.checked;
	managerInstance.pre_direction_set_2_pc = managerInstance.direction_set_2_pc.checked;
	if (is_save_settings == true)
	{
		SaveCurrentValues(id);
	}
}

FileReadWriteManager.prototype.execReadWrite = function(id)
{
	var managerInstance = GetManagerInstance(id);
	if (managerInstance.direction_pc_2_set.checked == true)
	{
		WriteFile2Set(managerInstance.srcPath.value, managerInstance.dstPath.value);
	}
	else {
		WriteFile2Pc(managerInstance.srcPath.value, managerInstance.dstPath.value);
	}
	SaveCurrentValues(id);
}

function SaveCurrentValues(id)
{
	var managerInstance = GetManagerInstance(id);
	if (managerInstance.direction_pc_2_set.checked == true)
	{
		settings.set("UIBizWriteDirection"+id, "pc_2_set");
	}
	else {
		settings.set("UIBizWriteDirection"+id, "set_2_pc");
	}
	settings.set("UIBizSrcFile"+id, managerInstance.srcPath.value);
	settings.set("UIBizDstFile"+id, managerInstance.dstPath.value);
	settings.write();
}



function WriteFile2Pc(
	srcFile,
	dstFile
)
{
	if( !Connect() )
	{
		return false;
	}
	Disconnect();
	let retryCount = 0;

	if (!tryConnect()) {
		if (retryCount >= 10) {
			mintole.alert("AdjustCmd Connect Error!");
			return false;
		}
		retryCount++;
		setTimeout(updateProc, 1000);
		return false;
	} else {
		retryCount = 0;
	}
	_readFile(dstFile, srcFile);
	Disconnect();
}

function WriteFile2Set(
	srcFile,	// PC上の書き込むファイムのパス
	dstFile	// セット上の書き込むファイムのパス
)
{
	if( dstFile.match(/\/usr\/lib\//) ) {
		if( !Connect() ) return false;
		Disconnect();
		// セット上の書き込むファイルパスに"/usr/lib/"が含まれていたら、change_mode.sh 相当の書き換え手順を踏む.
		startSharedObjectUpdate(srcFile, dstFile);
		return true;
	} 

	if( !Connect() ) {
		mintole.error("Fail to connect");
		return false;
	}

	if( FileCtl.FileWrite(dstFile, srcFile) ) {
		mintole.alert("Write File Completed!");
	} else
	{
		mintole.alert("Write File Error!");
	}

	Disconnect();	// 接続断
}

var updateStep;
var retryCount;
var srcObjectPath;
var dstObjectPath;

function startSharedObjectUpdate(
	srcFile,	// PC上の書き込むファイムのパス
	dstFile	// セット上の書き込むファイムのパス
)
{
	updateStep = 1;
	retryCount = 0;

	srcObjectPath = srcFile;
	dstObjectPath = dstFile;

	setTimeout(updateProc, 100);
	return true;
}
function updateProc()
{
	if (!tryConnect()) {
		if (retryCount >= 10) {
			mintole.alert("AdjustCmd Connect Error!");
			return false;
		}
		retryCount++;
		setTimeout(updateProc, 1000);
		return false;
	} else {
		retryCount = 0;
	}
	mintole.debug("updateStep:" + updateStep);
	var ret = true;
	switch (updateStep) {
	case 1:
		ret = _changeBootMode(2);
		break;
	case 2:
		ret = _reboot();
		break;
	case 3:
		ret = _mount();
		break;
	case 4:
		ret = _writeFile(dstObjectPath, srcObjectPath);
		break;
	case 5:
		ret = _changeBootMode(3);
		break;
	case 6:
		ret = _reboot();
		mintole.debug("!!!OK!!!");
		Disconnect();
 		return true;
	}
	if (ret) {
		updateStep++;
		setTimeout(updateProc, 100);
	} else {
		mintole.debug("!!!NG!!!");
	}
	Disconnect();
	return true;
}

function _changeMode(mode)
{
	AdjustCmd.DataSize = 4;
	AdjustCmd.SetParam8(0, 0x01);
	AdjustCmd.SetParam8(1, 0x30 + mode);
	AdjustCmd.SetParam8(2, 0x00);
	AdjustCmd.SetParam8(3, 0x00);
	return AdjustCmd.CmdIssue( 0x0601, 0x4013 );
}
function _prepChangeModeDir()
{
	// for obsolate proc.
	AdjustCmd.DataSize = 4;
	AdjustCmd.SetParam8(0, 0x01);
	AdjustCmd.SetParam8(1, 0x03);
	AdjustCmd.SetParam8(2, 0x00);
	AdjustCmd.SetParam8(3, 0x00);
	AdjustCmd.CmdIssue( 0x0601, 0x4013 );
}
function _changeBootMode(mode)
{
	if ( _changeMode(mode) ) {
		return true;
	}
	// obsolate proc.
	var currentDir = GetCurrentDir();
	var dmodeFile;
	switch (mode) {
	case 2:
		dmodeFile = currentDir + "\\config\\dmode_2"
		break;
	case 3:
		dmodeFile = currentDir + "\\config\\dmode_3"
		break;
	default:
		mintole.alert("Error in changeBootMode()" + "mode=" + mode);
		return false;
	}
	if( !FileCtl.FileWrite("/setting/mode/dmode", dmodeFile) ) {
		_prepChangeModeDir();	// "/setting/mode/dmode"を作成してみる.
		if( !FileCtl.FileWrite("/setting/mode/dmode", dmodeFile) ) {
			mintole.alert(dmodeFile);
			mintole.alert("Write File Error! > /setting/mode/dmode" + "\n" + "Please check whether exists \"/setting/mode/\" on Set.");
			return false;
		}
	}
	var preloadFile = currentDir + "\\config\\preload"
	if( !FileCtl.FileWrite("/setting/mode/preload", preloadFile) ) {
		mintole.alert("Write File Error! > /setting/mode/preload");
		return false;
	}
	return true;
}
function _reboot()
{
	// Reboot
	AdjustCmd.DataSize = 0;
	AdjustCmd.CmdIssue( 0x0D01, 0x4050 );

	return true;
}
function _readFile(dst, src)
{
	mintole.debug("write " + src + " to " + dst);
	if (FileCtl.FileRead(dst, src)) {
		mintole.alert("Write File Completed!");
	} else
	{
		mintole.alert("Write File Error!");
	}

	return true;
}

function _writeFile(dst, src)
{
	mintole.debug("write " + src + " to " + dst);
	if (FileCtl.FileWrite(dst, src)) {
		mintole.alert("Write File Completed!");
	} else
	{
		mintole.alert("Write File Error!");
	}

	return true;
}
function _mount()
{
	// ターミナル接続用のサーバ起動
	AdjustCmd.CreateTermSrv( 0, 5001 );
	AdjustCmd.DataSize = 2;
	AdjustCmd.SetParam8( 0, 0x02 );
	AdjustCmd.SetParam8( 1, 0x02 );
	AdjustCmd.CmdIssue( 0x0601, 0x801F );

	// ttlマクロ実行
	var wsh = new ActiveXObject("WScript.Shell");
	var fso = new ActiveXObject("Scripting.FileSystemObject");

	var localPath = wsh.CurrentDirectory;
	var exePath 　= "c:\\Program Files (x86)\\teraterm\\ttpmacro.exe"
	// var ttlPath 　= localPath + "\\resource\\TeraTerm\\mount.ttl";
	var ttlPath 　= localPath + "\\TeraTerm\\mount.ttl";

	// ttlPath 　= localPath + "\\resource\\TeraTerm\\mount.ttl";
	ttlPath 　= localPath + "\\TeraTerm\\mount.ttl";
	if( fso.FileExists( ttlPath )){
		wsh.run( "\"" + exePath + "\"" + " " + "\"" + ttlPath + "\"", 0, true );
	}
	else{
		mintole.alert("mount.ttl is not exist!! ");
	}
	delete fso;
	delete wsh;

	return true;
}
function tryConnect()
{
	connectNestNum++;
	mintole.debug("Connect: " + connectNestNum);

	AdjustCmd	= new ActiveXObject("EXSComIf.AdjustCtrl.1");
	FileCtl 	= new ActiveXObject("EXSComIf.FileControl.1");
	FirmUpCtl	= new ActiveXObject("EXSComIf.FirmupCtrl.1");
	MemDump 	= new ActiveXObject("EXSComIf.MemoryDump.1");

	var USBDevice = "USB0";
	if (! AdjustCmd.Connect(USBDevice)) {
		USBDevice = "USB1";
		if (! AdjustCmd.Connect(USBDevice)) {
			USBDevice = "USB2";
			if (! AdjustCmd.Connect(USBDevice)) {
				USBDevice = "USB3";
				if (! AdjustCmd.Connect(USBDevice)) {
					USBDevice = "USB4";
					if (! AdjustCmd.Connect(USBDevice)) {
						Disconnect();
						return false;
					}
				}
			}
		}
	}

	if (! FileCtl.Connect(USBDevice)) {
		mintole.alert("FileCtl Connect Error!");
		Disconnect();
		return false;
	}

	if (! FirmUpCtl.Connect(USBDevice)) {
		mintole.alert("FirmUpCtl Connect Error!");
		Disconnect();
		return false;
	}

	if (! MemDump.Connect(USBDevice)) {
		mintole.alert("MemoryDump Connect Error!");
		Disconnect();
		return false;
	}

	return true;
}
