langData = {
	// change_lang
	"change_lang":{
		"ja":"ChangeLang",
		"en":"言語変換"
	},

	// tool_title
	"tool_title":{
		"ja":"Diadem ファーム確認スクリプト Mint",
		"en":"Firm Check Script Mint For Diadem"
	},
	
	// changeMainFunc
	"COMBTN":{
		"ja":"共通",
		"en":"Common"
	},
	"DBG1BTN":{
		"ja":"デバッグ１",
		"en":"Debug1"
	},
	"DBG2BTN":{
		"ja":"デバッグ２",
		"en":"Debug2"
	},
	
	// ChangeFunc
	"SMCBTN":{
		"ja":"SubMicon",
		"en":"SubMicon"
	},
	"UBZBTN":{
		"ja":"UIBiz",
		"en":"UIBiz"
	},
	"ADDBTN":{
		"ja":"アドオン",
		"en":"Add-on"
	},
	
	//--------------------------------------------------------------------
	// Common
	//--------------------------------------------------------------------
	// Version Info
	"VersionInfo_title":{
		"ja":"バージョン情報",
		"en":"Version Info"
	},
	"VersionInfo_SetVer":{
		"ja":"セット=",
		"en":"SET="
	},
	"VersionInfo_MachineVer":{
		"ja":"機種情報=",
		"en":"Model="
	},
	"VersionInfo_DestVer":{
		"ja":"仕向情報=",
		"en":"Market="
	},
	"VersionInfo_btn":{
		"ja":"バージョン取得",
		"en":"Get Version Info"
	},
	"VersionInfo_rstbtn":{
		"ja":"表示リセット",
		"en":"Reset Display"
	},
	
	// Get Log
	"GetLog_title":{
		"ja":"ログとりツール",
		"en":"Get Log"
	},
	"GetLog_makeZip_label":{
		"ja":"取得したログをZIP化",
		"en":"Pack logs as a ZIP"
	},
	"GetLog_SSDI_label":{
		"ja":"Snapshot Debug Imageを取得",
		"en":"Get Snapshot Debug Image"
	},
	"GetLogCore_on_label":{
		"ja":"Coreファイルを取得（2分程度固まります）",
		"en":"Get Core files (hung-up for about 2 mins)"
	},
	"GetLogCodec_on_label":{
		"ja":"Codecログを取得（取得後は記録/再生不可）",
		"en":"Get Codec log (getting rec/play unusable)"
	},
	"GetLog_selectList_title":{
		"ja":"ログ取得対象",
		"en":"Get Log Items"
	},
	"GetLog_selectlist_selectall_label_str":{
		"ja":"全選択",
		"en":"Select all"
	},
	"GetLog_output":{
		"ja":"出力先：",
		"en":"Save Folder:"
	},
	"GetLog_exec":{
		"ja":"実行",
		"en":"Exec"
	},
	"GetLog_escpdel":{
		"ja":"退避ログ削除",
		"en":"Delete Escape Log"
	},
	
	// Backup File
	"Backup_title":{
		"ja":"バックアップファイル",
		"en":"Backup File"
	},
	"Backup_save":{
		"ja":"保存先",
		"en":"Save"
	},
	"Backup_data":{
		"ja":".\\backup",
		"en":".\\backup"
	},
	"Backup_brows":{
		"ja":"参照",
		"en":"Brows"
	},
	"Backup_read":{
		"ja":"読出",
		"en":"Exec"
	},
	"Backup_load":{
		"ja":"読込元",
		"en":"Write"
	},
	"Backup_Labelexadj":{
		"ja":"調整値以外全て",
		"en":"Excluding Adjust Value"
	},
	"Backup_Labelall":{
		"ja":"全て",
		"en":"ALL"
	},
	"Backup_Labeladj":{
		"ja":"調整値のみ",
		"en":"Adjust Value"
	},
	"Backup_write":{
		"ja":"書込",
		"en":"Exec"
	},
	"Backup_supp":{
		"ja":"書込み後は値反映のためにAC or BATT OFF/ONが必要です。<br>(Sus/Res禁止)",
		"en":"After Writing: AC or BATT OFF/ON Is Necessary For The Value Reflection.<br>(Power supply OFF/ON is prohibited)"
	},
	
	// 1. Update Mode
	"UpdateMode_title":{
		"ja":"1. Updateモード",
		"en":"1. Update Mode"
	},
	
	// FirmUpHelp
	"FirmUpHelp_str":{
		"ja":"↓ ONしたらAC OFF/ON",
		"en":"↓ Please AC OFF/ON When Update Mode On"
	},
	
	// 2. Firm Update
	"Firmup_title":{
		"ja":"2. ファームアップデート",
		"en":"2. Firm Update"
	},
	"Firmup_firmList":{
		"ja":"ファーム一覧取得",
		"en":"Get Firm List"
	},
	"Firmup_firmkeep_label":{
		"ja":"取得したファームを保持する",
		"en":"Keep gotten firmware"
	},
	"Firmup_start":{
		"ja":"開始",
		"en":"Go"
	},
	"Firmup_startNoreset":{
		"ja":"開始(再起動なし)",
		"en":"Go (Not Auto Restart)"
	},
	"Firmup_description_title":{
		"ja":"【説明】",
		"en":"[summary]",
	},
	"Firmup_description_content":{
		"ja":"・MintToolに接続中のデバイスに対してファームウェアをアップデートします<br>・「ファーム一覧取得」を押下すると、接続しているセットに合ったファーム一覧を取得します<br>",
		"en":"MintTool Going To Update Firmware To Connected Device.<br>Push \"Get Firm List\", then you can get firmware list for connecting Set<br>"
	},
	"Firmup_caution_title":{
		"ja":"【補足】",
		"en":"[caution]",
	},
	"Firmup_caution_content":{
		"ja":"・ 必ずメディアを抜いてから実行してください<br>",
		"en":"You MUST Eject Removable Media From Connected Device.<br>"
	},
	
	// FirmUpHelp1
	"FirmUpHelp1_str":{
		"ja":"↓自動で立ち上がるのを確認して",
		"en":"↓ When Auto Wake Up: Next"
	},
	"UartInput_title":{
		"ja":"3. UART 入力 有効化",
		"en":"3. UART INPUT ENABLE"
	},
	"UartInput_Enable":{
		"ja":"UART 入力 有効化",
		"en":"UART INPUT ENABLE"
	},
	"UartInput_supp":{
		"ja":"【説明】<br>・実行すると次回起動時からUARTからの入力が可能になります。<br>",
		"en":"[summary]<br>When Executed: Input From The UART Becomes Possible Next Wake Up.<br>"
	},
	
	// 3. PresetInitializer
	"Preset_title":{
		"ja":"4. 代表仕向のBackupを適用",
		"en":"4. Apply backup for main-destination"
	},
	"InitPreset_exe":{
		"ja":"Backup適用＆ソフトリセット",
		"en":"Apply backup & soft-reset"
	},
	"InitPreset_note":{
		"ja":"※ エラー発生時はPresetInitializerを使用して下さい。<br>",
		"en":"* If an error occurs: please use PresetInitializer manually.<br>"
	},
	
	// FirmUpHelp2
	"FirmUpHelp2_str":{
		"ja":"AC OFF/ON",
		"en":"Please AC OFF/ON"
	},
	
	// 3. PresetInitializer
	"PGScript_title":{
		"ja":"5. パタジェネスクリプトを実行",
		"en":"5. PG Script"
	},
	"PGScript_caution":{
		"ja":"※シス確のみ必要な操作です",
		"en":"* only for Syskaku"
	},
	
	//--------------------------------------------------------------------
	// Debug
	//--------------------------------------------------------------------
	// KEMCO
	"Kemco_title":{
		"ja":"KEMCO",
		"en":"KEMCO"
	},
	"Kemco_output":{
		"ja":"保存先",
		"en":"Save"
	},
	"Kemco_input":{
		"ja":"読込先",
		"en":"Write"
	},
	"Kemco_dir":{
		"ja":".\\kemco",
		"en":".\\kemco"
	},
	"Kemco_get":{
		"ja":"取得",
		"en":"GET"
	},
	"Kemco_put":{
		"ja":"配置",
		"en":"PUT"
	},
	"Kemco_caution":{
		"ja":"配置後、SSB機能を持つ機種はSSBIの再作成が必要です",
		"en":"After put: SET corresponding with SSB must re-create SSBI."
	},
	
	// TOMCO
	"Tomco_title":{
		"ja":"TOMCO",
		"en":"TOMCO"
	},
	"Tomco_output":{
		"ja":"保存先",
		"en":"Save"
	},
	"Tomco_input":{
		"ja":"読込先",
		"en":"Write"
	},
	"Tomco_dir":{
		"ja":".\\tomco",
		"en":".\\tomco"
	},
	"Tomco_get":{
		"ja":"取得",
		"en":"GET"
	},
	"Tomco_put":{
		"ja":"配置",
		"en":"PUT"
	},
	"Tomco_caution":{
		"ja":"設定を反映させるには再起動する必要があります。",
		"en":"To reflect the setting: you must reboot."
	},
	
	// Escape Log
	"EscapeLog_title":{
		"ja":"退避ログ機能",
		"en":"Escape Log"
	},
	"EscapeLog_exe":{
		"ja":"実行",
		"en":"Exec"
	},
	
	// Deadlock Monitoring
	"DeadlockMonitoring_title":{
		"ja":"デッドロック監視",
		"en":"Deadlock Monitoring"
	},
	"Monitoring_off":{
		"ja":"監視無効／--　（ICE使用者）",
		"en":"Monitoring Off／-- （ICE user）"
	},
	"DeadlockMonitoring_exe":{
		"ja":"実行",
		"en":"Exec"
	},
	
	// Exception/WDT Reboot
	"UrgentReboot_title":{
		"ja":"緊急再起動モード",
		"en":"Exception/WDT Reboot"
	},
	"UrgentReboot_exe":{
		"ja":"実行",
		"en":"Exec"
	},
	"UrgentReboot_caution":{
		"ja":"SSB機能を持つ機種は、SSBIの再作成が必要です。 ",
		"en":"SET corresponding with SSB must re-create SSBI."
	},
	
	// UART From Jig
	"UART_title":{
		"ja":"治具/検端からのUART入出力",
		"en":"UART From Jig"
	},
	"UART_exe":{
		"ja":"実行",
		"en":"Exce"
	},
	"UART_caution":{
		"ja":"利用にはリセット治具/検端が必要です。<br>SSB機能を持つ機種はSSBIの再作成が必要です。 ",
		"en":"Need Reset Jig or KENTAN If You Use.<br>SET corresponding with SSB must re-create SSBI."
	},
	"UART_Labelon_MPCP":{
		"ja":"MP+CP <font size=\"2\" color=\"red\">*DBG-1003専用</font>",
		"en":"MP+CP <font size=\"2\" color=\"red\">*Only for DBG-1003</font>"
	},

	
	// Core Dump
	"CoreDump_title":{
		"ja":"コアダンプ機能",
		"en":"Core Dump"
	},
	"CoreDump_exe":{
		"ja":"実行",
		"en":"Exec"
	},
	"CoreDump_caution":{
		"ja":"SSB機能を持つ機種はSSBIの再作成が必要です。 ",
		"en":"SET corresponding with SSB must re-create SSBI."
	},
	
	// Heap Profile Function
	"HeapProfile_title":{
		"ja":"Heap Profile機能",
		"en":"Heap Profile Function"
	},
	"HeapProfile_record":{
		"ja":"レコード数",
		"en":"Records Count"
	},
	"HeapProfile_read":{
		"ja":"読込",
		"en":"READ"
	},
	"HeapProfile_write":{
		"ja":"書込",
		"en":"WRITE"
	},
	"HeapProfile_caution":{
		"ja":"書込後、SSB機能を持つ機種はSSBIの再作成が必要です。 ",
		"en":"After write: SET corresponding with SSB must re-create SSBI."
	},
	
	// SnapShotBootFunction 
	"SnapShotBoot_title":{
		"ja":"Snapshot Boot機能",
		"en":"Snapshot BootFunction"
	},
	"SnapShotBoot_on":{
		"ja":"SSBI作成",
		"en":"SSBI CREATE"
	},
	"SnapShotBoot_off":{
		"ja":"SSBI無効化",
		"en":"SSBI DISABLE"
	},
	"SnapShotBootFunctionHelp_str":{
		"ja":"手動で再起動後、一度自動で再起動が行われます<br>CA搭載機種の場合はSSBI作成後にデッドロック監視設定を実行してください(RC後=量産向け設定/RC前=Testing用)",
		"en":"<br>After manually reboot: reboot again will be performed automatically.<br>In the case of CA model: please re-set Deadlock Monitoring after creating SSBI.<br>After RC:Monitoring On／Auto Reboot (for Mass-Production)<br>Before RC:Monitoring On／Manual Reboot (for Testing)"
	},
	
	// SnapShotBootImage
	"Ssb_output":{
		"ja":"保存先",
		"en":"Save"
	},
	"Ssb_get":{
		"ja":"取得",
		"en":"GET"
	},
	
	// HotBoot
	"HotBoot_exe":{
		"ja":"実行",
		"en":"Exce"
	},
	"HotBoot_supp":{
		"ja":"ハードが対応しているか確認して実行してください。",
		"en":"Please Check Is Hardware Compatible This Feature"
	},
	
	// Thread Monitor
	"ThreadMonitor_title":{
		"ja":"Thread Monitorログ取得(CP)",
		"en":"Thread Monitor Log (CP)"
	},
	"ThreadMonitor_address":{
		"ja":"アドレス",
		"en":"Address"
	},
	"ThreadMonitor_size":{
		"ja":"サイズ",
		"en":"Size"
	},
	"ThreadMonitor_addrRead":{
		"ja":"アドレス読込",
		"en":"Set Address"
	},
	"ThreadMonitor_read":{
		"ja":"読込",
		"en":"READ"
	},
	
	// Snapshot Debug Image
	"ssdi_create_rst_title":{
		"ja":"リセット時SSDI作成：",
		"en":"SSDI Create by Reset: "
	},
	"ssdi_create_rst_on_label":{
		"ja":"ON",
		"en":"ON"
	},
	"ssdi_create_rst_off_label":{
		"ja":"OFF",
		"en":"OFF"
	},
	"ssdi_create_rst_set":{
		"ja":"設定",
		"en":"Exec"
	},
	"SnapshotDebug_title":{
		"ja":"Snapshot Debug Image（CP）",
		"en":"Snapshot Debug Image (CP)"
	},
	"SnapshotDebug_delete":{
		"ja":"削除",
		"en":"DELETE"
	},
	"SnapshotDebug_read":{
		"ja":"取得",
		"en":"READ"
	},
	
	// Software Reset
	"SoftReset_title":{
		"ja":"ソフトリセット",
		"en":"Software Reset"
	},
	"SoftReset_exe":{
		"ja":"実行",
		"en":"Exec"
	},
	
	// SENSER Mode
	"SenserMode_title":{
		"ja":"SENSERモード",
		"en":"SENSER Mode"
	},
	"SenserMode_Labelnormal":{
		"ja":"Normal",
		"en":"Normal"
	},
	"SenserMode_Labelusb":{
		"ja":"強制USB",
		"en":"Force USB"
	},
	"SenserMode_exe":{
		"ja":"実行",
		"en":"Exec"
	},
	
	// Factory Check Mode
	"FactoryCheck_title":{
		"ja":"調整検査モード",
		"en":"Factory Check Mode"
	},
	"FactoryCheck_exe":{
		"ja":"実行",
		"en":"Exec"
	},
	
	// Terminal Mode
	"TerminalMode_title":{
		"ja":"ターミナルモード",
		"en":"Terminal Mode"
	},
	"TerminalMode_exe":{
		"ja":"実行",
		"en":"Exec"
	},
	
	// APO Function
	"Apo_title":{
		"ja":"APO 機能",
		"en":"APO Function"
	},
	"Apo_exe":{
		"ja":"実行",
		"en":"Exec"
	},
	
	// Setting Info
	"SettingInfo_title":{
		"ja":"設定情報",
		"en":"Setting Info"
	},
	"SettingInfo_senser":{
		"ja":"SENSERモード",
		"en":"SENSER Mode"
	},
	"SettingInfo_log":{
		"ja":"退避ログ機能",
		"en":"Escape Log Feature"
	},
	"SettingInfo_reboot":{
		"ja":"緊急再起動モード",
		"en":"Emergency Reboot"
	},
	"SettingInfo_uart":{
		"ja":"UART通信モード",
		"en":"UART Comm Mode"
	},
	"SettingInfo_dispbtn":{
		"ja":"設定情報取得",
		"en":"Get Setting Info"
	},
	"SettingInfo_resetbtn":{
		"ja":"表示リセット",
		"en":"Reset Display"
	},
	
	// PSD Data (Mario)
	"Mario_title":{
		"ja":"受光角度分布調整データ",
		"en":"PSD Data"
	},
	"Mario_save":{
		"ja":"保存先",
		"en":"Save"
	},
	"Mario_data":{
		"ja":".\\mario",
		"en":".\\mario"
	},
	"Mario_brows":{
		"ja":"参照",
		"en":"Brows"
	},
	"Mario_read":{
		"ja":"読出",
		"en":"Exec"
	},
	"Mario_load":{
		"ja":"読込元",
		"en":"Write"
	},
	"Mario_write":{
		"ja":"書込",
		"en":"Exec"
	},
	
	// Defdet Data (Defdet)
	"Defdet_title":{
		"ja":"欠陥調整データ",
		"en":"Defdet Data"
	},
	"Defdet_save":{
		"ja":"保存先",
		"en":"Save"
	},
	"Defdet_data":{
		"ja":".\\defdet",
		"en":".\\defdet"
	},
	"Defdet_brows":{
		"ja":"参照",
		"en":"Brows"
	},
	"Defdet_read":{
		"ja":"読出",
		"en":"Exec"
	},
	"Defdet_load":{
		"ja":"読込元",
		"en":"Write"
	},
	"Defdet_write":{
		"ja":"書込",
		"en":"Exec"
	},
	
	//--------------------------------------------------------------------
	// SubMicon
	//--------------------------------------------------------------------
	// SubFunction
	"tab_lens":{
		"ja":"LENS",
		"en":"LENS"
	},
	
	// Darwin - Version Infomation
	"DarwinVer_title":{
		"ja":"バージョン情報",
		"en":"Version Info"
	},
	"DarwinVer_getbtn":{
		"ja":"バージョン取得",
		"en":"Get Version"
	},
	"DarwinVer_resetbtn":{
		"ja":"表示リセット",
		"en":"Clear"
	},
	
	// Darwin - Mecha Setting
	"DarwinTool_title":{
		"ja":"Darwin メカ設定",
		"en":"Darwin Mecha Setting"
	},
	"DarwinTool_all":{
		"ja":"自動設定 :",
		"en":"Auto Setting :"
	},
	"DarwinTool_allonbtn":{
		"ja":"全有効",
		"en":"ALL Enable"
	},
	"DarwinTool_alloffbtn":{
		"ja":"全無効",
		"en":"ALL Disable"
	},
	"DarwinTool_shtType":{
		"ja":"シャッタータイプ :",
		"en":"Shutter type :"
	},
	"DarwinTool_shtType_onbtn":{
		"ja":"有効",
		"en":"Enable"
	},
	"DarwinTool_shtType_offbtn":{
		"ja":"無効",
		"en":"Disable"
	},
	"DarwinTool_shtType_chgbtn":{
		"ja":"パラメータ変更",
		"en":"Change Param"
	},
	"DarwinTool_shtPi":{
		"ja":"シャッターPIタイプ :",
		"en":"Shutter PI type :"
	},
	"DarwinTool_shtPi_onbtn":{
		"ja":"有効",
		"en":"Enable"
	},
	"DarwinTool_shtPi_offbtn":{
		"ja":"無効",
		"en":"Disable"
	},
	"DarwinTool_shtPi_chgbtn":{
		"ja":"パラメータ変更",
		"en":"Change Param"
	},
	"DarwinTool_intStrobe":{
		"ja":"内蔵ストロボ有無 :",
		"en":"Inner Strobe :"
	},
	"DarwinTool_intStrobe_onbtn":{
		"ja":"有効",
		"en":"Enable"
	},
	"DarwinTool_intStrobe_offbtn":{
		"ja":"無効",
		"en":"Disable"
	},
	"DarwinTool_intStrobe_chgbtn":{
		"ja":"パラメータ変更",
		"en":"Change Param"
	},
	"DarwinTool_strobePopup":{
		"ja":"ストロボポップアップ有無 :",
		"en":"Strobe Pup-Up :"
	},
	"DarwinTool_strobePopup_onbtn":{
		"ja":"有効",
		"en":"Enable"
	},
	"DarwinTool_strobePopup_offbtn":{
		"ja":"無効",
		"en":"Disable"
	},
	"DarwinTool_strobePopup_chgbtn":{
		"ja":"パラメータ変更",
		"en":"Change Param"
	},
	"DarwinTool_extStrobe":{
		"ja":"外付けストロボ有無 :",
		"en":"External Strobe :"
	},
	"DarwinTool_extStrobe_onbtn":{
		"ja":"有効",
		"en":"Enable"
	},
	"DarwinTool_extStrobe_offbtn":{
		"ja":"無効",
		"en":"Disable"
	},
	"DarwinTool_extStrobe_chgbtn":{
		"ja":"パラメータ変更",
		"en":"Change Param"
	},
	"DarwinTool_syncTerm":{
		"ja":"シンクロターミナル :",
		"en":"Syncro Terminal :"
	},
	"DarwinTool_syncTerm_onbtn":{
		"ja":"有効",
		"en":"Enable"
	},
	"DarwinTool_syncTerm_offbtn":{
		"ja":"無効",
		"en":"Disable"
	},
	"DarwinTool_syncTerm_chgbtn":{
		"ja":"パラメータ変更",
		"en":"Change Param"
	},
	"DarwinTool_battTerm":{
		"ja":"筐体温度取得 :",
		"en":"Battery Thermal :"
	},
	"DarwinTool_battTerm_onbtn":{
		"ja":"有効",
		"en":"Enable"
	},
	"DarwinTool_battTerm_offbtn":{
		"ja":"無効",
		"en":"Disable"
	},
	"DarwinTool_battTerm_chgbtn":{
		"ja":"パラメータ変更",
		"en":"Change Param"
	},
	"DarwinTool_virGrip":{
		"ja":"縦位置グリップ有無 :",
		"en":"Virtical grip :"
	},
	"DarwinTool_virGrip_onbtn":{
		"ja":"有効",
		"en":"Enable"
	},
	"DarwinTool_virGrip_offbtn":{
		"ja":"無効",
		"en":"Disable"
	},
	"DarwinTool_virGrip_chgbtn":{
		"ja":"パラメータ変更",
		"en":"Change Param"
	},
	"DarwinTool_caution":{
		"ja":"デバイスごとの個別設定の利用は、<br>各自の責任の元に設定をお願いいたします",
		"en":"You MUST use this function that set individually for each device <br>in your responsibility."
	},
	
	// LENS - Version Infomation
	"LensVer_title":{
		"ja":"バージョン情報",
		"en":"Version Info"
	},
	"LensVer_getbtn":{
		"ja":"バージョン取得",
		"en":"Get Version"
	},
	"LensVer_resetbtn":{
		"ja":"表示リセット",
		"en":"Clear"
	},
	
	// kemco caution
	"end_kemco":{
		"ja":"※設定を反映させるには再起動する必要があります。",
		"en":"To reflect the setting: you must reboot."
	},
	
	// ares caution
	"end":{
		"ja":"※このスクリプトの利用には、AresDdmに添付regist.batを一度実行する必要があります。",
		"en":"You MUST Exec regist.bat (AresDdm Has It) At Least Once."
	},
	
	//--------------------------------------------------------------------
	// UIBiz
	//--------------------------------------------------------------------
	"WriteFile_title":{
		"ja":"ファイル書き込み1",
		"en":"Write File 1"
	},
	"WriteFile2_title":{
		"ja":"ファイル書き込み2",
		"en":"Write File 2"
	},
	"WriteFile_exe1":{
		"ja":"実行",
		"en":"Exec"
	},
	"WriteFile_exe2":{
		"ja":"実行",
		"en":"Exec"
	},
	"SaveExplaination1":{
		"ja":"実行を押すかラジオボタンを選択すると現在値が保存されます",
		"en":"Save current values when click Exec or ratio button."
	},
	"SaveExplaination2":{
		"ja":"実行を押すかラジオボタンを選択すると現在値が保存されます",
		"en":"Save current values when click Exec or ratio button."
	},
	//--------------------------------------------------------------------
	// Confirmation dialog when SYSKAKU firmware update
	//--------------------------------------------------------------------
	"ConfirmSysUpdate_ThisFirm":{
		"ja":"このファームは",
		"en":"This firm is"
	},
	"ConfirmSysUpdate_Confirm":{
		"ja":"アップデート実行しますか？",
		"en":"Execute update?"
	},
	"ConfirmSysUpdate_caution":{
		"ja":"です",
		"en":""
	},
	"ConfirmSysUpdate_btnCancel":{
		"ja":"キャンセル",
		"en":"Cancel"
	},
	"ConfirmSysUpdate_btnExec":{
		"ja":"実行",
		"en":"Execute"
	},
	
}
