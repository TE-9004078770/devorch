var AdjustCmd = null;
// var ProductInfo = null;	// For EX
// var MicomAcc = null;	// For EX
var FileCtl = null;
var FirmUpCtl = null;
var MemDump = null;
var connectNestNum = 0;

/*================================================================================
 * Connect
================================================================================*/
function Connect()
{
	connectNestNum++;
	mintole.debug("Connect: " + connectNestNum);

	AdjustCmd	= new ActiveXObject("EXSComIf.AdjustCtrl.1");
	// ProductInfo = new ActiveXObject("EXSComIf.ProductInfo.1");
	// MicomAcc	= new ActiveXObject("EXSComIf.MicomAcc.1");
	FileCtl 	= new ActiveXObject("EXSComIf.FileControl.1");
	FirmUpCtl	= new ActiveXObject("EXSComIf.FirmupCtrl.1");
	MemDump 	= new ActiveXObject("EXSComIf.MemoryDump.1");

	var USBDevice = "USB0";
	if (! AdjustCmd.Connect(USBDevice)) {
		USBDevice = "USB1";
		if (! AdjustCmd.Connect(USBDevice)) {
			USBDevice = "USB2";
			if (! AdjustCmd.Connect(USBDevice)) {
				USBDevice = "USB3";
				if (! AdjustCmd.Connect(USBDevice)) {
					USBDevice = "USB4";
					if (! AdjustCmd.Connect(USBDevice)) {
						
						mintole.alert("AdjustCmd Connect Error!");
						Disconnect();

						return false;
					}
				}
			}
		}
	}

	// if (! ProductInfo.Connect(USBDevice)) {
	// 	mintole.alert("ProductInfo Connect Error!");
	// 	Disconnect();
	// 	return false;
	// }

	// if (! MicomAcc.Connect(USBDevice)) {
	// 	mintole.alert("MicomAcc Connect Error!");
	// 	Disconnect();
	// 	return false;
	// }

	if (! FileCtl.Connect(USBDevice)) {
		mintole.alert("FileCtl Connect Error!");
		Disconnect();
		return false;
	}

	if (! FirmUpCtl.Connect(USBDevice)) {
		mintole.alert("FirmUpCtl Connect Error!");
		Disconnect();
		return false;
	}

	if (! MemDump.Connect(USBDevice)) {
		mintole.alert("MemoryDump Connect Error!");
		Disconnect();
		return false;
	}

	return true;
}

/*================================================================================
 * Disconnect
================================================================================*/
function Disconnect()
{
	if( connectNestNum > 0 ) { connectNestNum--; }
	mintole.debug("Disconnect: " + connectNestNum);
	
	delete AdjustCmd;
	delete ProductInfo;
	delete MicomAcc;
	delete FileCtl;
	delete FirmUpCtl;
	delete MemDump;

	// AdjustCmd = null;
	// ProductInfo = null;
	// MicomAcc = null;
	// FileCtl = null;
	// FirmUpCtl = null;
	// MemDump = null;

	return true;
}

/*================================================================================
 * Is already connected
================================================================================*/
function IsConnected()
{
	return (AdjustCmd && /*ProductInfo && MicomAcc &&*/ FileCtl && FirmUpCtl && MemDump);
}
