
var DEFAULT_SETTING_FILE_PATH = ".\\resource\\default_settings.json";
var SETTING_FILE_PATH = ".\\settings.json";
var settings = null;

/*================================================================================
 * Initialize
================================================================================*/
window.addEventListener("load", function() {
	settings = new SettingManager();
	settings.read();
});


/*================================================================================
 * Setting Manager Class
================================================================================*/
var SettingManager = function() {
	this.settingData = {};
	
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	if( !fso.FileExists(SETTING_FILE_PATH) ) {
		try {
			fso.CopyFile(DEFAULT_SETTING_FILE_PATH, SETTING_FILE_PATH);
			if( mintole ) { mintole.debug("Copied setting file from default"); }
		}
		catch(e) {
			if( mintole ) { mintole.error("Fail to initialize setting file"); }
		}
	}
	delete fso;
}

/*--------------------------------------------------------------------------------
 * Read setting file
--------------------------------------------------------------------------------*/
SettingManager.prototype.read = function()
{
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	if( fso.FileExists(SETTING_FILE_PATH) ) {
		var file = fso.OpenTextFile(SETTING_FILE_PATH, 1);

		if( !file.AtEndOfStream ) {
			try {
				this.settingData = JSON.parse(file.ReadAll());
			}
			catch(e) {
				mintole.error("Fail to read setting file");
			}
		}

		file.Close();
		delete file;
	}
	delete fso;
}

/*--------------------------------------------------------------------------------
 * Write setting file
--------------------------------------------------------------------------------*/
SettingManager.prototype.write = function()
{
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	var file = fso.OpenTextFile(SETTING_FILE_PATH, 2, true);
	try {
		file.Write(JSON.stringify(this.settingData));
	}
	catch(e) {
		mintole.error("Fail to write setting file");
	}
	file.Close();
	delete file;
	delete fso;
}

/*--------------------------------------------------------------------------------
 * Get setting value
--------------------------------------------------------------------------------*/
SettingManager.prototype.get = function(key)
{
	try {
		return this.settingData[key];
	}
	catch(e) {
		return undefined;
	}
}

/*--------------------------------------------------------------------------------
 * Set setting value
--------------------------------------------------------------------------------*/
SettingManager.prototype.set = function(key, value)
{
	this.settingData[key] = value;
}

/*--------------------------------------------------------------------------------
 * Set setting value by Element
--------------------------------------------------------------------------------*/
SettingManager.prototype.setByElm = function(key, elm)
{
	var value = "";

	switch( elm.tagName.toLowerCase() ) {
	case "input":
		switch( elm.type.toLowerCase() ) {
		case "radio":
			var name = elm.name;
			var elms = document.getElementsByName(name);
			for( var i = 0; i < elms.length; i++ ) {
				var elm = elms[i];
				if( elm.checked ) {
					value = elm.value;
					break;
				}
			}
			break;
		case "checkbox":
			value = elm.checked ? true : false;
			break;
		default:
			value = elm.value;
			break;
		}
		break;
	case "select":
		value = elm.value;
		break;
	default:
		mintole.error("SettingManager Error: Not supporting element for [setByElm]");
		break;
	}
	this.set(key, value);

	return value;
}

/*--------------------------------------------------------------------------------
 * Set setting value To Element
--------------------------------------------------------------------------------*/
SettingManager.prototype.setToElm = function(key, elm)
{
	var value = this.get(key);

	switch( elm.tagName.toLowerCase() ) {
	case "input":
		switch( elm.type.toLowerCase() ) {
		case "radio":
			var name = elm.name;
			var elms = document.getElementsByName(name);
			for( var i = 0; i < elms.length; i++ ) {
				var elm = elms[i];
				if( elm.value == value ) {
					elm.checked = "checked";
					break;
				}
			}
			break;
		case "checkbox":
			if( value == true ) { elm.checked = "checked"; }
			else { elm.checked = ""; }
			break;
		default:
			elm.value = value;
			break;
		}
		break;
	case "select":
		var elms = elm.getElementsByTagName("option");
		for( var i = 0; i < elms.length; i++ ) {
			var celm = elms[i];
			if( celm.value == value ) {
				elm.selectedIndex = i;
				break;
			}
		}
		break;
	default:
		mintole.error("SettingManager Error: Not supporting element for [setToElm]");
		break;
	}
}

/*--------------------------------------------------------------------------------
 * Register element for setting
--------------------------------------------------------------------------------*/
SettingManager.prototype.__linkElmToKey = function(evt, key, elm) {
	elm.addEventListener(evt, function() {
		settings.setByElm(key, this);
		settings.write();
	});
	this.setToElm(key, elm);
}
SettingManager.prototype.linkElmToKey = function(key, elm)
{
	switch( elm.tagName.toLowerCase() ) {
	case "input":
		switch( elm.type.toLowerCase() ) {
		case "radio":
			var elms = document.getElementsByName(elm.name);
			for( var i = 0; i < elms.length; i++ ) {
				this.__linkElmToKey("click", key, elms[i]);
			}
			break;
		case "checkbox":
			this.__linkElmToKey("click", key, elm);
			break;
		default:
			this.__linkElmToKey("change", key, elm);
			break;
		}
		break;
	case "select":
		this.__linkElmToKey("change", key, elm);
		break;
	default:
		mintole.error("SettingManager Error: Not supporting element for [regElm]");
		break;
	}
}
