
var settingInfo = null;

/*================================================================================
 * Initialize
================================================================================*/
window.addEventListener("load", function() {
	settingInfo = new SettingInfo();
});


/*================================================================================
 * Setting Info Class
================================================================================*/
var SettingInfo = function() {
	this.senserMode = 0xFF;
	this.escapeLogMode = 0xFF;
	this.exceptionRebootMode = 0xFF;
	this.uartMode = 0;
};

/*--------------------------------------------------------------------------------
 * Read setting info
--------------------------------------------------------------------------------*/
SettingInfo.prototype.read = function()
{
	if( !Connect() ) {
		return false;
	}

	// SENSER mode
	AdjustCmd.DataSize = 2;
	AdjustCmd.SetParam8(0, 0x00);
	if( !AdjustCmd.CmdIssue(0x0601, 0x0011) ) {
		this.senserMode = 0xFF;

		mintole.open();
		mintole.error("Read Senser Mode FAIL !");
	} 
	else {
		this.senserMode = AdjustCmd.GetResponse8(0);
	}

	// Escape log mode
	AdjustCmd.DataSize = 4;
	AdjustCmd.SetParam32(0, 0x00510015);
	if( !AdjustCmd.CmdIssue(0x0603, 0x0001) ) {
		this.escapeLogMode = 0xFF;

		mintole.open();
		mintole.error("Escape Log Function: Reading Backup FAIL !");
	}
	else {
		this.escapeLogMode = AdjustCmd.GetResponse8(0);
	}

	Disconnect();

	// Get kemco/tomco
	var kemcoStr = kemReadKemcoFile();
	var tomcoStr = GetTomcoByStr();

	// Reboot with exception
	var strException = "exception.reboot=1";
	if( kemcoStr.indexOf(strException) != -1 ) {
		this.exceptionRebootMode = 1;
	}
	else {
		this.exceptionRebootMode = 0;
	}

	// UART Mode
	var strKemcoConsole = new RegExp(/console=ttyAMA[0-3],\d+n8/);
	var strTomcoConsole = "console_enable=Y";

	this.uartMode = 0;
	if( kemcoStr.search(strKemcoConsole) != -1 ) {
		this.uartMode |= 1;
	}
	if( tomcoStr.indexOf(strTomcoConsole) != -1 ) {
		this.uartMode |= 2;
	}

	return true;
}

/*--------------------------------------------------------------------------------
 * Get SENSER Mode by String
--------------------------------------------------------------------------------*/
SettingInfo.prototype.getSenserModeStr = function()
{
	switch( this.senserMode ) {
	case 0x00:
		return "NORMAL";
		break;
	case 0x01:
		return "Force USB";
		break;
	default:
		mintole.error("SENSER Mode ERROR: " + this.senserMode);
		return "Error!!";
		break;
	}
}

/*--------------------------------------------------------------------------------
 * Get Escape log Mode by String
--------------------------------------------------------------------------------*/
SettingInfo.prototype.getEscapeLogModeStr = function()
{
	switch( this.escapeLogMode ) {
	case 0x00:
		return "OFF";
		break;
	case 0x01:
		return "ON";
		break;
	default:
		mintole.error("Escape log Mode ERROR: " + this.escapeLogMode);
		return "Error!!";
		break;
	}
}

/*--------------------------------------------------------------------------------
 * Get Exception reboot Mode by String
--------------------------------------------------------------------------------*/
SettingInfo.prototype.getExceptionRebootModeStr = function()
{
	switch( this.exceptionRebootMode ) {
	case 0:
		return "Exception Reboot OFF";
		break;
	case 1:
		return "Exception Reboot ON";
		break;
	default:
		mintole.error("Exception reboot Mode ERROR: " + this.exceptionRebootMode);
		return "Error!!";
		break;
	}
}

/*--------------------------------------------------------------------------------
 * Get UART Mode by String
--------------------------------------------------------------------------------*/
SettingInfo.prototype.getUARTModeStr = function()
{
	switch( this.uartMode ) {
	case 3:
		return "MP+CP";
		break;
	case 2:
		return "CP ON";
		break;
	case 1:
		return "MP ON";
		break;
	case 0:
		return "OFF";
		break;
	default:
		mintole.error("UART Mode ERROR: " + this.exceptionRebootMode);
		return "Error!!";
		break;
	}
}
