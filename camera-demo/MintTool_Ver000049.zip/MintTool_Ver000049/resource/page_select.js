
var TAB_WRAPPER_NAME_LIST = new Array("ChangeMainFunc", "ChangeFunc");
var SUB_TAB_WRAPPER_NAME_LIST = new Array("SubMiconTab");
var PAGE_DIR_NAME = "./resource/page/";

/*================================================================================
 * Tab select action
================================================================================*/
function tabSelect(btnId, classHead, nameList)
{
	for( var i = 0; i < nameList.length; i++ )
	{
		var tabWrapper = document.getElementById(nameList[i]);
		var tabWrapperChildren = tabWrapper.getElementsByTagName("input");
		for( var j = 0; j < tabWrapperChildren.length; j++ )
		{
			var tab = tabWrapperChildren[j];
			if( String(tab.className).indexOf(classHead) == 0 ) {
				if( tab.id == btnId ) {
					tab.className = classHead + "Selected";
				} else {
					tab.className = classHead + "Unselected";
				}
			}
		}
	}
}
function mainTabSelect(btnId) {
	tabSelect(btnId, "BtnMainTab", TAB_WRAPPER_NAME_LIST);
}
function subTabSelect(btnId) {
	tabSelect(btnId, "BtnSubMiconTab", SUB_TAB_WRAPPER_NAME_LIST);
}

/*================================================================================
 * Change page
================================================================================*/
function changePage(btnElm, pageName)
{
	var mainFrame = document.getElementById("main_frame");
	mainFrame.src = PAGE_DIR_NAME + pageName.toLowerCase() + ".html";
	switch (pageName) {
	case "debug1":
	case "debug2":
		// ボタン色設定
		mainTabSelect(btnElm.id);

		// 補足表示設定
		document.getElementById("end_kemco").style.display		 = "block";
		break;

	case "common":
	case "SubMicon":
	case "UIBiz":
	case "addon":
		// ボタン色設定
		mainTabSelect(btnElm.id);
		
		// 補足表示設定
		document.getElementById("end_kemco").style.display		 = "none";
		break;

	default:
		mintole.error("[Page select error] NOT found page name: " + pageName);
		break;
	}
}

/*================================================================================
 * Change sub micon page
================================================================================*/
function changeSubMiconPage(SubMicon)
{
	switch (SubMicon) {
		case "Darwin":
			// 非表示
			document.getElementById("SubMicon_LENS_left").style.display    = "none";
			document.getElementById("SubMicon_LENS_right").style.display   = "none";

			// 表示
			document.getElementById("SubMicon_Darwin_left").style.display  = "block";
			document.getElementById("SubMicon_Darwin_right").style.display = "block";

			// ボタン色設定
			subTabSelect("tab_darwin");
			break;

		case "LENS":
			// 非表示
			document.getElementById("SubMicon_Darwin_left").style.display  = "none";
			document.getElementById("SubMicon_Darwin_right").style.display = "none";

			// 表示
			document.getElementById("SubMicon_LENS_left").style.display    = "block";
			document.getElementById("SubMicon_LENS_right").style.display   = "block";

			// ボタン色設定
			subTabSelect("tab_lens");
			break;

		default:
			mintole.error("[Page select error] NOT found SubMicon page name: " + SubMicon);
			break;
	}
}
