
var CurrentDir = GetCurrentDir();

window.addEventListener("load", function() {
	var baseElm = document.querySelector("base");
	if( baseElm ) {
		CurrentDir = baseElm.href.replace("file:///", "").replace(/\//g, "\\");
	}

	// Move Current directory (for when directly open this tool by IE, not via .hta)
	var WshShell = new ActiveXObject("WScript.Shell");
	WshShell.CurrentDirectory = CurrentDir;
	delete WshShell;
});

///////////////////////////////////////////////////////////////////////////////
// カレントディレクトリ取得
///////////////////////////////////////////////////////////////////////////////
function GetCurrentDir()
{
	return window.location.href.replace("file:///", "").replace(/\/[^/]+$/, "").replace(/\//g, "\\");
}
