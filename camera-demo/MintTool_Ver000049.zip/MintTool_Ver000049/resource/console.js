
var mintole = null;


/*================================================================================
 * Console Manager Class
================================================================================*/
var ConsoleManager = function(master) {
	this.LEVEL = {
		"OFF":0,
		"CRITICAL":1,
		"ALERT":2,
		"ERROR":3,
		"WARNING":4,
		"INFO":5,
		"DEBUG":6,
	};
	this.level = this.LEVEL.OFF;

	if( master ) {
		var bodyElm = document.getElementsByTagName("body")[0];
		this.consoleBlk = bodyElm.appendChild(document.createElement("div"));
		this.consoleBlk.id = this.CONSOLE_ELEMENT_ID;
		
		this.setLevel(settings.get(this.SETTING_CONSOLE_KEY_NAME));
	}
	else {
		this.consoleBlk = parent.document.getElementById(this.CONSOLE_ELEMENT_ID);
		if( !this.consoleBlk ) {
			parent.window.addEventListener("load", function() {
				this.consoleBlk = parent.document.getElementById(this.CONSOLE_ELEMENT_ID);

				this.setLevel(settings.get(this.SETTING_CONSOLE_KEY_NAME));
			}.bind(this));
		}
	}
}
ConsoleManager.prototype.SETTING_CONSOLE_KEY_NAME = "console";
ConsoleManager.prototype.CONSOLE_ELEMENT_ID = "console";

/*--------------------------------------------------------------------------------
 * Get console level
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.getLevel = function()
{
	return this.level;
}

/*--------------------------------------------------------------------------------
 * Set console level
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.setLevel = function(level)
{
	if( this.level == level ) { return; }

	var bodyElm = document.getElementsByTagName("body")[0];
	if( level > 0 && this.level == 0 ) {
		bodyElm.style.paddingBottom = "6em";
		this.consoleBlk.style.visibility = "visible";
		this.write("Mint Console is ON<br>");
	}
	else {
		bodyElm.style.paddingBottom = "";
		this.consoleBlk.style.visibility = "hidden";
	}
	this.level = level;
}

/*--------------------------------------------------------------------------------
 * Save console level
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.saveLevel = function()
{
	settings.set(SETTING_CONSOLE_KEY_NAME, this.level);
	settings.write();
}

/*--------------------------------------------------------------------------------
 * Open console
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.open = function()
{
	if( this.level < this.LEVEL.INFO ) {
		this.setLevel(this.LEVEL.INFO);
	}
}

/*--------------------------------------------------------------------------------
 * Close console
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.close = function()
{
	if( this.level != 0 ) {
		this.setLevel(0);
	}
}

/*--------------------------------------------------------------------------------
 * Get date text
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.getDateText = function(date)
{
	return String(date.getFullYear()).slice(-2) + "/"
				+ zerofillBefore(date.getMonth() + 1, 2) + "/"
				+ zerofillBefore(date.getDate(), 2) + "-"
				+ zerofillBefore(date.getHours(), 2) + ":"
				+ zerofillBefore(date.getMinutes(), 2) + ":"
				+ zerofillBefore(date.getSeconds(), 2) + "'"
				+ ( "000" + date.getMilliseconds() ).slice(-3);
}

/*--------------------------------------------------------------------------------
 * Write text
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.write = function(text)
{
	this.consoleBlk.innerHTML += "[" + this.getDateText(new Date()) + "] " + text + "<br>";
	this.consoleBlk.scrollTop = this.consoleBlk.scrollHeight;
}

/*--------------------------------------------------------------------------------
 * Write debug text
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.debug = function(text)
{
	if( this.level < this.LEVEL.DEBUG ) { return; }
	this.write("<span class=\"debug\">[debug] " + text + "</span>");
}

/*--------------------------------------------------------------------------------
 * Write info text
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.info = function(text)
{
	if( this.level < this.LEVEL.INFO ) { return; }
	this.write("<span class=\"info\">[info] " + text + "</span>");
}

/*--------------------------------------------------------------------------------
 * Write warning text
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.warning = function(text)
{
	if( this.level < this.LEVEL.WARNING ) { return; }
	this.write("<span class=\"warning\">[warning] " + text + "</span>");
}

/*--------------------------------------------------------------------------------
 * Write error text
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.error = function(text)
{
	if( this.level < this.LEVEL.ERROR ) { return; }
	this.write("<span class=\"error\">[error] " + text + "</span>");
}

/*--------------------------------------------------------------------------------
 * Write alert text
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.alert = function(text, popup)
{
	if( popup == undefined || popup ) { alert(text); }

	if( this.level < this.LEVEL.ALERT ) { return; }
	this.write("<span class=\"alert\">[alert] " + text + "</span>");
}

/*--------------------------------------------------------------------------------
 * Write critical text
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.critical = function(text)
{
	if( this.level < this.LEVEL.CRITICAL ) { return; }
	this.write("<span class=\"critical\">[critical] " + text + "</span>");
}
