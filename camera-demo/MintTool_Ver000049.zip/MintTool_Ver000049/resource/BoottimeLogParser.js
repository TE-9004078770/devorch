
//==================================================
//	Const definition
//==================================================
const BOOT_TIME_MAGIC = 0x4E554355 + 2;
const BOOT_TIME_ENTRY_TIME_SIZE = 8;
const MAX_COMMENT = 64;


//==================================================
//	Boottime log parser
//==================================================
function BoottimeLogParser()
{
	this.magic = 0;
	this.offHead = 0;
	this.offNext = 0;
	this.offMax = 0;
	this.maxComment = 0;
	this.numWritten = 0;
	this.headerSize = 0;
	this.entrySize = 0;
	this.binSize = 0;
	this.logs = new Array();


	//==================================================
	//	Error & exit
	//==================================================
	function die(msg)
	{
		mintole.error('***Tlog Parser Error: ' + msg);
		// exit();	// Cause syntax error to stop
	}


	//==================================================
	//	Get String from binary
	//==================================================
	function getStrFromBin(dv)
	{
		let log = "";
		for( let j = 8; j < dv.byteLength; j++ ) {
			let byte = dv.getUint8(j, true);
			if( byte == 0 ) { break; }
			log += String.fromCharCode(byte);
		}
	
		return log;
	}

	//==================================================
	//	Get offset
	//==================================================
	this.getOffset = function(n)
	{
		let off = 0;
		
		if (n >= this.numWritten) {
			return 0;
		}
	
		if (this.numWritten >= (this.binSize - this.headerSize) / this.entrySize) {
			off = this.offNext;
		} else {
			off = this.offHead;
		}
		off += this.entrySize * n;
		while( off + this.entrySize > this.offMax ) {
			off = off - this.offMax + this.offHead;
		}
	
		return off;
	}

	//==================================================
	//	Initialize parser by dataArray
	//==================================================
	this.initByData = function(data)
	{
		let offset = 0;
		dv = new DataView(data);
		this.logs = new Array();

		// Get header
		this.magic = dv.getUint32(offset, true);		offset += 4;
		this.offHead = dv.getUint32(offset, true);		offset += 4;
		this.offNext = dv.getUint32(offset, true);		offset += 4;
		this.offMax = dv.getUint32(offset, true);		offset += 4;
		this.maxComment = dv.getUint32(offset, true);	offset += 4;
		this.numWritten = dv.getUint32(offset, true);	offset += 4;

		// Get sizes
		this.headerSize = offset;
		this.entrySize = BOOT_TIME_ENTRY_TIME_SIZE + this.maxComment;
		this.binSize = data.byteLength;

		// Check magic number
		if( this.magic != BOOT_TIME_MAGIC ) {
			die("Invalid file format");
			return;
		}

		for( let i = 0; i < this.numWritten; i++ ) {
			let dve = new DataView(data, this.getOffset(i), this.entrySize);
			let log = getStrFromBin(dve);
			let beMark;
			
			if( log.indexOf(" B ") >= 0 ) { beMark = "B"; }
			else if( log.indexOf(" E ") >= 0 ) { beMark = "E"; }
			else { beMark = ""; }

			this.logs.push({
				time: ((dve.getUint32(4, true) * 0xFFFFFFFF) + dve.getUint32(0, true)),
				log: log,
				be: beMark,
			});

			dve = null;
		}

		dv = null;
	}

	//==================================================
	//	Show boot time log
	//==================================================
	this.appendTrElems = function(_viewArea)
	{
		if( _viewArea == null ) { return; }

		// Remove old information
		while( _viewArea.firstChild ) { _viewArea.removeChild(_viewArea.firstChild); }

		// Add new information
		for( let i = 0; i < this.logs.length; i++ )
		{
			let tr = view_area.appendChild(document.createElement("tr"));

			// Time
			let td = tr.appendChild(document.createElement("td"));
			td.appendChild(document.createTextNode((this.logs[i].time/1000000).toFixed(3) + "ms"));

			// Log
			td = tr.appendChild(document.createElement("td"));
			td.appendChild(document.createElement("pre")).appendChild(document.createTextNode(this.logs[i].log));

			tr.setAttribute("onmouseover", "touchLine(" + i + ");");
		}
	}

	//==================================================
	//	Get string
	//==================================================
	this.getString = function()
	{
		let logStr = "boot time log\n";

		for( let i = 0; i < this.logs.length; i++ )
		{
			let log = this.logs[i];

			// Log String
			logStr += log.log;
			// logStr += " ".repeat(MAX_COMMENT - log.log.length); // CANNOT use for IE11
			for( let j = 0; j < MAX_COMMENT - log.log.length; j++ ) {
				logStr += " ";
			}

			logStr += " : ";

			// Timestamp
			let timeStr = parseInt((log.time/1000), 10).toFixed(0);
			// logStr += " ".repeat(8 - timeStr.length); // CANNOT use for IE11
			for( let j = 0; j < 8 - timeStr.length; j++ ) {
				logStr += " ";
			}
			logStr += timeStr;
			logStr += " [us]\n";
		}

		return logStr;
	}

	//==================================================
	//	Initialize parser by URI
	//==================================================
	this.initByURI = function()
	{
		let ret = false;
		this.logs = new Array();

		if( !window.location.search ) { return false; }

		let params = LZString.decompressFromEncodedURIComponent(window.location.search.replace("?", "")).split(">");

		for( let i = 0; i < params.length; i++ )
		{
			let param = params[i];

			if( !param ) { continue; }

			let time = parseInt(param.split("<")[0], 16);
			let log = param.split("<")[1].replace("&lt;", "<").replace("&gt;", ">");
			let beMark;

			if( log.indexOf(" B ") >= 0 ) { beMark = "B"; }
			else if( log.indexOf(" E ") >= 0 ) { beMark = "E"; }
			else { beMark = ""; }

			this.logs.push({
				time: time,
				log: log,
				be: beMark,
			});
		}

		// Exist data on URI
		if( params.length ) {
			ret = true;
		}

		return ret;
	}

	//==================================================
	//	Get URI String
	//==================================================
	this.getURIStr = function()
	{
		let log = "";

		for( let i = 0; i < this.logs.length; i++ )
		{
			log += this.logs[i].time.toString(16);
			log += "<";
			log += this.logs[i].log.replace("<", "&lt;").replace(">", "&gt;");
			log += ">";
		}

		return window.location.href.replace(window.location.search, "") + "?" + LZString.compressToEncodedURIComponent(log);
	}

	//==================================================
	//	Get log line
	//==================================================
	this.getLogLine = function(idx)
	{
		return this.logs[idx];
	}
}
