
window.addEventListener("load", function() {
	addLoadAddonFile();
});

////////////////////////////////////////////////////////////////////////////////
//	Addon���̓Ǎ�
////////////////////////////////////////////////////////////////////////////////
function addReadAddonFile()
{
	var addonFilePath = CurrentDir + "\\addon\\" + "addon.txt";
	var addonFile;
	var addonStr = "";

	if( !WshFs.FileExists( addonFilePath )){
		addonFile = WshFs.OpenTextFile( addonFilePath, 8, true );	// 1:ForWrite

		for( i = 1 ; i <= 6 ; i++ ){
			addonFile.Write( "\n" );
			addonFile.Write( "Addon" + i + "_title=Title\n" );
			addonFile.Write( "Addon" + i + "_file=\n" );
//			addonFile.Write( "Addon" + i + "_memo=\n" );
		}
		addonFile.Close();
	}

	addonFile = WshFs.OpenTextFile( addonFilePath, 1 );				// 1:ForRead
	addonStr = addonFile.ReadAll();
	addonFile.Close();

	return addonStr;
}

////////////////////////////////////////////////////////////////////////////////
//	Addon���̏���
////////////////////////////////////////////////////////////////////////////////
function addWriteAddonFile( addonStr )
{
	var addonFilePath = CurrentDir + "\\addon\\" + "addon.txt";
	var addonFile;

	if( WshFs.FileExists( addonFilePath )){
		WshFs.DeleteFile( addonFilePath );
	}

	addonFile = WshFs.OpenTextFile( addonFilePath, 8, true );	// 1:ForWrite
	addonFile.Write( addonStr );
	addonFile.Close();
}

////////////////////////////////////////////////////////////////////////////////
//	Addon�����̓Ǎ�
////////////////////////////////////////////////////////////////////////////////
function addReadAddonMemo(
	saveNumber        // �ۑ��ԍ�
)
{
	var addonMemoPath = CurrentDir + "\\addon\\" + "addonMemo" + saveNumber + ".txt";
	var addonMemo;
	var addonStr = "";

	if( WshFs.FileExists( addonMemoPath )){
		addonMemo = WshFs.OpenTextFile( addonMemoPath, 1 );		// 1:ForRead
		addonStr = addonMemo.ReadAll();
		addonMemo.Close();
	}

	return addonStr;
}

////////////////////////////////////////////////////////////////////////////////
//	Addon�����̏���
////////////////////////////////////////////////////////////////////////////////
function addWriteAddonMemo(
	saveNumber,       // �ۑ��ԍ�
	addonStr          // 
)
{
	var addonMemoPath = CurrentDir + "\\addon\\" + "addonMemo" + saveNumber + ".txt";
	var addonMemo;

	if( WshFs.FileExists( addonMemoPath )){
		WshFs.DeleteFile( addonMemoPath );
	}

	addonFile = WshFs.OpenTextFile( addonMemoPath, 8, true );	// 1:ForWrite
	addonFile.Write( addonStr );
	addonFile.Close();
}

////////////////////////////////////////////////////////////////////////////////
//	Addon���̓W�J�iaddon.txt�����݂���ꍇ�AAddon�^�u���������ɓW�J����j
//		changePage( "addon" ) ����R�[�������
////////////////////////////////////////////////////////////////////////////////
function addLoadAddonFile()
{
	// addon.txt���Ȃ���Ή������Ȃ�
	var addonFilePath = CurrentDir + "\\addon\\" + "addon.txt";
	if( !WshFs.FileExists( addonFilePath )){
		return false;
	}

	// addon.txt�̓ǂݍ���
	var addon = addReadAddonFile();

	var strTitle, posTitle, resTitle;
	var strFile, posFile, resFile;
	var title = "";
	var file = "";

	for( i = 1 ; i <= 6 ; i++ ){
		strTitle = "Addon" + i + "_title=";
		posTitle = addon.indexOf( strTitle );

		strFile  = "Addon" + i + "_file=";
		posFile  = addon.indexOf( strFile );

		if(( posTitle == -1 ) || ( posFile == -1 )){
			alert( "ERR : /addon/addon.txt" );
			return false;
		}
		posTitle += strTitle.length;
		posFile  += strFile.length;

		// Title
		title = "";
		for( j = 0 ; j < 100 ; j++ ){								// Max�F100����
			resTitle = addon.charAt( posTitle + j );
			if( resTitle == "\n" ){									// ���s
				break;
			}
			title += resTitle;
		}

		// File
		file = "";
		for( j = 0 ; j < 256 ; j++ ){								// Max�F256����
			resFile = addon.charAt( posFile + j );
			if( resFile == "\n" ){									// ���s
				break;
			}
			file += resFile;
		}

		document.getElementById( "Addon" + i + "_title" ).value = title;
		document.getElementById( "Addon" + i + "_path" ).value  = file;
		document.getElementById( "Addon" + i + "_memo" ).value  = addReadAddonMemo( i );

//		alert( "Title = " + title );
//		alert( "File = "  + file );
//		alert( "Memo = "  + addReadAddonMemo( i ));
	}
}

////////////////////////////////////////////////////////////////////////////////
// Addon�t�@�C���̑I���i"Script"�������j
////////////////////////////////////////////////////////////////////////////////
function addAddon_SelectScript(
	saveNumber        // �ۑ��ԍ�
)
{
	// Addon�t�@�C���p�X�擾
	var strFile  = "Addon" + saveNumber + "_tmp";
	document.getElementById( strFile ).click();

	// Addon�t�@�C���p�X����
	var filePath = document.getElementById( strFile ).value;
	document.getElementById( "Addon" + saveNumber + "_path" ).value = filePath;
}

////////////////////////////////////////////////////////////////////////////////
// Addon�̎��s�i"Exec"��������addon.txt��ҏW�����s����j
////////////////////////////////////////////////////////////////////////////////
function addAddon_Exec(
	saveNumber,        // �ۑ��ԍ�
	exeFilename        // ���s�t�@�C��
)
{
	// ���s�t�@�C�������݂��Ȃ���Ή������Ȃ�
	if( !WshFs.FileExists( exeFilename )){
		alert( "Input:" + exeFilename + " Not Found" );
		return false;
	}

	// addon.txt�̕ҏW(�S�̈�X�V����)
	var addon = addReadAddonFile();		// �t�@�C�����Ȃ���ΐ�������

	var strTitle, posTitle, resTitle, setTitle;
	var strFile, posFile, resFile, setFile;
	var setMemo;
	var title = "";
	var file = "";

	for( i = 1 ; i <= 6 ; i++ ){
		strTitle = "Addon" + i + "_title=";
		posTitle = addon.indexOf( strTitle );

		strFile  = "Addon" + i + "_file=";
		posFile  = addon.indexOf( strFile );

		if(( posTitle == -1 ) || ( posFile == -1 )){
			alert( "ERR : /addon/addon.txt" );
			return false;
		}
		posTitle += strTitle.length;
		posFile  += strFile.length;

		// Title
		title = "";
		for( j = 0 ; j < 100 ; j++ ){								// Max�F100����
			resTitle = addon.charAt( posTitle + j );
			if( resTitle == "\n" ){									// ���s
				break;
			}
			title += resTitle;
		}

		// File
		file = "";
		for( j = 0 ; j < 256 ; j++ ){								// Max�F256����
			resFile = addon.charAt( posFile + j );
			if( resFile == "\n" ){									// ���s
				break;
			}
			file += resFile;
		}

		// ���[�U�[�ݒ�l�擾���ۑ�
		setTitle = document.getElementById( "Addon" + i + "_title" ).value;
		setFile  = document.getElementById( "Addon" + i + "_path" ).value;
		setMemo  = document.getElementById( "Addon" + i + "_memo" ).value;

		addon = addon.replace( strTitle + title, strTitle + setTitle );
		addon = addon.replace( strFile  + file,  strFile  + setFile );
		addWriteAddonMemo( i, setMemo );

//		alert( "Title = " + title + " -> " + setTitle );
//		alert( "File = "  + file  + " -> " + setFile );
//		alert( "Memo = " + setMemo );
	}

	addWriteAddonFile( addon );

	// Add on �̎��s
	var WshShell = new ActiveXObject( "WScript.Shell" );
	WshShell.Run( "\"" + exeFilename + "\"", 4, false );
	delete WshShell;

	return true;
}

