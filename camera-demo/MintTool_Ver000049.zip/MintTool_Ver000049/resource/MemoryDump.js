
/*****************************************************************************
 * メモリダンプの結果をファイルに保存する
 * @param: 吐き出し先ファイルパス
 * @param: 読み出し元アドレス
 * @param: 読み出しサイズ
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function MemDumpSaveToFile(file, addr, size)
{
	if( file == "" || addr == 0 || size == 0 ) { return false; }
	if( !Connect() ) {
		return false;
	}
	
	var ret = true;

	// Memory Dump
	try {
		if( MemDump.ReadData(addr, size) ) {
			// DumpDataをファイルに吐き出し
			if( !MemDump.SavetoFile(file, MemDump.ReadDataSize, 0, 1) ) {
				mintole.error("MemDumpSaveToFile: Save File FAIL");
				throw "error";
			}
		}
		else {
			mintole.error("MemDumpSaveToFile: MemoryDump FAIL");
			throw "error";
		}
	}
	catch(e) {
		// Error handler
		ret = false;
	}

	Disconnect();
	return ret;
}

/*****************************************************************************
 * 一時ファイルの削除
 * @param: FSOオブジェクト
 * @param: 一時ファイルパス
 * @param: 一時ファイルの拡張子
 * @return: void
*****************************************************************************/
function __cleanMemDumpTempFilesCP(fso, file, tmpFileExt) {
	try {
		fso.DeleteFile(fso.GetParentFolderName(file) + "\\\\*" + tmpFileExt);
	} catch(e) {}
}

/*****************************************************************************
 * メモリダンプの結果をファイルに保存する (CP向け)
 * @param: 吐き出し先ファイルパス
 * @param: 読み出し元アドレス
 * @param: 読み出しサイズ
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function MemDumpSaveToFileCP(file, addr, size)
{
	if( file == "" || addr == 0 || size == 0 ) { return false; }
	if ( !Connect() ) {
		return false;
	}

	var TMP_FILE_EXT = ".dtmp";
	var fileIdx = 0;
	var wsh = new ActiveXObject("WScript.Shell");
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	file = file.replace(/\\/g,"\\\\");
	var tmpFileBase = file + "_";
	var ret = true;

	// Delete zombie files
	__cleanMemDumpTempFilesCP(fso, file, TMP_FILE_EXT);

	// Dump dividedly
	try {
		while( size > 0 ) {
			var tmpFile = tmpFileBase + fileIdx + TMP_FILE_EXT;
			var tmpSize = size > MemDumpMaxSize ? MemDumpMaxSize : size;

			// Memory Dump
			if( MemDump.ReadDataEX(addr, tmpSize, 0x1) ) {
				// DumpDataをファイルに吐き出し
				if( !MemDump.SavetoFile(tmpFile, MemDump.ReadDataSize, 0, 1) ) {
					mintole.error("MemDumpSaveToFileCP: Save File FAIL");
					throw "error";
				}
			}
			else {
				mintole.error("MemDumpSaveToFileCP: MemoryDump FAIL");
				throw "error";
			}

			addr += tmpSize;
			size -= tmpSize;
			fileIdx++;
		}

		wsh.Run("cmd /c copy /b \"" + tmpFileBase + "*" + TMP_FILE_EXT + "\" \"" + file + "\"", 0, true);
	}
	catch(e) {
		// Error handler
		ret = false;
	}

	__cleanMemDumpTempFilesCP(fso, file, TMP_FILE_EXT);
	Disconnect();
	return ret;
}

/*****************************************************************************
 * 指定したbackupIdのメモリダンプの結果をファイルに保存する
 * @param: 吐き出し先ファイルパス
 * @param: 読み出し元アドレス
 * @param: 読み出しサイズ
 * @return: void
*****************************************************************************/
function MemDumpSaveToFileByBackupId(file, backupId_addr, backupId_size)
{
	var ret = true;
	var addr = new Array(0);
	var size = new Array(0);
	
	if( file == "" || backupId_addr == 0 || backupId_size == 0 ) { return false; }

	try {
		if( ReadBackupData32(backupId_addr, addr) && ReadBackupData32(backupId_size, size) ) {
			// Memory Dump
			size.pop();
			var addr64 = addr.pop()*0x100000000 + addr.pop();
			var size64 = size.pop();
			if( !MemDumpSaveToFile(file, addr64, size64) ) {
				mintole.alert("MemDumpSaveToFileByBackupId: Save File FAIL: "
					+ "addr: 0x" + addr64.toString(16) + ", size: 0x" + size64.toString(16));
				throw "error";
			}
		}
		else {
			mintole.alert("MemDumpSaveToFileByBackupId: Get Addr or Size FAIL: "
				+ "addr: 0x" + backupId_addr.toString(16) + ", size: 0x" + backupId_size.toString(16));
			throw "error";
		}
	}
	catch(e) {
		ret = false;
	}

	delete addr;
	delete size;

	return ret;
}

/*****************************************************************************
 * 指定したbackupIdのメモリダンプの結果をファイルに保存する（CP向け）
 * @param: 吐き出し先ファイルパス
 * @param: 読み出し元アドレス
 * @param: 読み出しサイズ
 * @return: void
*****************************************************************************/
function MemDumpSaveToFileByBackupIdCP(file, backupId_addr, backupId_size)
{
	var ret = true;
	var addr = new Array(0);
	var size = new Array(0);
	
	if( file == "" || backupId_addr == 0 || backupId_size == 0 ) { return false; }

	try {
		if( ReadBackupDataCP32(backupId_addr, addr) && ReadBackupDataCP32(backupId_size, size) ) {
			// Memory Dump
			size.pop();
			var addr64 = addr.pop()*0x100000000 + addr.pop();
			var size64 = size.pop();
			if( !MemDumpSaveToFileCP(file, addr64, size64) ) {
				mintole.alert("MemDumpSaveToFileByBackupIdCP: Save File FAIL: "
					+ "addr: 0x" + addr64.toString(16) + ", size: 0x" + size64.toString(16));
				throw "error";
			}
		}
		else {
			mintole.alert("MemDumpSaveToFileByBackupIdCP: Get Addr or Size FAIL: "
				+ "addr: 0x" + backupId_addr.toString(16) + ", size: 0x" + backupId_size.toString(16));
			throw "error";
		}
	}
	catch(e) {
		ret = false;
	}

	delete addr;
	delete size;

	return ret;
}

/*****************************************************************************
 * 指定したbackupIdのメモリダンプの結果をファイルに保存する（CP sus_log向け）
 * @param: 吐き出し先ファイルパス
 * @param: 読み出し元アドレス
 * @param: 読み出しサイズ
 * @return: void
*****************************************************************************/
function MemDumpSaveToFileByBackupIdForSusLog(file, backupId_addr, backupId_size)
{
	var ret = true;
	var addr = new Array(0);
	var size = new Array(0);
	
	if( file == "" || backupId_addr == 0 || backupId_size == 0 ) { return false; }

	try {
		if( ReadBackupData32(backupId_addr, addr) && ReadBackupDataCP32(backupId_size, size) ) {
			// Memory Dump
			size.pop();
			var addr64 = addr.pop()*0x100000000 + addr.pop();
			var size64 = size.pop();
			if( !MemDumpSaveToFile(file, addr64, size64) ) {
				mintole.alert("MemDumpSaveToFileByBackupIdForSusLog: Save File FAIL: "
					+ "addr: 0x" + backupId_addr.toString(16) + ", size: 0x" + backupId_size.toString(16));
				throw "error";
			}
		}
		else {
			mintole.alert("MemDumpSaveToFileByBackupIdForSusLog: Get Addr or Size FAIL: "
				+ "addr: 0x" + backupId_addr.toString(16) + ", size: 0x" + backupId_size.toString(16));
			throw "error";
		}
	}
	catch(e) {
		ret = false;
	}

	delete addr;
	delete size;

	return ret;
}
