
var setVer = null;

/*================================================================================
 * Initialize
================================================================================*/
window.addEventListener("load", function() {
	setVer = new SetVersion();
});

/*================================================================================
 * Target Version Class
================================================================================*/
var SetVersion = function() {

	this.firmwareVer = null;
	this.defhd = null;
}

/*--------------------------------------------------------------------------------
 * Read target firmware version
--------------------------------------------------------------------------------*/
SetVersion.prototype.readFirmwareVer = function()
{
	if( !Connect() ) {
		return false;
	}

	// Firmware virsion
	AdjustCmd.DataSize = 0;
	if( !AdjustCmd.CmdIssue(0x0603, 0x10) ) {
		mintole.error("Fail to get Firmware Version!");
		Disconnect();
		return false;
	}
	else {
		this.firmwareVer = {
			"ver" : AdjustCmd.GetResponse32(0).toString(16),
			"date" : AdjustCmd.GetResponse32(1).toString(16),
			"rel" : AdjustCmd.GetResponse32(2).toString(16)
		};
		mintole.debug("Get Firmware Version: "
						+ this.firmwareVer.ver + "/"
						+ this.firmwareVer.date + "/"
						+ this.firmwareVer.rel
					);
	}
	
	Disconnect();
	return true;
}

/*--------------------------------------------------------------------------------
 * Read target defhd.dat
--------------------------------------------------------------------------------*/
SetVersion.prototype.readDefhd = function()
{
	if( !Connect() ) {
		return false;
	}

	this.defhd = {
		"usrVer" : null,
		"modelInfo" : null,
		"destInfo" : ""
	};

	// Set version
	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x00);
	if( !AdjustCmd.CmdIssue(0x0604, 0x4000) ) {
		mintole.error("Fail to get SET Version!");
		Disconnect();
		return false;
	}
	else {
		var res = AdjustCmd.GetResponse8(0);
		if (res == 0) {
			var major = zerofillBefore(AdjustCmd.GetResponse8(1).toString(16), 2);
			var minor = zerofillBefore(AdjustCmd.GetResponse8(2).toString(16), 2);

			this.defhd.usrVer = {
				"major" : major,
				"minor" : minor
			};
		}
		else {
			mintole.error("Fail to get SET Version!");
			Disconnect();
			return false;
		}
	}

	// Model information
	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x01);
	if( !AdjustCmd.CmdIssue(0x0604, 0x4000) ) {
		mintole.error("Fail to get Model Info!");
		Disconnect();
		return false;
	}
	else {
		var res = AdjustCmd.GetResponse8(0);
		if (res == 0) {
			var year = zerofillBefore(AdjustCmd.GetResponse8(1).toString(16), 2);
			var category = zerofillBefore(AdjustCmd.GetResponse8(2).toString(16), 2);
			var major = zerofillBefore(AdjustCmd.GetResponse8(3).toString(16), 2);
			var minor = zerofillBefore(AdjustCmd.GetResponse8(4).toString(16), 2);

			this.defhd.modelInfo = {
				"year" : year,
				"category" : category,
				"major" : major,
				"minor" : minor,
			};
		}
		else {
			mintole.error("Fail to get Model Info!");
			Disconnect();
			return false;
		}
	}
	
	// Destination information
	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x02);
	if( !AdjustCmd.CmdIssue(0x0604, 0x4000) ) {
		mintole.error("Fail to get Destination Info!");
		Disconnect();
		return false;
	}
	else {
		var res = AdjustCmd.GetResponse8(0);
		if( res == 0 ) {
			var Dest0 = zerofillBefore(AdjustCmd.GetResponse8(1).toString(16), 2);
			var Dest1 = zerofillBefore(AdjustCmd.GetResponse8(2).toString(16), 2);
			var Dest2 = zerofillBefore(AdjustCmd.GetResponse8(3).toString(16), 2);
			var Dest3 = zerofillBefore(AdjustCmd.GetResponse8(4).toString(16), 2);

			this.defhd.destInfo = Dest0 + "." + Dest1 + "." + Dest2 + "." + Dest3;
		}
		else {
			mintole.error("Fail to get Destination Info!");
			Disconnect();
			return false;
		}
	}

	Disconnect();
	return true;
}

/*--------------------------------------------------------------------------------
 * Get firmware version
--------------------------------------------------------------------------------*/
SetVersion.prototype.getFirmwareVer = function()
{
	if( this.firmwareVer == null ) { return ""; }

	return (this.firmwareVer.ver.substr(0, 5) + "_"
			+ this.firmwareVer.ver.substr(5, 2) + "."
			+ this.firmwareVer.date
			+ zerofillBefore(this.firmwareVer.rel, 2)
		);
}

/*--------------------------------------------------------------------------------
 * Get a head of firmware version
--------------------------------------------------------------------------------*/
SetVersion.prototype.getFirmwareVerHead = function()
{
	if( this.firmwareVer == null ) { return ""; }

	return (this.firmwareVer.ver.substr(0, 5));
}

/*--------------------------------------------------------------------------------
 * Get user version
--------------------------------------------------------------------------------*/
SetVersion.prototype.getUsrVer = function()
{
	if( this.defhd == null ) { return null; }

	return this.defhd.usrVer;
}

/*--------------------------------------------------------------------------------
 * Get model information
--------------------------------------------------------------------------------*/
SetVersion.prototype.getModelInfo = function()
{
	if( this.defhd == null ) { return null; }

	return this.defhd.modelInfo;
}

/*--------------------------------------------------------------------------------
 * Get year of model information
--------------------------------------------------------------------------------*/
SetVersion.prototype.getModelInfoYear = function()
{
	if( this.defhd == null ) { return ""; }
	if( this.defhd.modelInfo == null ) { return ""; }

	return this.defhd.modelInfo.year;
}

/*--------------------------------------------------------------------------------
 * Get category of model information
--------------------------------------------------------------------------------*/
SetVersion.prototype.getModelInfoCategory = function()
{
	if( this.defhd == null ) { return ""; }
	if( this.defhd.modelInfo == null ) { return ""; }

	return this.defhd.modelInfo.category;
}

/*--------------------------------------------------------------------------------
 * Get category string of model information
--------------------------------------------------------------------------------*/
SetVersion.prototype.getModelInfoCategoryName = function()
{
	switch(this.getModelInfoCategory()) {
	case "01":
		categoryString = "CAM";
		break;
	case "02":
		categoryString = "DSC";
		break;
	case "03":
		categoryString = "DSLR";
		break;
	case "04":
		categoryString = "CAM";
		break;
	case "05":
		categoryString = "VSS";
		break;
	default:
		categoryString = "";
		break;
	}

	return categoryString;
}

/*--------------------------------------------------------------------------------
 * Get set name from model information
--------------------------------------------------------------------------------*/
SetVersion.prototype.getModelInfoSetName = function()
{
	if( this.defhd == null ) { return ""; }
	if( this.defhd.modelInfo == null ) { return ""; }

	return (this.defhd.modelInfo.category + this.defhd.modelInfo.year + this.defhd.modelInfo.minor).slice(1);
}

/*--------------------------------------------------------------------------------
 * Get destination information
--------------------------------------------------------------------------------*/
SetVersion.prototype.getDestInfo = function()
{
	if( this.defhd == null ) { return ""; }

	return this.defhd.destInfo;
}


///////////////////////////////////////////////////////////////////////////////
// Get Category Num Function
///////////////////////////////////////////////////////////////////////////////
function GetCategoryNum()
{
	setVer.readDefhd();
	return setVer.getModelInfoCategory() || "00";
}

///////////////////////////////////////////////////////////////////////////////
// Get Category Name Function
///////////////////////////////////////////////////////////////////////////////
function GetCategoryName()
{
	setVer.readDefhd();
	return setVer.getModelInfoCategoryName() || "Unknown";
}

///////////////////////////////////////////////////////////////////////////////
// Get Head Firmware Version
///////////////////////////////////////////////////////////////////////////////
function GetHeadVersion()
{
	setVer.readFirmwareVer();
	return setVer.getFirmwareVerHead();
}
