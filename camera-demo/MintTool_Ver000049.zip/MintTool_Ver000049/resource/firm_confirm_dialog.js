
/*================================================================================
 * Print firmware name
================================================================================*/
function printFirmwareName()
{
	var parentData = window.dialogArguments;
	var FnameStr = parentData[0];

	var cautionObj = document.getElementById("ConfirmSysUpdate_caution");
	cautionObj.innerHTML = FnameStr + cautionObj.innerHTML;
}

/*================================================================================
 * Return selection result
================================================================================*/
function returnResult(result)
{
	returnValue = result;
	close();
}
