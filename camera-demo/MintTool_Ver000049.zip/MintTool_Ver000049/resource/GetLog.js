
var getLogPieces = null;

/*================================================================================
 * Initialize
================================================================================*/
window.addEventListener("load", function() {
	var GetLog_makeZip = document.getElementById("GetLog_makeZip");
	settings.linkElmToKey("packLogZip", GetLog_makeZip);

	var GetLog_SSDI = document.getElementById("GetLog_SSDI");
	settings.linkElmToKey("getLogSSDI", GetLog_SSDI);

	var GetLogCore_on = document.getElementById("GetLogCore_on");
	settings.linkElmToKey("getLogCore", GetLogCore_on);

	var GetLogCodec_on = document.getElementById("GetLogCodec_on");
	settings.linkElmToKey("getLogCodec", GetLogCodec_on);

	getLogPieces = new GetLogPieces();

	appendGetLogList();
});


/*================================================================================
 * Get log
================================================================================*/
function comGetLog(
	DirectroyName	// ログを保存するディレクトリパス
)
{
	mintole.open();
	
	if (false == chkMainLSI()) {
		return false;
	}

	var fso = new ActiveXObject("Scripting.FileSystemObject");

	if (! fso.FolderExists(DirectroyName)) {
		mintole.alert("Destination Not Found: " + DirectroyName);
		return false;
	}

	// 相対パスの場合は絶対パスに修正
	DirectroyName = fso.GetAbsolutePathName(DirectroyName);

	// ディレクトリ名を日付に
	DirectroyName = DirectroyName + "\\" + GetDateStrForFileName() + "_IPSX";
	mintole.info(DirectroyName);

	// フォルダが存在しなければ作成する
	if (! fso.FolderExists(DirectroyName)) {
		if (!fso.CreateFolder(DirectroyName)) {
			mintole.alert("Fail to create directory: " + fso.ErrMsg);
			return false;
		}
	}

	if( getLogPieces.preProc() == false ) {
		return false;
	}

	if(isDisableSenserIF(false)){
		AdjustCmd.DataSize = 1;
		AdjustCmd.SetParam8(0, 0x00);	// all
		if( !AdjustCmd.CmdIssue(0x060f, 0x0001) ) {
			getLogPieces.hasErr = true;
		}
		else{
			if( !AdjustCmd.SavetoFile(DirectroyName + "\\logdata.tar.gz", AdjustCmd.ResSize, 0, 1) ) {
				getLogPieces.hasErr = true;
			}
		}
	}
	else{
		getLogPieces.exec(DirectroyName);
	}
	getLogPieces.postProc();

	if( getLogPieces.hasErr == false ) {
		/* log delete */
		if(!isDisableSenserIF(false)){
			comDeleteEscapeLog(false);
		}
		mintole.alert("Save Log Success");
	}
	else {
		mintole.alert("Save Log Fail");
	}

	delete fso;
}


/*================================================================================
 * Remove escape log
================================================================================*/
function comDeleteEscapeLog(popup)
{
	if( !Connect() ) {
		return false;
	}

	if(isDisableSenserIF(true)){
		Disconnect();
		return false;
	}

	var deleteFileList = new Array(
		// klog
		"/log/ulogio_klog.txt",
		"/tmp/ulogio_klog.txt",
		"/log/cp/ulogio_klog.bin",
		"/tmp/cp/ulogio_klog.bin",
	
		// tlog
		"/log/ulogio_tlog.txt",
		"/tmp/ulogio_tlog.txt",
		"/log/cp/ulogio_tlog.bin",
		"/tmp/cp/ulogio_tlog.bin",
	
		// escapelog
		"/log/escapelog.bin",
		"/tmp/escapelog.bin",
		"/log/cp/escapelog.bin",
		"/tmp/cp/escapelog.bin",
	
		// uipc
		"/tmp/uipc_stat_kernel.txt",
		"/tmp/uipc_stat_user.txt",
		
		// ThreadMonitorlog
		"/log/ThreadMonitor.bin",
		"/tmp/ThreadMonitor.bin",

		"/tmp/emif_oom.txt",

		// Zynq log
		"/log/zynq/escapelog_a53.bin",
		"/log/zynq/escapelog_fsbl.bin",
		"/log/zynq/escapelog_r5-0.bin",
		"/log/zynq/escapelog_r5-1.bin"
	);

	for( var i = 0; i < deleteFileList.length; i++ ) {
		FileCtl.FileDelete(deleteFileList[i]);
	}

	// core file
	getLogPieces.removeCoreFile("");

	mintole.alert("Delete Escape Log", popup);

	Disconnect();
}


/*================================================================================
 * Append Get log list
================================================================================*/
function createGetLogListElement(parent, i)
{
	var selectAllChkBox = document.getElementById("GetLog_selectlist_selectall");

	var procName = getLogPieces.getProcName(i);
	var procNameForID = getLogPieces.getProcNameForID(i);

	/* <li><label id="ID_label" for="ID"><input id="ID" type="checkbox">PROCESS_NAME</label></li> */
	var id = "GetLog_selectList_" + procNameForID;
	var liElm = parent.appendChild(document.createElement("li"));
	var labelElm = liElm.appendChild(document.createElement("label"));
	labelElm.id = id + "_label";
	labelElm.htmlFor = id;
	var inpElm = labelElm.appendChild(document.createElement("input"));
	inpElm.id = id;
	inpElm.type = "checkbox";
	labelElm.appendChild(document.createTextNode(procName));
	
	// Link to Setting Info. key
	settings.linkElmToKey(id, inpElm);
	inpElm.addEventListener("click", function(i) {
		getLogPieces.switchEnable(i, !!this.checked);
		
		// Cooperate with "select all checkbox"
		if( !!!this.checked ) { selectAllChkBox.checked = ""; }
		else {
			selectAllChkBox.checked = "checked";
			for( var i = 0; i < getLogPieces.getProcLen(); i++ ) {
				if( getLogPieces.getProcName(i) && getLogPieces.isNotForSelect(i) != true )
				{
					var procNameForID = getLogPieces.getProcNameForID(i);
					var id = "GetLog_selectList_" + procNameForID;
					var chkbox = document.getElementById(id);
					if( !chkbox.checked ) {
						selectAllChkBox.checked = "";
						break;
					}
				}
			}
		}
	}.bind(inpElm, i));

	// Reflect current status
	if( settings.get(id) != false ) {
		inpElm.checked = "checked";
		getLogPieces.switchEnable(i, true);
	}
	else {
		// Uncheck "select all checkbox"
		selectAllChkBox.checked = "";
	}
}
function appendGetLogList()
{
	var selectListElm = document.getElementById("GetLog_selectList");
	
	for( var i = 0; i < getLogPieces.getProcLen(); i++ ) {
		if( getLogPieces.getProcName(i) && getLogPieces.isNotForSelect(i) != true )
		{
			// Append list element
			createGetLogListElement(selectListElm, i);
		}
	}

	function changeGetLogListAll(stat) {
		for( var i = 0; i < getLogPieces.getProcLen(); i++ ) {
			if( getLogPieces.getProcName(i) && getLogPieces.isNotForSelect(i) != true )
			{
				var procNameForID = getLogPieces.getProcNameForID(i);
				var id = "GetLog_selectList_" + procNameForID;
				var chkbox = document.getElementById(id);
				
				if( stat ) {
					chkbox.checked = "checked";
					settings.set(id, true);
				} else {
					chkbox.checked = "";
					settings.set(id, false);
				}
				settings.write();
				getLogPieces.switchEnable(i, !!stat);
			}
		}
	}
	var selectAllChkBox = document.getElementById("GetLog_selectlist_selectall");
	selectAllChkBox.addEventListener("click", function() {
		changeGetLogListAll( this.checked );
	});
}
