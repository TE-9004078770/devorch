
window.addEventListener("load", function() {
	// タブ初期値設定
	changeSubMiconPage("Darwin");
});

///////////////////////////////////////////////////////////////////////////////
// Get Darwin version
///////////////////////////////////////////////////////////////////////////////
function GetDarwinVer(
	bAlert		// アラート (0:アラートを出さない/ 1:アラートを出す)
)
{
	DarwinVer_drwBooId.innerHTML    = "*";
	DarwinVer_drwBooRel.innerHTML   = "*";
	DarwinVer_drwBooRev.innerHTML   = "*";
	DarwinVer_drwBooCate.innerHTML  = "*";
	DarwinVer_drwBooMod.innerHTML   = "*";
	DarwinVer_drwCoreId.innerHTML   = "*";
	DarwinVer_drwCoreRel.innerHTML  = "*";
	DarwinVer_drwCoreRev.innerHTML  = "*";
	DarwinVer_drwCoreCate.innerHTML = "*";
	DarwinVer_drwCoreMod.innerHTML  = "*";

	if(! Connect() ) return false;

	var ret_boo = 0;
	var ret_core = 0;

	// BOO_DWN_FW_ID_GET
	AdjustCmd.DataSize = 0;
	if (AdjustCmd.CmdIssue(0x0D20, 0xEA)) {
		var booDrwFW = new Array();
		for (var cnt = 0; cnt < AdjustCmd.ResSize; cnt++) {
			booDrwFW.push(String.fromCharCode(AdjustCmd.GetResponse8(cnt)));
		}

		// FRNTVER_BOO_GET
	 	AdjustCmd.DataSize = 0;
		if (AdjustCmd.CmdIssue(0x0D20, 0xEE)) {
			var frontVerBooH = AdjustCmd.GetResponse8(0).toString(16);
			var frontVerBooL = AdjustCmd.GetResponse8(1).toString(16);

			DarwinVer_drwBooId.innerHTML = "<strong>" + booDrwFW.join('') + "</strong>";
			DarwinVer_drwBooRel.innerHTML = "<strong>" + "0x" + frontVerBooL + "</strong>";
			DarwinVer_drwBooRev.innerHTML = "<strong>" + "0x" + frontVerBooH + "</strong>";
		}

		if (AdjustCmd.CmdIssue(0x0D20, 0xEC)) {
			var frontVerBoo_EXH = AdjustCmd.GetResponse8(0).toString(16);
			var frontVerBoo_EXL = AdjustCmd.GetResponse8(1).toString(16);

			DarwinVer_drwBooCate.innerHTML = "<strong>" + "0x" + frontVerBoo_EXL + "</strong>";
			DarwinVer_drwBooMod.innerHTML = "<strong>" + "0x" + frontVerBoo_EXH + "</strong>";
		}

		ret_boo = 1;

		delete booDrwFW;
	}

	// CORE_DWN_FW_ID_GET
	AdjustCmd.DataSize = 0;
	if (AdjustCmd.CmdIssue(0x0D20, 0xEB)) {
		var coreDrwFW = new Array();
		for (var cnt = 0; cnt < AdjustCmd.ResSize; cnt++) {
			coreDrwFW.push(String.fromCharCode(AdjustCmd.GetResponse8(cnt)));
		}

		// FRNTVER_CORE_GET
	 	AdjustCmd.DataSize = 0;
		if (AdjustCmd.CmdIssue(0x0D20, 0xEF)) {
			var frontVerCoreH = AdjustCmd.GetResponse8(0).toString(16);
			var frontVerCoreL = AdjustCmd.GetResponse8(1).toString(16);

			DarwinVer_drwCoreId.innerHTML = "<strong>" + coreDrwFW.join('') + "</strong>";
			DarwinVer_drwCoreRel.innerHTML = "<strong>" + "0x" + frontVerCoreL + "</strong>";
			DarwinVer_drwCoreRev.innerHTML = "<strong>" + "0x" + frontVerCoreH + "</strong>";
		}

		if (AdjustCmd.CmdIssue(0x0D20, 0xED)) {
			var frontVerCore_EXH = AdjustCmd.GetResponse8(0).toString(16);
			var frontVerCore_EXL = AdjustCmd.GetResponse8(1).toString(16);

			DarwinVer_drwCoreCate.innerHTML = "<strong>" + "0x" + frontVerCore_EXL + "</strong>";
			DarwinVer_drwCoreMod.innerHTML = "<strong>" + "0x" + frontVerCore_EXH + "</strong>";
		}

		ret_core = 1

		delete coreDrwFW;
	}

	if ((ret_boo == 0 || ret_core == 0 ) && bAlert == 1) {
		alert("Get Darwin Version FAIL!!!");
	}

	Disconnect();
	return true;
}

///////////////////////////////////////////////////////////////////////////////
// Clear Darwin version
///////////////////////////////////////////////////////////////////////////////
function ClrDarwinVer()
{
	DarwinVer_drwBooId.innerHTML    = "*";
	DarwinVer_drwBooRel.innerHTML   = "*";
	DarwinVer_drwBooRev.innerHTML   = "*";
	DarwinVer_drwBooCate.innerHTML  = "*";
	DarwinVer_drwBooMod.innerHTML   = "*";
	DarwinVer_drwCoreId.innerHTML   = "*";
	DarwinVer_drwCoreRel.innerHTML  = "*";
	DarwinVer_drwCoreRev.innerHTML  = "*";
	DarwinVer_drwCoreCate.innerHTML = "*";
	DarwinVer_drwCoreMod.innerHTML  = "*";

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// Darwin Auto setting
///////////////////////////////////////////////////////////////////////////////
function DarwinAutoSetting(
	settingVal	// Enable/ Disable
)
{
	if (! Connect()) {
		return false;
	}

	var writeData = new Array();
	var param = 0;

	if (settingVal == "Enable") {
		param = 0x01;
	}
	else {
		param = 0x00;
	}

	for (var cnt = 0; cnt < 0x20; cnt++) {
		writeData.push( param );
	}

	// BKID_DAR_POW_REG(0x0D21) 
	if (UpdateBackupDataOffsetCP(0x1850002, 0x000000C0, 0x00000020, writeData)) {
		alert("Comlete : Please restart the camera.");
	}

	delete writeData;
	Disconnect();

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// Darwin Individual setting
///////////////////////////////////////////////////////////////////////////////
function DarwinIndividualSetting(
	deviceType, 	// デバイスタイプ
	settingVal		// Enable/ Disable
)
{
	if (! Connect()) {
		return false;
	}

	var writeData = new Array();
	var offset = 0x00;
	var param = 0x00;

	switch (deviceType) {
		case "shtType":			// シャッタータイプ
			offset = 0xC0;
			break;
		case "shtPiType":		// シャッターPIタイプ
			offset = 0xC6;
			break;
		case "intStrobe":		// 内蔵ストロボ有無
			offset = 0xC9;
			break;
		case "strobePopup":		// ポップアップユニット有無
			offset = 0xC3;
			break;
		case "extStrobe":		// 外付けストロボ有無
			offset = 0xD3;
			break;
		case "syncTerm":		// シンクロターミナル
			offset = 0xD4;
			break;
		case "battTerm":		// 筐体温度取得
			offset = 0xC8;
			break;
		case "virGrip":			// 縦位置グリップ有無
			offset = 0xD1;
			break;
		default:
			alert("Change Darwin Mecha setting FAIL !\ndeviceType:", deviceType);
			delete writeData;
			Disconnect();
			return false;
	}

	if (settingVal == "Enable") {
		param = 0x01;
	}
	else {
		param = 0x00;
	}

	writeData.push(param);

	// BKID_DAR_POW_REG(0x0D21) 
	// エラー時は関数内でコーションが表示される
	if (UpdateBackupDataOffsetCP(0x1850002, offset, 0x00000001, writeData)) {
		alert("Comlete : Please restart the camera.");
	}

	delete writeData;
	Disconnect();

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// Darwin Individual param
///////////////////////////////////////////////////////////////////////////////
function DarwinIndividualParam(
	deviceType, 	// デバイスタイプ
	settingVal		// 設定パラメータ
)
{
	if (! Connect()) {
		return false;
	}

	var writeData = new Array();
	var offset = 0x00;
	var param = 0x00;

	switch (deviceType) {
		case "shtType":			// シャッタータイプ
			offset = 0x50;
			break;
		case "shtPiType":		// シャッターPIタイプ
			offset = 0x56;
			break;
		case "intStrobe":		// 内蔵ストロボ有無
			offset = 0x59;
			break;
		case "strobePopup":		// ポップアップユニット有無
			offset = 0x53;
			break;
		case "extStrobe":		// 外付けストロボ有無
			offset = 0x63;
			break;
		case "syncTerm":		// シンクロターミナル
			offset = 0x64;
			break;
		case "battTerm":		// 筐体温度取得
			offset = 0x58;
			break;
		case "virGrip":			// 縦位置グリップ有無
			offset = 0x61;
			break;
		default:
			alert("Change Darwin Mecha setting FAIL !\ndeviceType:", deviceType);
			delete writeData;
			Disconnect();
			return false;
	}

	if (deviceType == "shtType") {
		switch (settingVal) {
			case "type1":		// 1/4000 shutter(NoPI)
				param = 0x31;
				break;
			case "type2":		// 1/4000 less-1C(NoPI)
				param = 0x33;
				break;
			case "type3":		// 1/4000 shutter
				param = 0x39;
				break;
			case "type4":		// 1/4000 less-1C
				param = 0x3B;
				break;
			case "type5":		// 1/8000 shutter
				param = 0x3A;
				break;
			case "type6":		// 1/4000 eshutter
				param = 0x0C;
				break;
			case "type7":		// 1/4000 単幕電磁shutter
				param = 0x0D;
				break;
			case "type8":		// 1/8000 先幕レスハイブリッドShutter
				param = 0x0E;
				break;
			case "type9":		// 遮光幕
				param = 0x0F;
				break;
			default:
				alert("Change Darwin Mecha setting FAIL !\nsettingVal:", settingVal);
				delete writeData;
				Disconnect();
				return false;
		}
		writeData.push(param);
	}
	else {
		writeData.push(parseInt(settingVal, 16));
	}

	// BKID_DAR_POW_REG(0x0D21) 
	// エラー時は関数内でコーションが表示される
	if (UpdateBackupDataOffsetCP(0x1850003, offset, 0x00000001, writeData)) {
		alert("Comlete : Please restart the camera.");
	}

	delete writeData;
	Disconnect();

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// Get Lens version
// 情報元 鏡筒設計部6課　西さん
///////////////////////////////////////////////////////////////////////////////
function GetLensVer(
	bAlert		// アラート (0:アラートを出さない/ 1:アラートを出す)
)
{
	LensVer_kind.innerHTML = "*";
	LensVer_Ver.innerHTML  = "*";

	if (! Connect()) {
		return false;
	}

	var ret = 0;
	var lensTable = {
		'8010': 'VX9100\(16mm\)',
		'8011': 'VX9101\(18-55mm\)',
		'8012': 'VX9102\(55-210mm\)',
		'8013': 'VX9103\(18-200mm\)',
		'8014': 'VX9104\(35mm Macro\)',
		'8015': 'VX9105\(24mm\)',
		'8016': 'VX9106\(40mm\)',
		'8018': 'VX9108\(11-18mm\)',
		'8019': 'VX9109\(16-50mm\)',
		'801E': 'VX9114\(fixed focal\)',
		'801F': 'VX9115\(35mm\)'
	};

	AdjustCmd.DataSize = 8;					// parameter size
	AdjustCmd.SetParam32(0, 0x700A00FC);	// DataOffset
	AdjustCmd.SetParam32(1, 0x00000001);	// DataSize
	ret |= !AdjustCmd.CmdIssue( 0x0404, 0x00FE);	// RAM READ
	var modelH = AdjustCmd.GetResponse8(0).toString(16);
	modelH = fnc_expand( modelH );

	AdjustCmd.DataSize = 8;					// parameter size
	AdjustCmd.SetParam32(0, 0x700A00FD);	// DataOffset
	AdjustCmd.SetParam32(1, 0x00000001);	// DataSize
	ret |= !AdjustCmd.CmdIssue( 0x0404, 0x00FE);	// RAM READ
	var modelL = AdjustCmd.GetResponse8(0).toString(16);
	modelL = fnc_expand( modelL );

	AdjustCmd.DataSize = 8;					// parameter size
	AdjustCmd.SetParam32(0, 0x700A00FE);	// DataOffset
	AdjustCmd.SetParam32(1, 0x00000001);	// DataSize
	ret |= !AdjustCmd.CmdIssue( 0x0404, 0x00FE);	// RAM READ
	var verMajor = AdjustCmd.GetResponse8(0).toString(16);
	verMajor = fnc_expand(verMajor);

	AdjustCmd.DataSize = 8;					// parameter size
	AdjustCmd.SetParam32(0, 0x700A00FF);	// DataOffset
	AdjustCmd.SetParam32(1, 0x00000001);	// DataSize
	ret |= !AdjustCmd.CmdIssue( 0x0404, 0x00FE);	// RAM READ
	var verMinor = AdjustCmd.GetResponse8(0).toString(16);
	verMinor = fnc_expand(verMinor);

	// Memory Read
	if (ret == 0) {
		LensVer_kind.innerHTML = "0x"  + modelH + modelL + " - " + lensTable[modelH + modelL];
		LensVer_Ver.innerHTML  = verMajor + "." + verMinor;
	}
	else {
		if (bAlert == 1) {
			alert("Get Lens Version FAIL");
		}
		Disconnect();
		return false;
	}

	Disconnect();

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// Clear Lens version
///////////////////////////////////////////////////////////////////////////////
function ClrLensVer()
{
	LensVer_kind.innerHTML = "*";
	LensVer_Ver.innerHTML  = "*";

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
function fnc_expand(
	num
)
{
	if(num=="0")
		num="00";
	if(num=="1")
		num="01";
	if(num=="2")
		num="02";
	if(num=="3")
		num="03";
	if(num=="4")
		num="04";
	if(num=="5")
		num="05";
	if(num=="6")
		num="06";
	if(num=="7")
		num="07";
	if(num=="8")
		num="08";
	if(num=="9")
		num="09";
	if(num=="a")
		num="0a";
	if(num=="b")
		num="0b";
	if(num=="c")
		num="0c";
	if(num=="d")
		num="0d";
	if(num=="e")
		num="0e";
	if(num=="f")
		num="0f";

	return num;
}
