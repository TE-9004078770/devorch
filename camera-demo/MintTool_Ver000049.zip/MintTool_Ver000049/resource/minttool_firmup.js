
var RTS_FILE_LIST = "\\\\dis-nas-public-001.cv.sony.co.jp\\public\\rel-rts\\firm-catalog.txt";
var RTS_FILE_LIST_SORT_TMP = ".\\tmp_stdout.txt"
var FIRMUP_SCRIPT_PATH = ".\\resource\\wscript\\firmup_caller.wsf";
var FIRMUP_CONFIRM_DIALOG_PATH = ".\\FirmConfirmDialog.hta";
var firmListMaker = null;
var firmupExecuter = null;

/*================================================================================
 * Initialize
================================================================================*/
window.addEventListener("load", function() {
	firmupExecuter = new FirmupExecuter();
	firmListMaker = new RTSFirmListMaker(firmupExecuter);

	// Set default setting
	if( settings.get("firmSrc") == "local" ) {
		firmListMaker.changeFirmSource(firmListMaker.firmupSrcLocal);
		firmListMaker.firmupSrcLocal.checked = "checked";
	}
	else {
		firmListMaker.changeFirmSource(firmListMaker.firmupSrcRTS);
		firmListMaker.firmupSrcRTS.checked = "checked";
	}
});


/*================================================================================
 * RTS Firm List Maker Class
================================================================================*/
RTSFirmListMaker = function(firmupExecuter)
{
	this.setNameList = document.getElementById("remote_firm_set_name_list");
	this.objList = document.getElementById("remote_firm_object_list");
	this.verList = document.getElementById("remote_firm_version_list");
	this.firmupSrcRTS = document.getElementById("firmup_src_rts");
	this.firmupSrcLocal = document.getElementById("firmup_src_local");
	this.RTSSelectForm = document.getElementById("Firmup_RTS_Form");
	this.LocalSelectForm = document.getElementById("Firmup_Local_Form");
	
	this.setNameList.addEventListener("change", function() {firmListMaker.changeFirmSelector(this);});
	this.objList.addEventListener("change", function() {firmListMaker.changeFirmSelector(this);});
	this.verList.addEventListener("change", function() {firmListMaker.changeFirmSelector(this);});

	this.firmupSrcRTS.addEventListener("click", function() {firmListMaker.changeFirmSource(this);});
	this.firmupSrcLocal.addEventListener("click", function() {firmListMaker.changeFirmSource(this);});
	
	this.fileInfoList = new Array();

	this.firmupExecuter = firmupExecuter;
}

/*--------------------------------------------------------------------------------
 * Get RTS file list
--------------------------------------------------------------------------------*/
RTSFirmListMaker.prototype.getRTSFileList = function(setNameNum)
{
	var list = new Array();
	var fso = new ActiveXObject("Scripting.FileSystemObject");

	if( !fso.FileExists(RTS_FILE_LIST) ) {
		mintole.error("RTS Firm list NOT Found");
		return list;
	}

	var wsh = new ActiveXObject("WScript.Shell");
	wsh.Run("cmd /c findstr /E /R \"" + setNameNum + "\.[^\\\\]*\\\\" + setNameNum + "\.[^\\\\]*\.zip\" " + RTS_FILE_LIST + " | sort > " + RTS_FILE_LIST_SORT_TMP, 0, true);
	delete wsh;

	if( fso.FileExists(RTS_FILE_LIST_SORT_TMP) )
	{
		var file = fso.OpenTextFile(RTS_FILE_LIST_SORT_TMP);
		if( !file.AtEndOfStream ) {
			list = file.ReadAll().split(/\r\n|\r|\n/);
			mintole.debug("Success to read RTS File List: " + list.length);
		}
		else {
			mintole.warning("RTS File List is empty");
		}
		file.Close();
		fso.DeleteFile(RTS_FILE_LIST_SORT_TMP);

		delete file;
	}
	else {
		mintole.error("Fail to get RTS Firm list");
	}
	delete fso;

	return list;
}

/*--------------------------------------------------------------------------------
 * Make file information (by directory & file name)
--------------------------------------------------------------------------------*/
RTSFirmListMaker.prototype.makeFileInfo = function()
{
	setVer.readDefhd();
	var setName = setVer.getModelInfoSetName();
	if( setName == "0" ) { return; }

	var fileList = this.getRTSFileList(setName + "_00").reverse();
	for( var i = 0; i < fileList.length; i++ ) {
		var filePath = fileList[i];
		if( filePath == "" ) { continue; }

		var splitFilePath = filePath.split("\\");
		this.fileInfoList.push({
			"path" : filePath,
			"setName" : splitFilePath.slice(-3)[0],
			"date" : splitFilePath.slice(-1)[0].split(".")[1].split("_")[0],
			"object" : splitFilePath.slice(-1)[0].split(".")[1].split("_").slice(-1)[0],
		});
	}
}

/*--------------------------------------------------------------------------------
 * List up
--------------------------------------------------------------------------------*/
RTSFirmListMaker.prototype.listup = function()
{
	this.makeFileInfo();

	// Clean list
	this.cleanList(this.setNameList);

	var setNameList = new Array();
	for( var i = 0; i < this.fileInfoList.length; i++ ) {
		var fileInfo = this.fileInfoList[i];
		
		if( setNameList.indexOf(fileInfo.setName) == -1 ) {
			setNameList.push(fileInfo.setName);
		}
	}
	for( var i = 0; i < setNameList.length; i++ ) {
		var opt = this.setNameList.appendChild(document.createElement("option"));
		opt.value = setNameList[i];
		opt.innerHTML = setNameList[i];
	}

	this.changeFirmSelector(this.setNameList);
}

/*--------------------------------------------------------------------------------
 * Clean list
--------------------------------------------------------------------------------*/
RTSFirmListMaker.prototype.cleanList = function(list)
{
	while( list.firstChild ) { list.removeChild(list.firstChild); }
}

/*--------------------------------------------------------------------------------
 * Select RTS firmware
--------------------------------------------------------------------------------*/
RTSFirmListMaker.prototype.selectRTSFirmFile = function()
{
	var remoteFirmSetName = this.setNameList.value;
	var remoteFirmObject = this.objList.value;
	var remoteFirmVersion = this.verList.value;

	if( remoteFirmSetName != "" ) {
		for( var i = 0; i < this.fileInfoList.length; i++ ) {
			var fileInfo = this.fileInfoList[i];

			if( fileInfo.setName != remoteFirmSetName ) { continue; }
			if( fileInfo.object != remoteFirmObject ) { continue; }
			if( fileInfo.date != remoteFirmVersion ) { continue; }

			this.firmupExecuter.RTSFirmFilePath = fileInfo.path;
		}
	}
	if( this.firmupExecuter.RTSFirmFilePath ) {
		mintole.debug("Selected RTS Firm: " + this.firmupExecuter.RTSFirmFilePath);
	}
}

/*--------------------------------------------------------------------------------
 * Change firm selector (Event handler)
--------------------------------------------------------------------------------*/
RTSFirmListMaker.prototype.changeFirmSelector = function(self)
{
	if( self.id != "remote_firm_version_list" )
	{
		var remoteFirmSetName = this.setNameList.value;
		var remoteFirmObject = this.objList.value;
	
		// Clean list
		this.cleanList(this.verList);
		
		for( var i = 0; i < this.fileInfoList.length; i++ ) {
			var fileInfo = this.fileInfoList[i];

			if( fileInfo.setName != remoteFirmSetName ) { continue; }
			if( fileInfo.object != remoteFirmObject ) { continue; }
			
			var opt = this.verList.appendChild(document.createElement("option"));
			opt.value = fileInfo.date;
			opt.innerHTML = fileInfo.date;
		}

		this.firmupExecuter.RTSFirmFilePath = "";
	}

	this.selectRTSFirmFile();
}

/*--------------------------------------------------------------------------------
 * Change firm source (Event handler)
--------------------------------------------------------------------------------*/
RTSFirmListMaker.prototype.changeFirmSource = function(self)
{
	if( self.value == "rts" ) {
		this.RTSSelectForm.style.display = "block";
		this.LocalSelectForm.style.display = "none";

		this.selectRTSFirmFile();
		mintole.debug("Selected RTS Firm");

		settings.set("firmSrc", "rts");
	}
	else {
		this.RTSSelectForm.style.display = "none";
		this.LocalSelectForm.style.display = "block";

		this.firmupExecuter.RTSFirmFilePath = "";
		mintole.debug("Selected Local Firm");

		settings.set("firmSrc", "local");
	}
	settings.write();
}


/*================================================================================
 * Firm up executer Class
================================================================================*/
FirmupExecuter = function()
{
	this.firmUpTitle = document.getElementById("Firmup_title");
	this.firmUpProgerss = document.createElement("progress");
	this.firmupBlk = document.getElementById("Firmup");
	this.localFirmFile = document.getElementById("Firmup_firmFile");
	this.rtsFirmKeep = document.getElementById("Firmup_firmkeep");

	settings.linkElmToKey("firmKeep", this.rtsFirmKeep);

	this.firmFilePath = "";
	this.RTSFirmFilePath = "";
}

/*--------------------------------------------------------------------------------
 * Change view
--------------------------------------------------------------------------------*/
FirmupExecuter.prototype.changeView = function(isOn)
{
	var disabled = "disabled";

	try {
		this.firmUpTitle.removeChild(this.firmUpProgerss);
	}
	catch (e) {}

	if(isOn) {
		this.firmUpTitle.appendChild(this.firmUpProgerss);
		disabled = "disabled";
	}
	else {
		disabled = "";
	}
	
	var firmupElms = this.firmupBlk.getElementsByTagName("input");
	for( var i = 0; i < firmupElms.length; i++ ) {
		firmupElms[i].disabled = disabled;
	}
	firmupElms = this.firmupBlk.getElementsByTagName("select");
	for( var i = 0; i < firmupElms.length; i++ ) {
		firmupElms[i].disabled = disabled;
	}
}

/*--------------------------------------------------------------------------------
 * Get RTS firmup file
--------------------------------------------------------------------------------*/
FirmupExecuter.prototype.getRTSFirmupFile = function()
{
	if( this.RTSFirmFilePath == "" ) { return; }
	
	var wsh = new ActiveXObject("WScript.Shell");
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	var firmTmpDir = CurrentDir.replace(/\\$/, "") + "\\firm_tmp\\";
	this.firmFilePath = firmTmpDir + fso.GetFileName(this.RTSFirmFilePath);

	// Skip download from RTS, if already exits
	if( !fso.FileExists(this.firmFilePath) )
	{
		wsh.Run("cmd /c copy /b /y " + this.RTSFirmFilePath + " " + firmTmpDir, 0, true);
		
		mintole.debug("Copy RTS Firmware: " + this.RTSFirmFilePath + " -> " + firmTmpDir);

		if( !fso.FileExists(this.firmFilePath) ) {
			mintole.alert("Fail to get Firmware file from RTS");
		}
	}
	else {
		mintole.info("Firmware already exists");
	}
	
	delete wsh;
	delete fso;
}

/*--------------------------------------------------------------------------------
 * Clean RTS firmup file
--------------------------------------------------------------------------------*/
FirmupExecuter.prototype.cleanRTSFirmupFile = function()
{
	if( this.RTSFirmFilePath == "" ) { return; }
	if( this.rtsFirmKeep.value != "" ) { return; }

	var fso = new ActiveXObject("Scripting.FileSystemObject");
	fso.DeleteFile(this.firmFilePath);
	delete fso;
	
	mintole.debug("Cleaned Temporary File: " + this.firmFilePath);
}

/*--------------------------------------------------------------------------------
 * Select firmup file
--------------------------------------------------------------------------------*/
FirmupExecuter.prototype.selectFirmupFile = function()
{
	if( this.RTSFirmFilePath == "" ) {
		this.firmFilePath = this.localFirmFile.value;
		mintole.debug("Selected local Firmware: " + this.firmFilePath);
	}
	else {
		this.getRTSFirmupFile();
		mintole.debug("Selected RTS Firmware: " + this.RTSFirmFilePath);
	}
}

/*--------------------------------------------------------------------------------
 * Confirm updating with SYSKAKU firmware
--------------------------------------------------------------------------------*/
FirmupExecuter.prototype.confirmSysDialog = function(FnameStr)
{
	var url = FIRMUP_CONFIRM_DIALOG_PATH;
	var winWidth = "800px";
	var winHeight = "400px";
	var options = "dialogWidth=" + winWidth + ";dialogHeight=" + winHeight + ";left=500 ;center=1;resizable=1;minimize=0;maximize=0;";

	// Argument for modal dialog
	var sendArguments = new Array(FnameStr);

	// Open dialog
	var returnValue = window.showModalDialog(url, sendArguments, options);

	//Judge the return value
	if( returnValue == 1 ) {
		return true;
	}
	else if( returnValue == 0 ) {
		return false;
	}
}

/*--------------------------------------------------------------------------------
 * Check firmware file target
--------------------------------------------------------------------------------*/
FirmupExecuter.prototype.checkFirmTarget = function()
{
	var ret = true;

	// Get Set name
	setVer.readDefhd();
	var setName = setVer.getModelInfoSetName();

	var FirmName = this.firmFilePath.split("\\").slice(-1)[0];
	var fileSetName = FirmName.split("_")[0];

	if(setName != fileSetName) {
		mintole.warning("Applying firmware for different SetName");
		mintole.debug("SetName: " + setName + ", FileName: " + fileSetName);

		// Detecting the file is for Sys-Kaku by the name including "_SYS_"
		var search_sys_result = FirmName.indexOf("_SYS_");
		if (search_sys_result > 0) {
			var FnameLustIndex = FirmName.length + 1;
			var FnameStr = FirmName.substring(search_sys_result+1, FnameLustIndex);

			if (! this.confirmSysDialog(FnameStr)) {
				ret = false;
			}
		}
		else {
			// Firmware file is NOT for Sys-Kaku
			if (confirm(" ! ! ! Caution ! ! ! Diffarent Model Firm  ! ! ! \n\n Do you want to update the firmware of different model?")) {
				if (! confirm("Really sure?  Different model")) {
					ret = false;
				}
			}
			else {
				ret = false;
			}
		}
	}

	if( ret == false ) {
		mintole.alert("Update Canceled");
	}
	return ret;
}

/*--------------------------------------------------------------------------------
 * Check firmware file os signed
--------------------------------------------------------------------------------*/
FirmupExecuter.prototype.checkFirmSigned = function()
{
	if( !Connect() ) {
		return false;
	}
	var isSigned = false;

	AdjustCmd.DataSize = 0;
	if ( AdjustCmd.CmdIssue(0x0604, 0x4015)) {
		if(AdjustCmd.GetResponse8(0) != 0){
			isSigned = true;
		}
	}
	Disconnect();

	// Get Set name
	var FirmName = this.firmFilePath.split("\\").slice(-1)[0];
	var srcSigned = FirmName.match(/_sign/) != null;

	if(isSigned != srcSigned) {
		mintole.alert( "Unable to update due to signature mismatch" );
		return false;
	}
	return true;
}

/*--------------------------------------------------------------------------------
 * Firmware update
 * Args[0]: Reboot flag (0:No reboot / 1:Reboot)
--------------------------------------------------------------------------------*/
FirmupExecuter.prototype.execute = function(reboot_Flag)
{
	if(false == chkMainLSI()) {
		mintole.error("Reject because of MainLSI difference");
		return false;
	}

	this.changeView(true);
	this.selectFirmupFile();
	this.changeView(false);

	if(this.firmFilePath == "") {
		mintole.alert("Firmware Path is empty");
		return false;
	}

	if( !this.checkFirmTarget() ) {
		return false;
	}

	if( !this.checkFirmSigned() ) {
		return false;
	}

	this.changeView(true);

	// Execute firmware update
	mintole.debug("Start firmware update");
	var wsh = new ActiveXObject("WScript.Shell");
	var ret = wsh.Run(["wscript", FIRMUP_SCRIPT_PATH, this.firmFilePath, reboot_Flag].map(function(x) {return "\"" + x + "\""}).join(" "), 0, true);
	delete wsh;
	
	this.cleanRTSFirmupFile();
	
	this.changeView(false);

	if( ret == 0 ) {
		if( reboot_Flag == 1 ) {
			mintole.alert("Firmware Update Complete. Please Wait Boot.");
		}
		else {
			mintole.alert("Firmware Update Complete.");
		}
	}
	else {
		mintole.alert("Firmware Update FAIL");
	}

	return true;
}
