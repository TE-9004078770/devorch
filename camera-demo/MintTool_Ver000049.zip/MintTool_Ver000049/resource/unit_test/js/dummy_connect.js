var AdjustCmd = null;
var FileCtl = null;
var FirmUpCtl = null;
var MemDump = null;
var connectNestNum = 0;

var AdjustCtrl = null;
var FileControl = null;
var FirmupCtrl = null;
var MemoryDump = null;
var ActiveXObject = null;

/*================================================================================
 * AdjustCtrl
================================================================================*/
var org_AdjustCtrl = function() {
	this.DataSize = 0;
	this.ResSize = 0;
}
org_AdjustCtrl.prototype.Connect = function(dev) {
	return true;
}
org_AdjustCtrl.prototype.SetParam8 = function(offset, data) {
	return true;
}
org_AdjustCtrl.prototype.SetParam16 = function(offset, data) {
	return true;
}
org_AdjustCtrl.prototype.SetParam32 = function(offset, data) {
	return true;
}
org_AdjustCtrl.prototype.GetResponse8 = function(idx) {
	return 0;
}
org_AdjustCtrl.prototype.GetResponse16 = function(idx) {
	return 0;
}
org_AdjustCtrl.prototype.GetResponse32 = function(idx) {
	return 0;
}
org_AdjustCtrl.prototype.CmdIssue = function(blk, code) {
	return true;
}

/*================================================================================
 * FileControl
================================================================================*/
var org_FileControl = function() {
}
org_FileControl.prototype.Connect = function(dev) {
	return true;
}
org_FileControl.prototype.FileRead = function(localPath, remotePath) {
	return true;
}
org_FileControl.prototype.FileWrite = function(remotePath, localPath) {
	return true;
}
org_FileControl.prototype.FileDelete = function(remotePath) {
	return true;
}

/*================================================================================
 * FirmupCtrl
================================================================================*/
var org_FirmupCtrl = function() {
}
org_FirmupCtrl.prototype.Connect = function(dev) {
	return true;
}
org_FirmupCtrl.prototype.Update = function(firmUpFile) {
	return true;
}

/*================================================================================
 * MemoryDump
================================================================================*/
var org_MemoryDump = function() {
	this.ReadDataSize = 0;
}
org_MemoryDump.prototype.Connect = function(dev) {
	return true;
}
org_MemoryDump.prototype.ReadData = function(addr, size) {
	return true;
}
org_MemoryDump.prototype.ReadDataEX = function(addr, size, type) {
	return true;
}
org_MemoryDump.prototype.GetData = function(idx) {
	return true;
}
org_MemoryDump.prototype.PutData = function(offset, data) {
	return true;
}
org_MemoryDump.prototype.WriteData = function(addr) {
	return true;
}
org_MemoryDump.prototype.WriteDataEX = function(addr, type) {
	return true;
}
org_MemoryDump.prototype.SavetoFile = function(filePath, size, offset, writeOver) {
	return true;
}


/*================================================================================
ActiveXObject
================================================================================*/
var org_ActiveXObject = function(type) {
}
org_ActiveXObject.prototype.Run = function(cmd, style, finWait) {
	return true;
}
org_ActiveXObject.prototype.DeleteFile = function(filename) {
	return true;
}
org_ActiveXObject.prototype.GetParentFolderName = function(filename) {
	return true;
}

/*================================================================================
 * Prepare to Connect
================================================================================*/
function PrepConnect()
{
	AdjustCtrl = new org_AdjustCtrl();
	FileControl = new org_FileControl();
	FirmupCtrl = new org_FirmupCtrl();
	MemoryDump = new org_MemoryDump();
	ActiveXObject = org_ActiveXObject;
}

/*================================================================================
 * Clean up to Connect
================================================================================*/
function CleanUpConnect()
{
	delete AdjustCtrl;
	delete FileControl;
	delete FirmupCtrl;
	delete MemoryDump;
	delete ActiveXObject;
}

/*================================================================================
 * Connect
================================================================================*/
function Connect()
{
	AdjustCmd	= AdjustCtrl;
	FileCtl 	= FileControl;
	FirmUpCtl	= FirmupCtrl;
	MemDump 	= MemoryDump;

	var ret = AdjustCmd.Connect() && FileCtl.Connect() && FirmUpCtl.Connect() && MemDump.Connect();

	if( ret ) {
		connectNestNum++;
		mintole.debug("Dummy Connect: " + connectNestNum);
	}

	return ret;
}

/*================================================================================
 * Disconnect
================================================================================*/
function Disconnect()
{
	if( connectNestNum > 0 ) { connectNestNum--; }
	mintole.debug("Dummy Disconnect: " + connectNestNum);
	
	delete AdjustCmd;
	delete FileCtl;
	delete FirmUpCtl;
	delete MemDump;

	return true;
}

/*================================================================================
 * Is already connected
================================================================================*/
function IsConnected()
{
	return (AdjustCmd && FileCtl && FirmUpCtl && MemDump);
}
