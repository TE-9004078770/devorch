
var testNum = 0;
var okNum = 0;
var ngNum = 0;

//=================================================================================
// main
//=================================================================================
function test_main(param)
{
	testNum = param.test_list.length;
	for( var i = 0; i < testNum; i++ ) {
		var test = param.test_list[i];

		var ret = "NG";
		PrepConnect();

		if( test.func(test.param) ) {
			ret = "OK";
			okNum++;
		}
		else {
			ngNum++;
		}
		printBody("Test[" + (i+1) + "] result : [" + test.func.name + "(" + JSON.stringify(test.param) + ")] ==> " + ret + "\n");

		CleanUpConnect();
	}

	printBody("\n");
	printBody("============================================================\n");
	printBody("Test name      : " + param.test_name + "\n");
	printBody("Test total num : " + testNum + "\n");
	printBody("Test OK num    : " + okNum + "\n");
	printBody("Test NG num    : " + ngNum + "\n");
}
