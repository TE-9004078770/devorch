
var MemDumpMaxSize = 10*1000*1000;

var ReadBackupData32_cb = function(bkid_addr, bkValues) { return true; }
var ReadBackupDataCP32_cb = function(bkid_addr, bkValues) { return true; }


//=================================================================================
// ReadBackupData32 stub
//=================================================================================
function ReadBackupData32(bkid_addr, bkValues)
{
	var ret = ReadBackupData32_cb(bkid_addr, bkValues);
	return ret;
}

//=================================================================================
// ReadBackupDataCP32 stub
//=================================================================================
function ReadBackupDataCP32(bkid_addr, bkValues)
{
	var ret = ReadBackupDataCP32_cb(bkid_addr, bkValues);
	return ret;
}

//=================================================================================
// MemDumpSaveToFile
//=================================================================================
function test_MemDumpSaveToFile(param)
{
	var ngFlag = false;
	var seqNo = 0;
	var FILE_NAME = "HOGEHOGE.txt";
	var DATA_ADDR = 0x12345678;
	var DATA_SIZE = 32;

	MemoryDump.Connect = function(dev) {
		seqNo++;
		return param["Connect"]["return"];
	}
	MemoryDump.ReadData = function(addr, size) {
		seqNo++;
		if( addr != DATA_ADDR ) {
			ngFlag = true;
		}
		if( size != DATA_SIZE ) {
			ngFlag = true;
		}
		this.ReadDataSize = size;
		return param["ReadData"]["return"];
	}
	MemoryDump.SavetoFile = function(file, size, offset, ovrWr) {
		seqNo++;

		if( file != FILE_NAME ) {
			ngFlag = true;
		}
		if( size != this.ReadDataSize ) {
			ngFlag = true;
		}
		if( offset != 0 ) {
			ngFlag = true;
		}
		if( !ovrWr ) {
			ngFlag = true;
		}
		return param["SavetoFile"]["return"];
	}
	
	var ret = false;
	switch(param["NG_param"]) {
	case "file":
		ret = MemDumpSaveToFile("", DATA_ADDR, DATA_SIZE);
		break;
	case "addr":
		ret = MemDumpSaveToFile(FILE_NAME, 0, DATA_SIZE);
		break;
	case "size":
		ret = MemDumpSaveToFile(FILE_NAME, DATA_ADDR, 0);
		break;
	default:
		ret = MemDumpSaveToFile(FILE_NAME, DATA_ADDR, DATA_SIZE);
		break;
	}

	// Sequence check
	if( seqNo != param["seqNo"] ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == param["ret"] && ngFlag == false;
}

//=================================================================================
// MemDumpSaveToFileCP
//=================================================================================
function test_MemDumpSaveToFileCP(param)
{
	var ngFlag = false;
	var seqNo = 0;
	var tmpFileIdx = 0;
	var FILE_NAME = "HOGEHOGE.txt";
	var DATA_ADDR = 0x12345678;
	var DATA_SIZE = 32 * MemDumpMaxSize;

	MemoryDump.Connect = function(dev) {
		seqNo++;
		return param["Connect"]["return"];
	}
	MemoryDump.ReadDataEX = function(addr, size, cpu) {
		seqNo++;
		if( addr != DATA_ADDR ) {
			ngFlag = true;
		}
		if( size != MemDumpMaxSize && DATA_SIZE % MemDumpMaxSize != size ) {
			ngFlag = true;
		}
		if( cpu != 1 ) {
			ngFlag = true;
		}
		this.ReadDataSize = size;
		DATA_ADDR += size;
		return param["ReadDataEX"]["return"];
	}
	MemoryDump.SavetoFile = function(file, size, offset, ovrWr) {
		seqNo++;

		if( file.indexOf(FILE_NAME + "_" + tmpFileIdx) < 0 ) {
			ngFlag = true;
		}
		if( size != this.ReadDataSize ) {
			ngFlag = true;
		}
		if( offset != 0 ) {
			ngFlag = true;
		}
		if( !ovrWr ) {
			ngFlag = true;
		}
		tmpFileIdx++;

		return param["SavetoFile"]["return"];
	}
	
	var ret = false;
	switch(param["NG_param"]) {
	case "file":
		ret = MemDumpSaveToFileCP("", DATA_ADDR, DATA_SIZE);
		break;
	case "addr":
		ret = MemDumpSaveToFileCP(FILE_NAME, 0, DATA_SIZE);
		break;
	case "size":
		ret = MemDumpSaveToFileCP(FILE_NAME, DATA_ADDR, 0);
		break;
	default:
		ret = MemDumpSaveToFileCP(FILE_NAME, DATA_ADDR, DATA_SIZE);
		break;
	}

	// Sequence check
	if( seqNo != param["seqNo"] ) {
		printBody("Sequence number error:" + seqNo + "\n");
		ngFlag = true;
	}

	return ret == param["ret"] && ngFlag == false;
}

//=================================================================================
// Normal pattern for MemDumpSaveToFileByBackupId
//=================================================================================
function test_MemDumpSaveToFileByBackupId(param)
{
	var ngFlag = false;
	var seqNo = 0;
	var FILE_NAME = "HOGEHOGE.txt";
	var BKID_ADDR = 0x01230123;
	var BKID_SIZE = 0x98769876;
	var RET_ADDR = 0x123456789abcde;
	var RET_SIZE = 0x32103210;

	MemoryDump.Connect = function(dev) {
		seqNo++;
		return param["Connect"]["return"];
	}
	MemoryDump.ReadData = function(addr, size) {
		seqNo++;
		if( addr != RET_ADDR ) {
			ngFlag = true;
		}
		if( size != RET_SIZE ) {
			ngFlag = true;
		}
		this.ReadDataSize = size;
		return param["ReadData"]["return"];
	}
	MemoryDump.SavetoFile = function(file, size, offset, ovrWr) {
		seqNo++;

		if( file != FILE_NAME ) {
			ngFlag = true;
		}
		if( size != this.ReadDataSize ) {
			ngFlag = true;
		}
		if( offset != 0 ) {
			ngFlag = true;
		}
		if( !ovrWr ) {
			ngFlag = true;
		}
		return param["SavetoFile"]["return"];
	}
	ReadBackupData32_cb = function(bkid_addr, bkValues) {
		if( bkid_addr == BKID_ADDR ) {
			bkValues.push(RET_ADDR & 0xFFFFFFFF);
			bkValues.push((RET_ADDR / 0x100000000) & 0xFFFFFFFF);	// (RET_ADDR >> 32) & 0xFFFFFFFF
		}
		else if( bkid_addr == BKID_SIZE ) {
			bkValues.push(RET_SIZE);
			bkValues.push(0);
		}
		else {
			ngFlag = true;
		}
		if( !bkValues || !Array.isArray(bkValues) ) {
			ngFlag = true;
		}
		return param["readBk_ret"];
	}
	
	var ret = false;
	switch(param["NG_param"]) {
	case "file":
		ret = MemDumpSaveToFileByBackupId("", BKID_ADDR, BKID_SIZE);
		break;
	case "addr":
		ret = MemDumpSaveToFileByBackupId(FILE_NAME, 0, BKID_SIZE);
		break;
	case "size":
		ret = MemDumpSaveToFileByBackupId(FILE_NAME, BKID_ADDR, 0);
		break;
	default:
		ret = MemDumpSaveToFileByBackupId(FILE_NAME, BKID_ADDR, BKID_SIZE);
		break;
	}

	ReadBackupData32_cb = function(bkid_addr, bkValues) { return true; }

	// Sequence check
	if( seqNo != param["seqNo"] ) {
		printBody("Sequence number error: " + seqNo + "\n");
		ngFlag = true;
	}

	return ret == param["ret"] && ngFlag == false;
}

//=================================================================================
// Normal pattern for MemDumpSaveToFileByBackupIdCP
//=================================================================================
function test_MemDumpSaveToFileByBackupIdCP(param)
{
	var ngFlag = false;
	var seqNo = 0;
	var FILE_NAME = "HOGEHOGE.txt";
	var BKID_ADDR = 0x01230123;
	var BKID_SIZE = 0x98769876;
	var RET_ADDR = 0x123456789abcde;
	var RET_SIZE = 0x32103210;

	MemoryDump.Connect = function(dev) {
		seqNo++;
		return param["Connect"]["return"];
	}
	MemoryDump.ReadDataEx = function(addr, size) {
		seqNo++;
		if( addr != RET_ADDR ) {
			ngFlag = true;
		}
		if( size != RET_SIZE ) {
			ngFlag = true;
		}
		this.ReadDataSize = size;
		return param["ReadDataEx"]["return"];
	}
	MemoryDump.SavetoFile = function(file, size, offset, ovrWr) {
		seqNo++;

		if( file.indexOf(FILE_NAME.replace(/\.[^\.]+$/, "")) < 0 ) {
			ngFlag = true;
		}
		if( size != this.ReadDataSize ) {
			ngFlag = true;
		}
		if( offset != 0 ) {
			ngFlag = true;
		}
		if( !ovrWr ) {
			ngFlag = true;
		}
		return param["SavetoFile"]["return"];
	}
	ReadBackupDataCP32_cb = function(bkid_addr, bkValues) {
		if( bkid_addr == BKID_ADDR ) {
			bkValues.push(RET_ADDR & 0xFFFFFFFF);
			bkValues.push((RET_ADDR / 0x100000000) & 0xFFFFFFFF);	// (RET_ADDR >> 32) & 0xFFFFFFFF
		}
		else if( bkid_addr == BKID_SIZE ) {
			bkValues.push(RET_SIZE);
			bkValues.push(0);
		}
		else {
			ngFlag = true;
		}
		if( !bkValues || !Array.isArray(bkValues) ) {
			ngFlag = true;
		}
		return param["readBk_ret"];
	}
	
	var ret = false;
	switch(param["NG_param"]) {
	case "file":
		ret = MemDumpSaveToFileByBackupIdCP("", BKID_ADDR, BKID_SIZE);
		break;
	case "addr":
		ret = MemDumpSaveToFileByBackupIdCP(FILE_NAME, 0, BKID_SIZE);
		break;
	case "size":
		ret = MemDumpSaveToFileByBackupIdCP(FILE_NAME, BKID_ADDR, 0);
		break;
	default:
		ret = MemDumpSaveToFileByBackupIdCP(FILE_NAME, BKID_ADDR, BKID_SIZE);
		break;
	}

	ReadBackupDataCP32_cb = function(bkid_addr, bkValues) { return true; }

	// Sequence check
	if( seqNo != param["seqNo"] ) {
		printBody("Sequence number error: " + seqNo + "\n");
		ngFlag = true;
	}
	
	return ret == param["ret"] && ngFlag == false;
}

//=================================================================================
// Normal pattern for MemDumpSaveToFileByBackupIdForSusLog
//=================================================================================
function test_MemDumpSaveToFileByBackupIdForSusLog(param)
{
	var ngFlag = false;
	var seqNo = 0;
	var FILE_NAME = "HOGEHOGE.txt";
	var BKID_ADDR = 0x01230123;
	var BKID_SIZE = 0x98769876;
	var RET_ADDR = 0x123456789abcde;
	var RET_SIZE = 0x32103210;

	MemoryDump.Connect = function(dev) {
		seqNo++;
		return param["Connect"]["return"];
	}
	MemoryDump.ReadData = function(addr, size) {
		seqNo++;
		if( addr != RET_ADDR ) {
			ngFlag = true;
		}
		if( size != RET_SIZE ) {
			ngFlag = true;
		}
		this.ReadDataSize = size;
		return param["ReadData"]["return"];
	}
	MemoryDump.SavetoFile = function(file, size, offset, ovrWr) {
		seqNo++;

		if( file != FILE_NAME ) {
			ngFlag = true;
		}
		if( size != this.ReadDataSize ) {
			ngFlag = true;
		}
		if( offset != 0 ) {
			ngFlag = true;
		}
		if( !ovrWr ) {
			ngFlag = true;
		}
		return param["SavetoFile"]["return"];
	}
	ReadBackupData32_cb = function(bkid_addr, bkValues) {
		if( bkid_addr == BKID_ADDR ) {
			bkValues.push(RET_ADDR & 0xFFFFFFFF);
			bkValues.push((RET_ADDR / 0x100000000) & 0xFFFFFFFF);	// (RET_ADDR >> 32) & 0xFFFFFFFF
		}
		else if( bkid_addr == BKID_SIZE ) {
			bkValues.push(RET_SIZE);
			bkValues.push(0);
		}
		else {
			ngFlag = true;
		}
		if( !bkValues || !Array.isArray(bkValues) ) {
			ngFlag = true;
		}
		return param["readBk_ret"];
	}
	ReadBackupDataCP32_cb = function(bkid_addr, bkValues) {
		if( bkid_addr == BKID_ADDR ) {
			bkValues.push(RET_ADDR & 0xFFFFFFFF);
			bkValues.push((RET_ADDR / 0x100000000) & 0xFFFFFFFF);	// (RET_ADDR >> 32) & 0xFFFFFFFF
		}
		else if( bkid_addr == BKID_SIZE ) {
			bkValues.push(RET_SIZE);
			bkValues.push(0);
		}
		else {
			ngFlag = true;
		}
		if( !bkValues || !Array.isArray(bkValues) ) {
			ngFlag = true;
		}
		return param["readBk_ret"];
	}
	
	var ret = false;
	switch(param["NG_param"]) {
	case "file":
		ret = MemDumpSaveToFileByBackupIdForSusLog("", BKID_ADDR, BKID_SIZE);
		break;
	case "addr":
		ret = MemDumpSaveToFileByBackupIdForSusLog(FILE_NAME, 0, BKID_SIZE);
		break;
	case "size":
		ret = MemDumpSaveToFileByBackupIdForSusLog(FILE_NAME, BKID_ADDR, 0);
		break;
	default:
		ret = MemDumpSaveToFileByBackupIdForSusLog(FILE_NAME, BKID_ADDR, BKID_SIZE);
		break;
	}

	ReadBackupData32_cb = function(bkid_addr, bkValues) { return true; }
	ReadBackupDataCP32_cb = function(bkid_addr, bkValues) { return true; }

	// Sequence check
	if( seqNo != param["seqNo"] ) {
		printBody("Sequence number error: " + seqNo + "\n");
		ngFlag = true;
	}

	return ret == param["ret"] && ngFlag == false;
}


var test_list = new Array(
	// MemDumpSaveToFile
	{func: test_MemDumpSaveToFile, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"SavetoFile": {"return": true},
		"seqNo": 3,
		"NG_param": "none",
		"ret": true
	}},
	{func: test_MemDumpSaveToFile, param: {
		"Connect": {"return": false},
		"ReadData": {"return": true},
		"SavetoFile": {"return": true},
		"seqNo": 1,
		"NG_param": "none",
		"ret": false
	}},
	{func: test_MemDumpSaveToFile, param: {
		"Connect": {"return": true},
		"ReadData": {"return": false},
		"SavetoFile": {"return": true},
		"seqNo": 2,
		"NG_param": "none",
		"ret": false
	}},
	{func: test_MemDumpSaveToFile, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"SavetoFile": {"return": false},
		"seqNo": 3,
		"NG_param": "none",
		"ret": false
	}},
	{func: test_MemDumpSaveToFile, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"SavetoFile": {"return": false},
		"seqNo": 0,
		"NG_param": "file",
		"ret": false
	}},
	{func: test_MemDumpSaveToFile, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"SavetoFile": {"return": false},
		"seqNo": 0,
		"NG_param": "addr",
		"ret": false
	}},
	{func: test_MemDumpSaveToFile, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"SavetoFile": {"return": false},
		"seqNo": 0,
		"NG_param": "size",
		"ret": false
	}},

	// MemDumpSaveToFileCP
	{func: test_MemDumpSaveToFileCP, param: {
		"Connect": {"return": true},
		"ReadDataEX": {"return": true},
		"SavetoFile": {"return": true},
		"seqNo": 65,
		"NG_param": "none",
		"ret": true
	}},
	{func: test_MemDumpSaveToFileCP, param: {
		"Connect": {"return": false},
		"ReadDataEX": {"return": true},
		"SavetoFile": {"return": true},
		"seqNo": 1,
		"NG_param": "none",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileCP, param: {
		"Connect": {"return": true},
		"ReadDataEX": {"return": false},
		"SavetoFile": {"return": true},
		"seqNo": 2,
		"NG_param": "none",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileCP, param: {
		"Connect": {"return": true},
		"ReadDataEX": {"return": true},
		"SavetoFile": {"return": false},
		"seqNo": 3,
		"NG_param": "none",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileCP, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"SavetoFile": {"return": false},
		"seqNo": 0,
		"NG_param": "file",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileCP, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"SavetoFile": {"return": false},
		"seqNo": 0,
		"NG_param": "addr",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileCP, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"SavetoFile": {"return": false},
		"seqNo": 0,
		"NG_param": "size",
		"ret": false
	}},
	
	// MemDumpSaveToFileByBackupId
	{func: test_MemDumpSaveToFileByBackupId, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": true,
		"seqNo": 3,
		"NG_param": "none",
		"ret": true
	}},
	{func: test_MemDumpSaveToFileByBackupId, param: {
		"Connect": {"return": false},
		"ReadData": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": true,
		"seqNo": 1,
		"NG_param": "none",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileByBackupId, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": false,
		"seqNo": 0,
		"NG_param": "none",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileByBackupId, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": true,
		"seqNo": 0,
		"NG_param": "file",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileByBackupId, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": true,
		"seqNo": 0,
		"NG_param": "addr",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileByBackupId, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": true,
		"seqNo": 0,
		"NG_param": "size",
		"ret": false
	}},
	
	// MemDumpSaveToFileByBackupIdCP
	{func: test_MemDumpSaveToFileByBackupIdCP, param: {
		"Connect": {"return": true},
		"ReadDataEx": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": true,
		"seqNo": 85,
		"NG_param": "none",
		"ret": true
	}},
	{func: test_MemDumpSaveToFileByBackupIdCP, param: {
		"Connect": {"return": false},
		"ReadDataEx": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": true,
		"seqNo": 1,
		"NG_param": "none",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileByBackupIdCP, param: {
		"Connect": {"return": true},
		"ReadDataEx": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": false,
		"seqNo": 0,
		"NG_param": "none",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileByBackupIdCP, param: {
		"Connect": {"return": true},
		"ReadDataEx": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": true,
		"seqNo": 0,
		"NG_param": "file",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileByBackupIdCP, param: {
		"Connect": {"return": true},
		"ReadDataEx": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": true,
		"seqNo": 0,
		"NG_param": "addr",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileByBackupIdCP, param: {
		"Connect": {"return": true},
		"ReadDataEx": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": true,
		"seqNo": 0,
		"NG_param": "size",
		"ret": false
	}},
	
	// MemDumpSaveToFileByBackupIdForSusLog
	{func: test_MemDumpSaveToFileByBackupIdForSusLog, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"ReadDataEX": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": true,
		"seqNo": 3,
		"NG_param": "none",
		"ret": true
	}},
	{func: test_MemDumpSaveToFileByBackupIdForSusLog, param: {
		"Connect": {"return": false},
		"ReadData": {"return": true},
		"ReadDataEX": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": true,
		"seqNo": 1,
		"NG_param": "none",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileByBackupIdForSusLog, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"ReadDataEX": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": false,
		"seqNo": 0,
		"NG_param": "none",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileByBackupIdForSusLog, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"ReadDataEX": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": true,
		"seqNo": 0,
		"NG_param": "file",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileByBackupIdForSusLog, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"ReadDataEX": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": true,
		"seqNo": 0,
		"NG_param": "addr",
		"ret": false
	}},
	{func: test_MemDumpSaveToFileByBackupIdForSusLog, param: {
		"Connect": {"return": true},
		"ReadData": {"return": true},
		"ReadDataEX": {"return": true},
		"SavetoFile": {"return": true},
		"readBk_ret": true,
		"seqNo": 0,
		"NG_param": "size",
		"ret": false
	}},
);

//=================================================================================
// onLoad handler
//=================================================================================
window.addEventListener("load", function() {
	test_main({
		test_name: "MemoryDump test",
		test_list: test_list
	});
});
