
var CMD_ISSUE_RD_BKUP = { blk: 0x0603, cd: 0x0001 };
var CMD_ISSUE_RD_BKUP_CP = { blk: 0x0603, cd: 0x0040 };
var CMD_ISSUE_WR_BKUP = { blk: 0x0603, cd: 0x0002 };
var CMD_ISSUE_WR_BKUP_CP = { blk: 0x0603, cd: 0x0041 };
var CMD_ISSUE_SAVE_BKUP = { blk: 0x0603, cd: 0x0003 };
var CMD_ISSUE_WR_BKUP_OFFSET = { blk: 0x0603, cd: 0x0030 };
var CMD_ISSUE_WR_BKUP_OFFSET_CP = { blk: 0x0603, cd: 0x0042 };

//=================================================================================
// Normal OK pattern for ReadBackupDataX
//=================================================================================
function test_ReadBackupDataX_normal_OK(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var resSize = param.resSize;
	var seqNo = 0;
	var DATA_SIZE = 4;
	var DATA_NUM = 8;

	AdjustCtrl.Connect = function(dev) {
		this.ResSize = resSize;
		seqNo++;
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		if (blk != CMD_ISSUE_RD_BKUP.blk
			|| code != CMD_ISSUE_RD_BKUP.cd
			|| AdjustCmd.DataSize != DATA_SIZE
		) {
			printBody("CmdIssue parameter error\n");
			ngFlag = true;
		}
		seqNo++;

		return true;
	}

	AdjustCtrl.SetParam8 = function(offset, data) {
		ngFlag = true;
		printBody("SetParam8 calling\n");
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		ngFlag = true;
		printBody("SetParam16 calling\n");
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		switch(offset) {
		case 0:
			if( data != bkId ) {
				printBody("SetParam32 backup id error\n");
				ngFlag = true;
			}
			seqNo++;
			break;
		default:
			ngFlag = true;
			break;
		}
		return true;
	}
	
	AdjustCtrl.GetResponse8 = function(idx) {
		if( resSize == 8 ) {
			if( idx >= resSize ) {
				ngFlag = true;
				printBody("GetResponse8 read over-run\n");
			}
			seqNo++;
			return idx;
		}
		else {
			ngFlag = true;
			printBody("GetResponse8 calling\n");
		}
	}
	AdjustCtrl.GetResponse16 = function(idx) {
		if( resSize == 16 ) {
			if( idx >= resSize ) {
				ngFlag = true;
				printBody("GetResponse16 read over-run\n");
			}
			seqNo++;
			return idx;
		}
		else {
			ngFlag = true;
			printBody("GetResponse16 calling\n");
		}
	}
	AdjustCtrl.GetResponse32 = function(idx) {
		if( resSize == 32 ) {
			if( idx >= resSize ) {
				ngFlag = true;
				printBody("GetResponse32 read over-run\n");
			}
			seqNo++;
			return idx;
		}
		else {
			ngFlag = true;
			printBody("GetResponse32 calling\n");
		}
	}
	
	var rcvData = new Array();
	var ret = false;
	switch(resSize) {
	case 8:
		ret = ReadBackupData8(bkId, rcvData);
		break;
	case 16:
		ret = ReadBackupData16(bkId, rcvData);
		break;
	case 32:
		ret = ReadBackupData32(bkId, rcvData);
		break;
	default:
		break;
	}

	// Check the data
	for( var i = 0; i < DATA_NUM; i++ ) {
		if( rcvData[i] != i ) {
			printBody("Wrong response data: " + rcvData[i] + "\n");
			ngFlag = true;
			break;
		}
	}

	// Sequence check
	if( seqNo != 3 + DATA_NUM ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret && ngFlag == false;
}

//=================================================================================
// Connect NG pattern for ReadBackupDataX
//=================================================================================
function test_ReadBackupDataX_connect_NG(param)
{
	var bkId = 0x12345678;
	var seqNo = 0;
	var ngFlag = false;
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		return false;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return true;
	}
	AdjustCtrl.GetResponse16 = function(idx) {
		seqNo++;
		return true;
	}
	AdjustCtrl.GetResponse32 = function(idx) {
		seqNo++;
		return true;
	}

	var rcvData = new Array();
	var ret = false;
	switch(param.resSize) {
	case 8:
		ret = ReadBackupData8(bkId, rcvData);
		break;
	case 16:
		ret = ReadBackupData16(bkId, rcvData);
		break;
	case 32:
		ret = ReadBackupData32(bkId, rcvData);
		break;
	default:
		break;
	}

	// Sequence check
	if( seqNo != 1 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// CmdIssue NG pattern for ReadBackupDataX
//=================================================================================
function test_ReadBackupDataX_CmdIssue_NG(param)
{
	var bkId = 0x12345678;
	var seqNo = 0;
	var ngFlag = false;
	var DATA_SIZE = 4;
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		seqNo++;
		if (blk != CMD_ISSUE_RD_BKUP.blk
			|| code != CMD_ISSUE_RD_BKUP.cd
			|| AdjustCmd.DataSize != DATA_SIZE
		) {
			printBody("CmdIssue parameter error\n");
			ngFlag = true;
		}
		return false;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return true;
	}
	AdjustCtrl.GetResponse16 = function(idx) {
		seqNo++;
		return true;
	}
	AdjustCtrl.GetResponse32 = function(idx) {
		seqNo++;
		return true;
	}

	var rcvData = new Array();
	var ret = false;
	switch(param.resSize) {
	case 8:
		ret = ReadBackupData8(bkId, rcvData);
		break;
	case 16:
		ret = ReadBackupData16(bkId, rcvData);
		break;
	case 32:
		ret = ReadBackupData32(bkId, rcvData);
		break;
	default:
		break;
	}

	// Sequence check
	if( seqNo != 3 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// Normal OK pattern for ReadBackupDataCPX
//=================================================================================
function test_ReadBackupDataCPX_normal_OK(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var resSize = param.resSize;
	var seqNo = 0;
	var DATA_SIZE = 8;
	var DATA_NUM = 8;

	AdjustCtrl.Connect = function(dev) {
		this.ResSize = resSize;
		seqNo++;
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		if (blk != CMD_ISSUE_RD_BKUP_CP.blk
			|| code != CMD_ISSUE_RD_BKUP_CP.cd
			|| AdjustCmd.DataSize != DATA_SIZE
		) {
			printBody("CmdIssue parameter error\n");
			ngFlag = true;
		}
		seqNo++;

		return true;
	}

	AdjustCtrl.SetParam8 = function(offset, data) {
		ngFlag = true;
		printBody("SetParam8 calling\n");
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		ngFlag = true;
		printBody("SetParam16 calling\n");
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		switch(offset) {
		case 0:
			if( data != bkId ) {
				printBody("SetParam32 backup id error\n");
				ngFlag = true;
			}
			seqNo++;
			break;
		case 1:
			if( data != 0x01 ) {
				printBody("SetParam32 backup type error\n");
				ngFlag = true;
			}
			seqNo++;
			break;
		default:
			printBody("SetParam32 over-run error\n");
			ngFlag = true;
			break;
		}
		return true;
	}
	
	AdjustCtrl.GetResponse8 = function(idx) {
		if( resSize == 8 ) {
			if( idx >= resSize ) {
				ngFlag = true;
				printBody("GetResponse8 read over-run\n");
			}
			seqNo++;
			return idx;
		}
		else {
			ngFlag = true;
			printBody("GetResponse8 calling\n");
		}
	}
	AdjustCtrl.GetResponse16 = function(idx) {
		if( resSize == 16 ) {
			if( idx >= resSize ) {
				ngFlag = true;
				printBody("GetResponse16 read over-run\n");
			}
			seqNo++;
			return idx;
		}
		else {
			ngFlag = true;
			printBody("GetResponse16 calling\n");
		}
	}
	AdjustCtrl.GetResponse32 = function(idx) {
		if( resSize == 32 ) {
			if( idx >= resSize ) {
				ngFlag = true;
				printBody("GetResponse32 read over-run\n");
			}
			seqNo++;
			return idx;
		}
		else {
			ngFlag = true;
			printBody("GetResponse32 calling\n");
		}
	}
	
	var rcvData = new Array();
	var ret = false;
	switch(resSize) {
	case 8:
		ret = ReadBackupDataCP8(bkId, rcvData);
		break;
	case 16:
		ret = ReadBackupDataCP16(bkId, rcvData);
		break;
	case 32:
		ret = ReadBackupDataCP32(bkId, rcvData);
		break;
	default:
		break;
	}

	// Check the data
	for( var i = 0; i < DATA_NUM; i++ ) {
		if( rcvData[i] != i ) {
			printBody("Wrong response data: " + rcvData[i] + "\n");
			ngFlag = true;
			break;
		}
	}

	// Sequence check
	if( seqNo != 4 + DATA_NUM ) {
		printBody("Sequence number error:\n");
		ngFlag = true;
	}

	return ret && ngFlag == false;
}

//=================================================================================
// Connect NG pattern for ReadBackupDataCPX
//=================================================================================
function test_ReadBackupDataCPX_connect_NG(param)
{
	var bkId = 0x12345678;
	var seqNo = 0;
	var ngFlag = false;
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		return false;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return true;
	}
	AdjustCtrl.GetResponse16 = function(idx) {
		seqNo++;
		return true;
	}
	AdjustCtrl.GetResponse32 = function(idx) {
		seqNo++;
		return true;
	}

	var rcvData = new Array();
	var ret = false;
	switch(param.resSize) {
	case 8:
		ret = ReadBackupDataCP8(bkId, rcvData);
		break;
	case 16:
		ret = ReadBackupDataCP16(bkId, rcvData);
		break;
	case 32:
		ret = ReadBackupDataCP32(bkId, rcvData);
		break;
	default:
		break;
	}

	// Sequence check
	if( seqNo != 1 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// CmdIssue NG pattern for ReadBackupDataCPX
//=================================================================================
function test_ReadBackupDataCPX_CmdIssue_NG(param)
{
	var bkId = 0x12345678;
	var seqNo = 0;
	var ngFlag = false;
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		seqNo++;
		return false;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		ngFlag = true;
		printBody("SetParam8 calling\n");
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		seqNo++;
		ngFlag = true;
		printBody("SetParam16 calling\n");
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		ngFlag = true;
		printBody("GetResponse8 calling\n");
		return true;
	}
	AdjustCtrl.GetResponse16 = function(idx) {
		seqNo++;
		ngFlag = true;
		printBody("GetResponse16 calling\n");
		return true;
	}
	AdjustCtrl.GetResponse32 = function(idx) {
		seqNo++;
		ngFlag = true;
		printBody("GetResponse32 calling\n");
		return true;
	}

	var rcvData = new Array();
	var ret = false;
	switch(param.resSize) {
	case 8:
		ret = ReadBackupDataCP8(bkId, rcvData);
		break;
	case 16:
		ret = ReadBackupDataCP16(bkId, rcvData);
		break;
	case 32:
		ret = ReadBackupDataCP32(bkId, rcvData);
		break;
	default:
		break;
	}

	// Sequence check
	if( seqNo != 4 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// Normal OK pattern for WriteBackupDataX
//=================================================================================
function test_WriteBackupDataX_normal_OK(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var sndSize = param.sndSize;
	var seqNo = 0;
	var SET_PARAM_OFFSET = 4;

	var sndData = new Array();
	for( var i = 0; i < sndSize; i++ ) {
		sndData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		if (blk != CMD_ISSUE_WR_BKUP.blk
			|| code != CMD_ISSUE_WR_BKUP.cd
			|| AdjustCmd.DataSize != (SET_PARAM_OFFSET + sndSize)
		) {
			printBody("CmdIssue parameter error\n");
			ngFlag = true;
		}
		seqNo++;

		return true;
	}

	function __SetParamX (offset, data, sndUnit) {
		switch(offset) {
		case 0:
			if( data != bkId ) {
				printBody("SetParam" + sndUnit + " backup id error\n");
				ngFlag = true;
			}
			seqNo++;
			break;
		default:
			if( sndUnit != sndSize ) {
				ngFlag = true;
				printBody("SetParam" + sndUnit + " calling\n");
			}
			else {
				var _offset = offset - SET_PARAM_OFFSET/(sndUnit/8);
				if( _offset >= sndSize ) {
					printBody("SetParam" + sndUnit + " over-run error\n");
					ngFlag = true;
				}
				else if( _offset != data ) {
					printBody("SetParam" + sndUnit + "(" + offset + ") wrong data: " + data + "\n");
					ngFlag = true;
				}
				seqNo++;
			}
			break;
		}
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		__SetParamX(offset, data, 8);
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		__SetParamX(offset, data, 16);
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		__SetParamX(offset, data, 32);
		return true;
	}
	
	AdjustCtrl.GetResponse8 = function(idx) {
		ngFlag = true;
		printBody("GetResponse8 calling\n");
	}
	AdjustCtrl.GetResponse16 = function(idx) {
		ngFlag = true;
		printBody("GetResponse16 calling\n");
	}
	AdjustCtrl.GetResponse32 = function(idx) {
		ngFlag = true;
		printBody("GetResponse32 calling\n");
	}
	
	var ret = false;
	switch(param.sndSize) {
	case 8:
		ret = WriteBackupData8(bkId, sndData);
		break;
	case 16:
		ret = WriteBackupData16(bkId, sndData);
		break;
	case 32:
		ret = WriteBackupData32(bkId, sndData);
		break;
	default:
		break;
	}

	// Sequence check
	if( seqNo != 3 + sndSize ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret && ngFlag == false;
}

//=================================================================================
// Connect NG pattern for WriteBackupDataX
//=================================================================================
function test_WriteBackupDataX_connect_NG(param)
{
	var bkId = 0x12345678;
	var seqNo = 0;
	var ngFlag = false;
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		return false;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		ngFlag = true;
		printBody("Calling GetResponse8\n");
		return true;
	}
	AdjustCtrl.GetResponse16 = function(idx) {
		seqNo++;
		ngFlag = true;
		printBody("Calling GetResponse16\n");
		return true;
	}
	AdjustCtrl.GetResponse32 = function(idx) {
		seqNo++;
		ngFlag = true;
		printBody("Calling GetResponse32\n");
		return true;
	}

	var rcvData = new Array();
	var ret = false;
	switch(param.sndSize) {
	case 8:
		ret = WriteBackupData8(bkId, rcvData);
		break;
	case 16:
		ret = WriteBackupData16(bkId, rcvData);
		break;
	case 32:
		ret = WriteBackupData32(bkId, rcvData);
		break;
	default:
		break;
	}

	// Sequence check
	if( seqNo != 1 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// Connect NG pattern for WriteBackupDataX
//=================================================================================
function test_WriteBackupDataX_CmdIssue_NG(param)
{
	var bkId = 0x12345678;
	var sndSize = param.sndSize;
	var seqNo = 0;
	var ngFlag = false;

	var sndData = new Array();
	for( var i = 0; i < sndSize; i++ ) {
		sndData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		seqNo++;
		return false;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		if( sndSize == 8 ) {
			seqNo++;
		}
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		if( sndSize == 16 ) {
			seqNo++;
		}
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		switch(offset) {
		case 0:
			seqNo++;
			break;
		default:
			if( sndSize == 32 ) {
				seqNo++;
			}
			break;
		}
		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		ngFlag = true;
		printBody("Calling GetResponse8\n");
		return true;
	}
	AdjustCtrl.GetResponse16 = function(idx) {
		seqNo++;
		ngFlag = true;
		printBody("Calling GetResponse16\n");
		return true;
	}
	AdjustCtrl.GetResponse32 = function(idx) {
		seqNo++;
		ngFlag = true;
		printBody("Calling GetResponse32\n");
		return true;
	}
	
	var ret = false;
	switch(sndSize) {
	case 8:
		ret = WriteBackupData8(bkId, sndData);
		break;
	case 16:
		ret = WriteBackupData16(bkId, sndData);
		break;
	case 32:
		ret = WriteBackupData32(bkId, sndData);
		break;
	default:
		break;
	}

	// Sequence check
	if( seqNo != 3 + sndSize ) {
		printBody("Sequence number error:" + seqNo + "\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// Normal OK pattern for WriteBackupDataCPX
//=================================================================================
function test_WriteBackupDataCPX_normal_OK(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var sndSize = param.sndSize;
	var seqNo = 0;
	var SET_PARAM_OFFSET = 8;

	var sndData = new Array();
	for( var i = 0; i < sndSize; i++ ) {
		sndData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		if (blk != CMD_ISSUE_WR_BKUP_CP.blk
			|| code != CMD_ISSUE_WR_BKUP_CP.cd
			|| AdjustCmd.DataSize != (SET_PARAM_OFFSET + sndSize)
		) {
			printBody("CmdIssue parameter error\n");
			ngFlag = true;
		}
		seqNo++;

		return true;
	}

	function __SetParamX (offset, data, sndUnit) {
		switch(offset) {
		case 0:
			if( data != bkId ) {
				printBody("SetParam" + sndUnit + " backup id error\n");
				ngFlag = true;
			}
			seqNo++;
			break;
		case 1:
			if( data != 0x01 ) {
				printBody("SetParam" + sndUnit + " backup type error\n");
				ngFlag = true;
			}
			seqNo++;
			break;
		default:
			if( sndUnit != sndSize ) {
				ngFlag = true;
				printBody("SetParam" + sndUnit + " calling\n");
			}
			else {
				var _offset = offset - SET_PARAM_OFFSET/(sndUnit/8);
				if( _offset >= sndSize ) {
					printBody("SetParam" + sndUnit + " over-run error\n");
					ngFlag = true;
				}
				else if( _offset != data ) {
					printBody("SetParam" + sndUnit + "(" + offset + ") wrong data: " + data + "\n");
					ngFlag = true;
				}
				seqNo++;
			}
			break;
		}
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		__SetParamX(offset, data, 8);
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		__SetParamX(offset, data, 16);
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		__SetParamX(offset, data, 32);
		return true;
	}
	
	AdjustCtrl.GetResponse8 = function(idx) {
		ngFlag = true;
		seqNo++;
		printBody("Calling GetResponse8\n");
	}
	AdjustCtrl.GetResponse16 = function(idx) {
		ngFlag = true;
		seqNo++;
		printBody("Calling GetResponse16\n");
	}
	AdjustCtrl.GetResponse32 = function(idx) {
		ngFlag = true;
		seqNo++;
		printBody("Calling GetResponse32\n");
	}
	
	var ret = false;
	switch(param.sndSize) {
	case 8:
		ret = WriteBackupDataCP8(bkId, sndData);
		break;
	case 16:
		ret = WriteBackupDataCP16(bkId, sndData);
		break;
	case 32:
		ret = WriteBackupDataCP32(bkId, sndData);
		break;
	default:
		break;
	}

	// Sequence check
	if( seqNo != 4 + sndSize ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret && ngFlag == false;
}

//=================================================================================
// Connect NG pattern for WriteBackupDataCPX
//=================================================================================
function test_WriteBackupDataCPX_connect_NG(param)
{
	var bkId = 0x12345678;
	var seqNo = 0;
	var ngFlag = false;
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		return false;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		ngFlag = true;
		printBody("Calling GetResponse8\n");
		return true;
	}
	AdjustCtrl.GetResponse16 = function(idx) {
		seqNo++;
		ngFlag = true;
		printBody("Calling GetResponse16\n");
		return true;
	}
	AdjustCtrl.GetResponse32 = function(idx) {
		seqNo++;
		ngFlag = true;
		printBody("Calling GetResponse32\n");
		return true;
	}

	var rcvData = new Array();
	var ret = false;
	switch(param.sndSize) {
	case 8:
		ret = WriteBackupDataCP8(bkId, rcvData);
		break;
	case 16:
		ret = WriteBackupDataCP16(bkId, rcvData);
		break;
	case 32:
		ret = WriteBackupDataCP32(bkId, rcvData);
		break;
	default:
		break;
	}

	// Sequence check
	if( seqNo != 1 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// Connect NG pattern for WriteBackupDataCPX
//=================================================================================
function test_WriteBackupDataCPX_CmdIssue_NG(param)
{
	var bkId = 0x12345678;
	var sndSize = param.sndSize;
	var seqNo = 0;
	var ngFlag = false;

	var sndData = new Array();
	for( var i = 0; i < sndSize; i++ ) {
		sndData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		seqNo++;
		return false;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		if( sndSize == 8 ) {
			seqNo++;
		}
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		if( sndSize == 16 ) {
			seqNo++;
		}
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		switch(offset) {
		case 0:
		case 1:
			seqNo++;
			break;
		default:
			if( sndSize == 32 ) {
				seqNo++;
			}
			break;
		}
		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		ngFlag = true;
		seqNo++;
		printBody("Calling GetResponse8\n");
		return true;
	}
	AdjustCtrl.GetResponse16 = function(idx) {
		ngFlag = true;
		seqNo++;
		printBody("Calling GetResponse16\n");
		return true;
	}
	AdjustCtrl.GetResponse32 = function(idx) {
		ngFlag = true;
		seqNo++;
		printBody("Calling GetResponse32\n");
		return true;
	}
	
	var ret = false;
	switch(sndSize) {
	case 8:
		ret = WriteBackupDataCP8(bkId, sndData);
		break;
	case 16:
		ret = WriteBackupDataCP16(bkId, sndData);
		break;
	case 32:
		ret = WriteBackupDataCP32(bkId, sndData);
		break;
	default:
		break;
	}

	// Sequence check
	if( seqNo != 4 + sndSize ) {
		printBody("Sequence number error:" + seqNo + "\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// Normal OK pattern for SaveBackupData
//=================================================================================
function test_SaveBackupData_normal_OK(param)
{
	var ngFlag = false;
	var seqNo = 0;

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam8 = function(offset, data)
	{
		seqNo++;
		ngFlag = true;
		printBody("Calling SetParam8\n");
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data)
	{
		switch(offset)
		{
		case 0:
			if( data != 0x0000 ) {
				ngFlag = true;
				printBody("SetParam16 data error\n");
			}
			seqNo++;
			break;
		default:
			ngFlag = true;
			printBody("SetParam16 over-run error\n");
			break;
		}
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data)
	{
		seqNo++;
		ngFlag = true;
		printBody("Calling SetParam32\n");
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		if (blk != CMD_ISSUE_SAVE_BKUP.blk
			|| code != CMD_ISSUE_SAVE_BKUP.cd
			|| AdjustCmd.DataSize != 2
		) {
			printBody("CmdIssue parameter error\n");
			ngFlag = true;
		}
		seqNo++;

		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		ngFlag = true;
		seqNo++;
		printBody("Calling GetResponse8\n");
		return true;
	}
	AdjustCtrl.GetResponse16 = function(idx) {
		ngFlag = true;
		seqNo++;
		printBody("Calling GetResponse16\n");
		return true;
	}
	AdjustCtrl.GetResponse32 = function(idx) {
		ngFlag = true;
		seqNo++;
		printBody("Calling GetResponse32\n");
		return true;
	}

	var ret = SaveBackupData();

	// Sequence check
	if( seqNo != 3 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == true && ngFlag == false;
}

//=================================================================================
// Connect NG pattern for SaveBackupData
//=================================================================================
function test_SaveBackupData_connect_NG(param)
{
	var seqNo = 0;
	var ngFlag = false;
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		return false;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		ngFlag = true;
		seqNo++;
		printBody("Calling SetParam8\n");
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		ngFlag = true;
		seqNo++;
		printBody("Calling SetParam32\n");
		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		ngFlag = true;
		seqNo++;
		printBody("Calling GetResponse8\n");
		return true;
	}
	AdjustCtrl.GetResponse16 = function(idx) {
		ngFlag = true;
		seqNo++;
		printBody("Calling GetResponse16\n");
		return true;
	}
	AdjustCtrl.GetResponse32 = function(idx) {
		ngFlag = true;
		seqNo++;
		printBody("Calling GetResponse32\n");
		return true;
	}

	var ret = SaveBackupData();

	// Sequence check
	if( seqNo != 1 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// Connect NG pattern for SaveBackupData
//=================================================================================
function test_SaveBackupData_CmdIssue_NG(param)
{
	var seqNo = 0;
	var ngFlag = false;
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		seqNo++;
		return false;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		ngFlag = true;
		seqNo++;
		printBody("Calling SetParam8\n");
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		switch(offset) {
		case 0:
			seqNo++;
			break;
		default:
			ngFlag = true;
			break;
		}
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		ngFlag = true;
		seqNo++;
		printBody("Calling SetParam32\n");
		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		ngFlag = true;
		seqNo++;
		printBody("Calling GetResponse8\n");
		return true;
	}
	AdjustCtrl.GetResponse16 = function(idx) {
		ngFlag = true;
		seqNo++;
		printBody("Calling GetResponse16\n");
		return true;
	}
	AdjustCtrl.GetResponse32 = function(idx) {
		ngFlag = true;
		seqNo++;
		printBody("Calling GetResponse32\n");
		return true;
	}

	var ret = SaveBackupData();

	// Sequence check
	if( seqNo != 3 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// Normal OK pattern for UpdateBackupData8
//=================================================================================
function test_UpdateBackupData8_normal_OK(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;
	var SET_PARAM_OFFSET = 4;
	var REPLACE_OFFSET = 4;
	var REPLACE_DATA = 0xFF;

	var resData = new Array();
	for( var i = 0; i < 8; i++ ) {
		resData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;

		if( connectNo == 1 ) {
			this.ResSize = resData.length;
		}
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		switch(cmdIssueNo)
		{
		case 1:
			if (blk != CMD_ISSUE_RD_BKUP.blk
				|| code != CMD_ISSUE_RD_BKUP.cd
				|| AdjustCmd.DataSize != 4
			) {
				printBody("Read CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		case 2:
			if (blk != CMD_ISSUE_WR_BKUP.blk
				|| code != CMD_ISSUE_WR_BKUP.cd
				|| AdjustCmd.DataSize != (SET_PARAM_OFFSET + resData.length)
			) {
				printBody("CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		case 3:
			if (blk != CMD_ISSUE_SAVE_BKUP.blk
				|| code != CMD_ISSUE_SAVE_BKUP.cd
				|| AdjustCmd.DataSize != 2
			) {
				printBody("Save CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		default:
			break;
		}

		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return resData[idx];
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		if( connectNo == 2 )
		{
			if( offset > SET_PARAM_OFFSET ) {
				if( (offset - SET_PARAM_OFFSET) == REPLACE_OFFSET ) {
					if( data != REPLACE_DATA ) {
						ngFlag = true;
						printBody("Replace data error\n");
					}
				}
				else {
					if( resData[offset - SET_PARAM_OFFSET] != data ) {
						ngFlag = true;
						printBody("Write data error\n");
					}
				}
			}
		}
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupData8(bkId, 0xFF, 4);

	// Connect No check
	if( connectNo != 3 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 3 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo < 6 + 2 + resData.length*2 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == true && ngFlag == false;
}

//=================================================================================
// ReadBackupData8 NG pattern for UpdateBackupData8
//=================================================================================
function test_UpdateBackupData8_ReadBackupData8_NG(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;

	var resData = new Array();
	for( var i = 0; i < 8; i++ ) {
		resData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;

		this.ResSize = resData.length;
		return false;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;

		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return resData[idx];
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupData8(bkId, 0xFF, 4);

	// Connect No check
	if( connectNo != 1 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 0 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo != 1 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// WriteBackupData8 NG pattern for UpdateBackupData8
//=================================================================================
function test_UpdateBackupData8_WriteBackupData8_NG(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;

	var resData = new Array();
	for( var i = 0; i < 8; i++ ) {
		resData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;

		if( connectNo == 1 ) {
			this.ResSize = resData.length;
		}
		else if( connectNo == 2 ) {
			return false;
		}
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		switch(cmdIssueNo)
		{
		case 1:
			if (blk != CMD_ISSUE_RD_BKUP.blk
				|| code != CMD_ISSUE_RD_BKUP.cd
				|| AdjustCmd.DataSize != 4
			) {
				printBody("Read CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		default:
			break;
		}

		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return resData[idx];
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupData8(bkId, 0xFF, 4);

	// Connect No check
	if( connectNo != 2 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 1 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo < 3 + 1 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// SaveBackupData NG pattern for UpdateBackupData8
//=================================================================================
function test_UpdateBackupData8_SaveBackupData_NG(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;
	var SET_PARAM_OFFSET = 4;
	var REPLACE_OFFSET = 4;
	var REPLACE_DATA = 0xFF;

	var resData = new Array();
	for( var i = 0; i < 8; i++ ) {
		resData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;

		if( connectNo == 1 ) {
			this.ResSize = resData.length;
		}
		else if( connectNo == 3 ) {
			return false;
		}
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		switch(cmdIssueNo)
		{
		case 1:
			if (blk != CMD_ISSUE_RD_BKUP.blk
				|| code != CMD_ISSUE_RD_BKUP.cd
				|| AdjustCmd.DataSize != 4
			) {
				printBody("Read CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		case 2:
			if (blk != CMD_ISSUE_WR_BKUP.blk
				|| code != CMD_ISSUE_WR_BKUP.cd
				|| AdjustCmd.DataSize != (SET_PARAM_OFFSET + resData.length)
			) {
				printBody("CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		default:
			break;
		}

		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return resData[idx];
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		if( connectNo == 2 )
		{
			if( offset > SET_PARAM_OFFSET ) {
				if( (offset - SET_PARAM_OFFSET) == REPLACE_OFFSET ) {
					if( data != REPLACE_DATA ) {
						ngFlag = true;
						printBody("Replace data error\n");
					}
				}
				else {
					if( resData[offset - SET_PARAM_OFFSET] != data ) {
						ngFlag = true;
						printBody("Write data error\n");
					}
				}
			}
		}
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupData8(bkId, 0xFF, 4);

	// Connect No check
	if( connectNo != 3 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 2 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo < 5 + 2 + resData.length*2 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// Normal OK pattern for UpdateBackupData8CP
//=================================================================================
function test_UpdateBackupData8CP_normal_OK(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;
	var SET_PARAM_OFFSET = 8;
	var REPLACE_OFFSET = 4;
	var REPLACE_DATA = 0xFF;

	var resData = new Array();
	for( var i = 0; i < 8; i++ ) {
		resData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;

		if( connectNo == 1 ) {
			this.ResSize = resData.length;
		}
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		switch(cmdIssueNo)
		{
		case 1:
			if (blk != CMD_ISSUE_RD_BKUP_CP.blk
				|| code != CMD_ISSUE_RD_BKUP_CP.cd
				|| AdjustCmd.DataSize != SET_PARAM_OFFSET
			) {
				printBody("Read CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		case 2:
			if (blk != CMD_ISSUE_WR_BKUP_CP.blk
				|| code != CMD_ISSUE_WR_BKUP_CP.cd
				|| AdjustCmd.DataSize != (SET_PARAM_OFFSET + resData.length)
			) {
				printBody("CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		case 3:
			if (blk != CMD_ISSUE_SAVE_BKUP.blk
				|| code != CMD_ISSUE_SAVE_BKUP.cd
				|| AdjustCmd.DataSize != 2
			) {
				printBody("Save CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		default:
			break;
		}

		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return resData[idx];
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		if( connectNo == 2 )
		{
			if( offset > SET_PARAM_OFFSET ) {
				if( (offset - SET_PARAM_OFFSET) == REPLACE_OFFSET ) {
					if( data != REPLACE_DATA ) {
						ngFlag = true;
						printBody("Replace data error\n");
					}
				}
				else {
					if( resData[offset - SET_PARAM_OFFSET] != data ) {
						ngFlag = true;
						printBody("Write data error\n");
					}
				}
			}
		}
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupData8CP(bkId, 0xFF, 4);

	// Connect No check
	if( connectNo != 3 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 3 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo < 6 + 4 + resData.length*2 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == true && ngFlag == false;
}

//=================================================================================
// ReadBackupDataCP8 NG pattern for UpdateBackupData8CP
//=================================================================================
function test_UpdateBackupData8CP_ReadBackupDataCP8_NG(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;

	var resData = new Array();
	for( var i = 0; i < 8; i++ ) {
		resData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;

		if( connectNo == 1 ) {
			this.ResSize = resData.length;
			return false;
		}
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return resData[idx];
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupData8CP(bkId, 0xFF, 4);

	// Connect No check
	if( connectNo != 1 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 0 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo != 1 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// WriteBackupDataCP8 NG pattern for UpdateBackupData8CP
//=================================================================================
function test_UpdateBackupData8CP_WriteBackupDataCP8_NG(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;
	var SET_PARAM_OFFSET = 8;
	var REPLACE_OFFSET = 4;
	var REPLACE_DATA = 0xFF;

	var resData = new Array();
	for( var i = 0; i < 8; i++ ) {
		resData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;

		if( connectNo == 1 ) {
			this.ResSize = resData.length;
		}
		else if( connectNo == 2 ) {
			return false;
		}
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		switch(cmdIssueNo)
		{
		case 1:
			if (blk != CMD_ISSUE_RD_BKUP_CP.blk
				|| code != CMD_ISSUE_RD_BKUP_CP.cd
				|| AdjustCmd.DataSize != SET_PARAM_OFFSET
			) {
				printBody("Read CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		default:
			break;
		}

		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return resData[idx];
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupData8CP(bkId, 0xFF, 4);

	// Connect No check
	if( connectNo != 2 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 1 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo < 3 + 2 + resData.length ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// SaveBackupData NG pattern for UpdateBackupData8CP
//=================================================================================
function test_UpdateBackupData8CP_SaveBackupData_NG(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;
	var SET_PARAM_OFFSET = 8;
	var REPLACE_OFFSET = 4;
	var REPLACE_DATA = 0xFF;

	var resData = new Array();
	for( var i = 0; i < 8; i++ ) {
		resData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;

		if( connectNo == 1 ) {
			this.ResSize = resData.length;
		}
		else if( connectNo == 3 ) {
			return false;
		}
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		switch(cmdIssueNo)
		{
		case 1:
			if (blk != CMD_ISSUE_RD_BKUP_CP.blk
				|| code != CMD_ISSUE_RD_BKUP_CP.cd
				|| AdjustCmd.DataSize != SET_PARAM_OFFSET
			) {
				printBody("Read CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		case 2:
			if (blk != CMD_ISSUE_WR_BKUP_CP.blk
				|| code != CMD_ISSUE_WR_BKUP_CP.cd
				|| AdjustCmd.DataSize != (SET_PARAM_OFFSET + resData.length)
			) {
				printBody("CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		default:
			break;
		}

		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return resData[idx];
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		if( connectNo == 2 )
		{
			if( offset > SET_PARAM_OFFSET ) {
				if( (offset - SET_PARAM_OFFSET) == REPLACE_OFFSET ) {
					if( data != REPLACE_DATA ) {
						ngFlag = true;
						printBody("Replace data error\n");
					}
				}
				else {
					if( resData[offset - SET_PARAM_OFFSET] != data ) {
						ngFlag = true;
						printBody("Write data error\n");
					}
				}
			}
		}
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupData8CP(bkId, 0xFF, 4);

	// Connect No check
	if( connectNo != 3 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 2 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo < 5 + 4 + resData.length*2 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// Normal OK pattern for UpdateBackupData8_noalert
//=================================================================================
function test_UpdateBackupData8_noalert_normal_OK(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;
	var SET_PARAM_OFFSET = 4;
	var REPLACE_OFFSET = 4;
	var REPLACE_DATA = 0xFF;

	var resData = new Array();
	for( var i = 0; i < 8; i++ ) {
		resData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;

		if( connectNo == 1 ) {
			this.ResSize = resData.length;
		}
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		switch(cmdIssueNo)
		{
		case 1:
			if (blk != CMD_ISSUE_RD_BKUP.blk
				|| code != CMD_ISSUE_RD_BKUP.cd
				|| AdjustCmd.DataSize != 4
			) {
				printBody("Read CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		case 2:
			if (blk != CMD_ISSUE_WR_BKUP.blk
				|| code != CMD_ISSUE_WR_BKUP.cd
				|| AdjustCmd.DataSize != (SET_PARAM_OFFSET + resData.length)
			) {
				printBody("CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		case 3:
			if (blk != CMD_ISSUE_SAVE_BKUP.blk
				|| code != CMD_ISSUE_SAVE_BKUP.cd
				|| AdjustCmd.DataSize != 2
			) {
				printBody("Save CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		default:
			break;
		}

		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return resData[idx];
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		if( connectNo == 2 )
		{
			if( offset > SET_PARAM_OFFSET ) {
				if( (offset - SET_PARAM_OFFSET) == REPLACE_OFFSET ) {
					if( data != REPLACE_DATA ) {
						ngFlag = true;
						printBody("Replace data error\n");
					}
				}
				else {
					if( resData[offset - SET_PARAM_OFFSET] != data ) {
						ngFlag = true;
						printBody("Write data error\n");
					}
				}
			}
		}
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupData8_noalert(bkId, 0xFF, 4);

	// Connect No check
	if( connectNo != 3 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 3 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo < 6 + 2 + resData.length*2 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == true && ngFlag == false;
}

//=================================================================================
// Connect NG pattern for UpdateBackupData8_noalert
//=================================================================================
function test_UpdateBackupData8_noalert_Connect_NG(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;

	var resData = new Array();
	for( var i = 0; i < 8; i++ ) {
		resData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;

		this.ResSize = resData.length;
		return false;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;

		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return resData[idx];
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupData8_noalert(bkId, 0xFF, 4);

	// Connect No check
	if( connectNo != 1 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 0 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo != 1 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// CmdIssue NG pattern for UpdateBackupData8_noalert
//=================================================================================
function test_UpdateBackupData8_noalert_CmdIssue_NG(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;

	var resData = new Array();
	for( var i = 0; i < 8; i++ ) {
		resData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;

		this.ResSize = resData.length;
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;

		return false;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return resData[idx];
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupData8_noalert(bkId, 0xFF, 4);
	Disconnect();

	// Connect No check
	if( connectNo != 1 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 1 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo != 3 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// WriteBackupData8 NG pattern for UpdateBackupData8_noalert
//=================================================================================
function test_UpdateBackupData8_noalert_WriteBackupData8_NG(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;

	var resData = new Array();
	for( var i = 0; i < 8; i++ ) {
		resData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;

		if( connectNo == 1 ) {
			this.ResSize = resData.length;
		}
		else if( connectNo == 2 ) {
			return false;
		}
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		switch(cmdIssueNo)
		{
		case 1:
			if (blk != CMD_ISSUE_RD_BKUP.blk
				|| code != CMD_ISSUE_RD_BKUP.cd
				|| AdjustCmd.DataSize != 4
			) {
				printBody("Read CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		default:
			break;
		}

		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return resData[idx];
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupData8_noalert(bkId, 0xFF, 4);

	// Connect No check
	if( connectNo != 2 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 1 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo < 3 + 1 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// SaveBackupData NG pattern for UpdateBackupData8_noalert
//=================================================================================
function test_UpdateBackupData8_noalert_SaveBackupData_NG(param)
{
	var bkId = 0x12345678;
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;
	var SET_PARAM_OFFSET = 4;
	var REPLACE_OFFSET = 4;
	var REPLACE_DATA = 0xFF;

	var resData = new Array();
	for( var i = 0; i < 8; i++ ) {
		resData[i] = i;
	}

	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;

		if( connectNo == 1 ) {
			this.ResSize = resData.length;
		}
		else if( connectNo == 3 ) {
			return false;
		}
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		switch(cmdIssueNo)
		{
		case 1:
			if (blk != CMD_ISSUE_RD_BKUP.blk
				|| code != CMD_ISSUE_RD_BKUP.cd
				|| AdjustCmd.DataSize != 4
			) {
				printBody("Read CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		case 2:
			if (blk != CMD_ISSUE_WR_BKUP.blk
				|| code != CMD_ISSUE_WR_BKUP.cd
				|| AdjustCmd.DataSize != (SET_PARAM_OFFSET + resData.length)
			) {
				printBody("CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		default:
			break;
		}

		return true;
	}
	AdjustCtrl.GetResponse8 = function(idx) {
		seqNo++;
		return resData[idx];
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		if( connectNo == 2 )
		{
			if( offset > SET_PARAM_OFFSET ) {
				if( (offset - SET_PARAM_OFFSET) == REPLACE_OFFSET ) {
					if( data != REPLACE_DATA ) {
						ngFlag = true;
						printBody("Replace data error\n");
					}
				}
				else {
					if( resData[offset - SET_PARAM_OFFSET] != data ) {
						ngFlag = true;
						printBody("Write data error\n");
					}
				}
			}
		}
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupData8_noalert(bkId, 0xFF, 4);

	// Connect No check
	if( connectNo != 3 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 2 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo < 5 + 2 + resData.length*2 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// Normal OK pattern for UpdateBackupDataOffset
//=================================================================================
function test_UpdateBackupDataOffset_normal_OK(param)
{
	var bkId = 0x12345678;
	var WRITE_OFFSET = 4;
	var WRITE_SIZE = 8;
	
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;
	var OFFSET_WRITE_SET_PARAM_OFFSET = 16;
	var SAVE_SET_PARAM_OFFSET = 2;

	var wrtData = new Array();
	for( var i = 0; i < WRITE_SIZE; i++ ) {
		wrtData[i] = i;
	}
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		switch(cmdIssueNo)
		{
		case 1:
			if (blk != CMD_ISSUE_WR_BKUP_OFFSET.blk
				|| code != CMD_ISSUE_WR_BKUP_OFFSET.cd
				|| AdjustCmd.DataSize != OFFSET_WRITE_SET_PARAM_OFFSET + wrtData.length
			) {
				printBody("Offsest Write CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		case 2:
			if (blk != CMD_ISSUE_SAVE_BKUP.blk
				|| code != CMD_ISSUE_SAVE_BKUP.cd
				|| AdjustCmd.DataSize != SAVE_SET_PARAM_OFFSET
			) {
				printBody("Save CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		default:
			break;
		}
		return true;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		var _offset = offset - OFFSET_WRITE_SET_PARAM_OFFSET;
		if( data != wrtData[_offset] ) {
			ngFlag = true;
			printBody("Offset Write set data error\n");
		}
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		if( connectNo == 1 )
		{
			switch(offset) {
			case 0:
				if( data != 0x00000001 ) {
					ngFlag = true;
					printBody("Offset Write parameter error\n");
				}
				break;
			case 1:
				if( data != bkId ) {
					ngFlag = true;
					printBody("Offset Write backup ID error\n");
				}
				break;
			case 2:
				if( data != WRITE_OFFSET ) {
					ngFlag = true;
					printBody("Offset Write offset error\n");
				}
				break;
			case 3:
				if( data != WRITE_SIZE ) {
					ngFlag = true;
					printBody("Offset Write size error\n");
				}
				break;
			default:
				break;
			}
		}
		return true;
	}

	var ret = UpdateBackupDataOffset(bkId, WRITE_OFFSET, WRITE_SIZE, wrtData);
	
	// Connect No check
	if( connectNo != 2 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 2 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo < 4 + 5 + wrtData.length ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == true && ngFlag == false;
}

//=================================================================================
// Connect NG pattern for UpdateBackupDataOffset
//=================================================================================
function test_UpdateBackupDataOffset_Connect_NG(param)
{
	var bkId = 0x12345678;
	var WRITE_OFFSET = 4;
	var WRITE_SIZE = 8;
	
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;

	var wrtData = new Array();
	for( var i = 0; i < WRITE_SIZE; i++ ) {
		wrtData[i] = i;
	}
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;
		return false;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		return true;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupDataOffset(bkId, WRITE_OFFSET, WRITE_SIZE, wrtData);
	
	// Connect No check
	if( connectNo != 1 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 0 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo != 1 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// CmdIssue NG pattern for UpdateBackupDataOffset
//=================================================================================
function test_UpdateBackupDataOffset_CmdIssue_NG(param)
{
	var bkId = 0x12345678;
	var WRITE_OFFSET = 4;
	var WRITE_SIZE = 8;
	
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;

	var wrtData = new Array();
	for( var i = 0; i < WRITE_SIZE; i++ ) {
		wrtData[i] = i;
	}
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		seqNo++;
		cmdIssueNo++;
		return false;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupDataOffset(bkId, WRITE_OFFSET, WRITE_SIZE, wrtData);
	
	// Connect No check
	if( connectNo != 1 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 1 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo < 2 + 4 + wrtData.length ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// SaveBackupData NG pattern for UpdateBackupDataOffset
//=================================================================================
function test_UpdateBackupDataOffset_SaveBackupData_NG(param)
{
	var bkId = 0x12345678;
	var WRITE_OFFSET = 4;
	var WRITE_SIZE = 8;
	
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;
	var OFFSET_WRITE_SET_PARAM_OFFSET = 16;

	var wrtData = new Array();
	for( var i = 0; i < WRITE_SIZE; i++ ) {
		wrtData[i] = i;
	}
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;
		if( connectNo == 2 ) {
			return false;
		}
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		switch(cmdIssueNo)
		{
		case 1:
			if (blk != CMD_ISSUE_WR_BKUP_OFFSET.blk
				|| code != CMD_ISSUE_WR_BKUP_OFFSET.cd
				|| AdjustCmd.DataSize != OFFSET_WRITE_SET_PARAM_OFFSET + wrtData.length
			) {
				printBody("Offsest Write CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		default:
			break;
		}
		return true;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		var _offset = offset - OFFSET_WRITE_SET_PARAM_OFFSET;
		if( data != wrtData[_offset] ) {
			ngFlag = true;
			printBody("Offset Write set data error\n");
		}
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		if( connectNo == 1 )
		{
			switch(offset) {
			case 0:
				if( data != 0x00000001 ) {
					ngFlag = true;
					printBody("Offset Write parameter error\n");
				}
				break;
			case 1:
				if( data != bkId ) {
					ngFlag = true;
					printBody("Offset Write backup ID error\n");
				}
				break;
			case 2:
				if( data != WRITE_OFFSET ) {
					ngFlag = true;
					printBody("Offset Write offset error\n");
				}
				break;
			case 3:
				if( data != WRITE_SIZE ) {
					ngFlag = true;
					printBody("Offset Write size error\n");
				}
				break;
			default:
				break;
			}
		}
		return true;
	}

	var ret = UpdateBackupDataOffset(bkId, WRITE_OFFSET, WRITE_SIZE, wrtData);
	
	// Connect No check
	if( connectNo != 2 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 1 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo < 3 + 4 + wrtData.length ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// Normal OK pattern for UpdateBackupDataOffsetCP
//=================================================================================
function test_UpdateBackupDataOffsetCP_normal_OK(param)
{
	var bkId = 0x12345678;
	var WRITE_OFFSET = 4;
	var WRITE_SIZE = 8;
	
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;
	var OFFSET_WRITE_SET_PARAM_OFFSET = 20;
	var SAVE_SET_PARAM_OFFSET = 2;

	var wrtData = new Array();
	for( var i = 0; i < WRITE_SIZE; i++ ) {
		wrtData[i] = i;
	}
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		switch(cmdIssueNo)
		{
		case 1:
			if (blk != CMD_ISSUE_WR_BKUP_OFFSET_CP.blk
				|| code != CMD_ISSUE_WR_BKUP_OFFSET_CP.cd
				|| AdjustCmd.DataSize != OFFSET_WRITE_SET_PARAM_OFFSET + wrtData.length
			) {
				printBody("Offsest Write CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		case 2:
			if (blk != CMD_ISSUE_SAVE_BKUP.blk
				|| code != CMD_ISSUE_SAVE_BKUP.cd
				|| AdjustCmd.DataSize != SAVE_SET_PARAM_OFFSET
			) {
				printBody("Save CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		default:
			break;
		}
		return true;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		var _offset = offset - OFFSET_WRITE_SET_PARAM_OFFSET;
		if( data != wrtData[_offset] ) {
			ngFlag = true;
			printBody("Offset Write set data error\n");
		}
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		if( connectNo == 1 )
		{
			switch(offset) {
			case 0:
				if( data != 0x00000001 ) {
					ngFlag = true;
					printBody("Offset Write parameter error\n");
				}
				break;
			case 1:
				if( data != bkId ) {
					ngFlag = true;
					printBody("Offset Write backup ID error\n");
				}
				break;
			case 2:
				if( data != WRITE_OFFSET ) {
					ngFlag = true;
					printBody("Offset Write offset error\n");
				}
				break;
			case 3:
				if( data != WRITE_SIZE ) {
					ngFlag = true;
					printBody("Offset Write size error\n");
				}
				break;
			case 4:
				if( data != 0x00000001 ) {
					ngFlag = true;
					printBody("Offset Write backup type error\n");
				}
				break;
			default:
				break;
			}
		}
		return true;
	}

	var ret = UpdateBackupDataOffsetCP(bkId, WRITE_OFFSET, WRITE_SIZE, wrtData);
	
	// Connect No check
	if( connectNo != 2 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 2 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo < 4 + 6 + wrtData.length ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == true && ngFlag == false;
}

//=================================================================================
// Connect NG pattern for UpdateBackupDataOffsetCP
//=================================================================================
function test_UpdateBackupDataOffsetCP_Connect_NG(param)
{
	var bkId = 0x12345678;
	var WRITE_OFFSET = 4;
	var WRITE_SIZE = 8;
	
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;

	var wrtData = new Array();
	for( var i = 0; i < WRITE_SIZE; i++ ) {
		wrtData[i] = i;
	}
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;
		return false;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		return true;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupDataOffsetCP(bkId, WRITE_OFFSET, WRITE_SIZE, wrtData);
	
	// Connect No check
	if( connectNo != 1 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 0 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo != 1 ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// CmdIssue NG pattern for UpdateBackupDataOffsetCP
//=================================================================================
function test_UpdateBackupDataOffsetCP_CmdIssue_NG(param)
{
	var bkId = 0x12345678;
	var WRITE_OFFSET = 4;
	var WRITE_SIZE = 8;
	
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;

	var wrtData = new Array();
	for( var i = 0; i < WRITE_SIZE; i++ ) {
		wrtData[i] = i;
	}
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code) {
		seqNo++;
		cmdIssueNo++;
		return false;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		return true;
	}

	var ret = UpdateBackupDataOffsetCP(bkId, WRITE_OFFSET, WRITE_SIZE, wrtData);
	
	// Connect No check
	if( connectNo != 1 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 1 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo < 2 + 5 + wrtData.length ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

//=================================================================================
// SaveBackupData NG pattern for UpdateBackupDataOffsetCP
//=================================================================================
function test_UpdateBackupDataOffsetCP_SaveBackupData_NG(param)
{
	var bkId = 0x12345678;
	var WRITE_OFFSET = 4;
	var WRITE_SIZE = 8;
	
	var ngFlag = false;
	var seqNo = 0;
	var connectNo = 0;
	var cmdIssueNo = 0;
	var OFFSET_WRITE_SET_PARAM_OFFSET = 20;

	var wrtData = new Array();
	for( var i = 0; i < WRITE_SIZE; i++ ) {
		wrtData[i] = i;
	}
	
	AdjustCtrl.Connect = function(dev) {
		seqNo++;
		connectNo++;
		if( connectNo == 2 ) {
			return false;
		}
		return true;
	}
	AdjustCtrl.CmdIssue = function(blk, code)
	{
		seqNo++;
		cmdIssueNo++;
		switch(cmdIssueNo)
		{
		case 1:
			if (blk != CMD_ISSUE_WR_BKUP_OFFSET_CP.blk
				|| code != CMD_ISSUE_WR_BKUP_OFFSET_CP.cd
				|| AdjustCmd.DataSize != OFFSET_WRITE_SET_PARAM_OFFSET + wrtData.length
			) {
				printBody("Offsest Write CmdIssue parameter error\n");
				ngFlag = true;
			}
			break;
		default:
			break;
		}
		return true;
	}
	AdjustCtrl.SetParam8 = function(offset, data) {
		seqNo++;
		var _offset = offset - OFFSET_WRITE_SET_PARAM_OFFSET;
		if( data != wrtData[_offset] ) {
			ngFlag = true;
			printBody("Offset Write set data error\n");
		}
		return true;
	}
	AdjustCtrl.SetParam16 = function(offset, data) {
		seqNo++;
		return true;
	}
	AdjustCtrl.SetParam32 = function(offset, data) {
		seqNo++;
		if( connectNo == 1 )
		{
			switch(offset) {
			case 0:
				if( data != 0x00000001 ) {
					ngFlag = true;
					printBody("Offset Write parameter error\n");
				}
				break;
			case 1:
				if( data != bkId ) {
					ngFlag = true;
					printBody("Offset Write backup ID error\n");
				}
				break;
			case 2:
				if( data != WRITE_OFFSET ) {
					ngFlag = true;
					printBody("Offset Write offset error\n");
				}
				break;
			case 3:
				if( data != WRITE_SIZE ) {
					ngFlag = true;
					printBody("Offset Write size error\n");
				}
				break;
			default:
				break;
			}
		}
		return true;
	}

	var ret = UpdateBackupDataOffsetCP(bkId, WRITE_OFFSET, WRITE_SIZE, wrtData);
	
	// Connect No check
	if( connectNo != 2 ) {
		printBody("Connect number error\n");
		ngFlag = true;
	}

	// CmdIssue No check
	if( cmdIssueNo != 1 ) {
		printBody("CmdIssue number error\n");
		ngFlag = true;
	}

	// Sequence check
	if( seqNo < 3 + 5 + wrtData.length ) {
		printBody("Sequence number error\n");
		ngFlag = true;
	}

	return ret == false && ngFlag == false;
}

var test_list = new Array(
	// ReadBackupDataX
	{func: test_ReadBackupDataX_normal_OK,   param: {resSize: 8}},
	{func: test_ReadBackupDataX_normal_OK,   param: {resSize: 16}},
	{func: test_ReadBackupDataX_normal_OK,   param: {resSize: 32}},
	{func: test_ReadBackupDataX_connect_NG,  param: {resSize: 8}},
	{func: test_ReadBackupDataX_connect_NG,  param: {resSize: 16}},
	{func: test_ReadBackupDataX_connect_NG,  param: {resSize: 32}},
	{func: test_ReadBackupDataX_CmdIssue_NG, param: {resSize: 8}},
	{func: test_ReadBackupDataX_CmdIssue_NG, param: {resSize: 16}},
	{func: test_ReadBackupDataX_CmdIssue_NG, param: {resSize: 32}},

	// ReadBackupDataCPX
	{func: test_ReadBackupDataCPX_normal_OK,   param: {resSize: 8}},
	{func: test_ReadBackupDataCPX_normal_OK,   param: {resSize: 16}},
	{func: test_ReadBackupDataCPX_normal_OK,   param: {resSize: 32}},
	{func: test_ReadBackupDataCPX_connect_NG,  param: {resSize: 8}},
	{func: test_ReadBackupDataCPX_connect_NG,  param: {resSize: 16}},
	{func: test_ReadBackupDataCPX_connect_NG,  param: {resSize: 32}},
	{func: test_ReadBackupDataCPX_CmdIssue_NG, param: {resSize: 8}},
	{func: test_ReadBackupDataCPX_CmdIssue_NG, param: {resSize: 16}},
	{func: test_ReadBackupDataCPX_CmdIssue_NG, param: {resSize: 32}},

	// WriteBackupDataX
	{func: test_WriteBackupDataX_normal_OK,   param: {sndSize: 8}},
	{func: test_WriteBackupDataX_normal_OK,   param: {sndSize: 16}},
	{func: test_WriteBackupDataX_normal_OK,   param: {sndSize: 32}},
	{func: test_WriteBackupDataX_connect_NG,  param: {sndSize: 8}},
	{func: test_WriteBackupDataX_connect_NG,  param: {sndSize: 16}},
	{func: test_WriteBackupDataX_connect_NG,  param: {sndSize: 32}},
	{func: test_WriteBackupDataX_CmdIssue_NG, param: {sndSize: 8}},
	{func: test_WriteBackupDataX_CmdIssue_NG, param: {sndSize: 16}},
	{func: test_WriteBackupDataX_CmdIssue_NG, param: {sndSize: 32}},

	// WriteBackupDataCPX
	{func: test_WriteBackupDataCPX_normal_OK,   param: {sndSize: 8}},
	{func: test_WriteBackupDataCPX_normal_OK,   param: {sndSize: 16}},
	{func: test_WriteBackupDataCPX_normal_OK,   param: {sndSize: 32}},
	{func: test_WriteBackupDataCPX_connect_NG,  param: {sndSize: 8}},
	{func: test_WriteBackupDataCPX_connect_NG,  param: {sndSize: 16}},
	{func: test_WriteBackupDataCPX_connect_NG,  param: {sndSize: 32}},
	{func: test_WriteBackupDataCPX_CmdIssue_NG, param: {sndSize: 8}},
	{func: test_WriteBackupDataCPX_CmdIssue_NG, param: {sndSize: 16}},
	{func: test_WriteBackupDataCPX_CmdIssue_NG, param: {sndSize: 32}},

	// SaveBackupData
	{func: test_SaveBackupData_normal_OK,   param: null},
	{func: test_SaveBackupData_connect_NG,  param: null},
	{func: test_SaveBackupData_CmdIssue_NG, param: null},

	// UpdateBackupData8
	{func: test_UpdateBackupData8_normal_OK,           param: null},
	{func: test_UpdateBackupData8_ReadBackupData8_NG,  param: null},
	{func: test_UpdateBackupData8_WriteBackupData8_NG, param: null},
	{func: test_UpdateBackupData8_SaveBackupData_NG,   param: null},

	// UpdateBackupData8CP
	{func: test_UpdateBackupData8CP_normal_OK,             param: null},
	{func: test_UpdateBackupData8CP_ReadBackupDataCP8_NG,  param: null},
	{func: test_UpdateBackupData8CP_WriteBackupDataCP8_NG, param: null},
	{func: test_UpdateBackupData8CP_SaveBackupData_NG,     param: null},

	// UpdateBackupData8_noalert
	{func: test_UpdateBackupData8_noalert_normal_OK,           param: null},
	{func: test_UpdateBackupData8_noalert_Connect_NG,          param: null},
	{func: test_UpdateBackupData8_noalert_CmdIssue_NG,         param: null},
	{func: test_UpdateBackupData8_noalert_WriteBackupData8_NG, param: null},
	{func: test_UpdateBackupData8_noalert_SaveBackupData_NG,   param: null},

	// UpdateBackupDataOffset
	{func: test_UpdateBackupDataOffset_normal_OK,         param: null},
	{func: test_UpdateBackupDataOffset_Connect_NG,        param: null},
	{func: test_UpdateBackupDataOffset_CmdIssue_NG,       param: null},
	{func: test_UpdateBackupDataOffset_SaveBackupData_NG, param: null},

	// UpdateBackupDataOffsetCP
	{func: test_UpdateBackupDataOffsetCP_normal_OK,         param: null},
	{func: test_UpdateBackupDataOffsetCP_Connect_NG,        param: null},
	{func: test_UpdateBackupDataOffsetCP_CmdIssue_NG,       param: null},
	{func: test_UpdateBackupDataOffsetCP_SaveBackupData_NG, param: null},
);

//=================================================================================
// onLoad handler
//=================================================================================
window.addEventListener("load", function() {
	test_main({
		test_name: "Backup test",
		test_list: test_list
	});
});
