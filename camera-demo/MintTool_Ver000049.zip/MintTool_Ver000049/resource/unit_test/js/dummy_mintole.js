
var mintole = null;


/*================================================================================
 * Console Manager Class
================================================================================*/
var ConsoleManager = function() {
	this.LEVEL = {
		"OFF":0,
		"CRITICAL":1,
		"ALERT":2,
		"ERROR":3,
		"WARNING":4,
		"INFO":5,
		"DEBUG":6,
	};
	this.level = 0;
}
ConsoleManager.prototype.SETTING_CONSOLE_KEY_NAME = "console";
ConsoleManager.prototype.CONSOLE_ELEMENT_ID = "console";

/*--------------------------------------------------------------------------------
 * Get console level
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.getLevel = function()
{
	return this.level;
}

/*--------------------------------------------------------------------------------
 * Set console level
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.setLevel = function(level)
{
	this.level = level;
}

/*--------------------------------------------------------------------------------
 * Save console level
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.saveLevel = function()
{
}

/*--------------------------------------------------------------------------------
 * Open console
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.open = function()
{
}

/*--------------------------------------------------------------------------------
 * Close console
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.close = function()
{
}

/*--------------------------------------------------------------------------------
 * Get date text
--------------------------------------------------------------------------------*/
function zerofillBefore(num, dig) {
	if( !num && num != 0 ) { return "0"; }
	if( !dig ) { return "0"; }

	return (("0" * dig) + String(num)).slice(-dig);
}
ConsoleManager.prototype.getDateText = function(date)
{
	return String(date.getFullYear()).slice(-2) + "/"
				+ zerofillBefore(date.getMonth() + 1, 2) + "/"
				+ zerofillBefore(date.getDate(), 2) + "-"
				+ zerofillBefore(date.getHours(), 2) + ":"
				+ zerofillBefore(date.getMinutes(), 2) + ":"
				+ zerofillBefore(date.getSeconds(), 2) + "'"
				+ ( "000" + date.getMilliseconds() ).slice(-3);
}

/*--------------------------------------------------------------------------------
 * Write text
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.write = function(text)
{
	document.querySelector("body").innerHTML += "<div class=\"console_out\">[" + this.getDateText(new Date()) + "] " + text + "</div>";
}

/*--------------------------------------------------------------------------------
 * Write debug text
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.debug = function(text)
{
	this.write("<span class=\"debug\">[debug] " + text + "</span>");
}

/*--------------------------------------------------------------------------------
 * Write info text
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.info = function(text)
{
	this.write("<span class=\"info\">[info] " + text + "</span>");
}

/*--------------------------------------------------------------------------------
 * Write warning text
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.warning = function(text)
{
	this.write("<span class=\"warning\">[warning] " + text + "</span>");
}

/*--------------------------------------------------------------------------------
 * Write error text
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.error = function(text)
{
	this.write("<span class=\"error\">[error] " + text + "</span>");
}

/*--------------------------------------------------------------------------------
 * Write alert text
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.alert = function(text, popup)
{
	this.write("<span class=\"alert\">[alert] " + text + "</span>");
}

/*--------------------------------------------------------------------------------
 * Write critical text
--------------------------------------------------------------------------------*/
ConsoleManager.prototype.critical = function(text)
{
	this.write("<span class=\"critical\">[critical] " + text + "</span>");
}
