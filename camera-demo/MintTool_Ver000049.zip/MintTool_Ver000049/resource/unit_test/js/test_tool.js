
var bodyElm = null;
var mintole = null;

window.addEventListener("load", function() {
	bodyElm = document.querySelector("body");
	mintole = new ConsoleManager();
});

function printBody(str)
{
	bodyElm.innerHTML += str.replace(/\n/g, "<br>");
}

