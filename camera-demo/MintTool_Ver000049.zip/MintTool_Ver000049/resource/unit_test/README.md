# 単体テスト
## テストの実行方法
以下のページを実行する。以上。  

* [Backup read/write](./test_Backup.html)
* [Memory Dump](./test_MemoryDump.html)


## 単体テスト用のファイル
* `js/dummy_mintole.js` ：Mint Toolのコンソール機能（mintole）をテスト用に吐き出すスタブ
* `js/test_tool.js` ：テスト用のツール
* `js/dummy_connect.js` ：ExComInfのスタブ
* `js/test_main.js` ：テストの叩き口＆まとめ

## テストの作り
window の `load` イベントで `test_main` をコールする

`test_main` のフォーマット
```js
test_main({
	test_name: "TEST NAME",
	test_list: TEST_LIST
});
```

* `TEST NAME` ：テスト名（表示用）
* `TEST_LIST` ：テストのリスト（配列）  
	**【テストリストのフォーマット】**
	* `func` ：テストを実行する関数（フォーマット `function func(param)`）
	* `param` ：上記関数に投げる引数（型は何でもOK。関数での使いざま次第）

### スタブたち
ExComInfのスタブを用意してあります。これをオーバーライドする形でテストを作成しています。  
