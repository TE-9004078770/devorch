
var CMD_ISSUE_RD_BKUP = { blk: 0x0603, cd: 0x0001 };
var CMD_ISSUE_RD_BKUP_CP = { blk: 0x0603, cd: 0x0040 };
var CMD_ISSUE_WR_BKUP = { blk: 0x0603, cd: 0x0002 };
var CMD_ISSUE_WR_BKUP_CP = { blk: 0x0603, cd: 0x0041 };
var CMD_ISSUE_SAVE_BKUP = { blk: 0x0603, cd: 0x0003 };
var CMD_ISSUE_WR_BKUP_OFFSET = { blk: 0x0603, cd: 0x0030 };
var CMD_ISSUE_WR_BKUP_OFFSET_CP = { blk: 0x0603, cd: 0x0042 };

/*****************************************************************************
 * バックアップデータを読み込む
 * @param: バックアップID
 * @param: データ受け取り配列
 * @param: 読み出し単位 [byte]
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function __ReadBackupData(backupId, dataList, readingUnitByte)
{
	var ret = true;

	if( !Connect() ) {
		return false;
	}

	try {
		// BackUp read
		AdjustCmd.DataSize = 4;
		AdjustCmd.SetParam32(0, backupId);

		if( !AdjustCmd.CmdIssue(CMD_ISSUE_RD_BKUP.blk, CMD_ISSUE_RD_BKUP.cd) ) {
			mintole.error("__ReadBackupData: Read Backup FAIL");
			throw "error";
		}

		var readNum = AdjustCmd.ResSize / readingUnitByte;
		var GET_RESPONSE_FUNC_LIST = new Array(
			null,
			function(i) {return AdjustCmd.GetResponse8(i)},
			function(i) {return AdjustCmd.GetResponse16(i)},
			null,
			function(i) {return AdjustCmd.GetResponse32(i)}
		);
		if( GET_RESPONSE_FUNC_LIST[readingUnitByte] ) {
			for( var i = 0; i < readNum; i++ ) {
				dataList.push(GET_RESPONSE_FUNC_LIST[readingUnitByte](i));
			}
		}
	}
	catch(e) {
		ret = false;
	}

	Disconnect();
	return ret;
}

/*****************************************************************************
 * バックアップデータを 1 / 2 / 4 byteずつ読み込む
 * @param: バックアップID
 * @param: データ受け取り配列
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function ReadBackupData8(backupId, dataList) {
	return __ReadBackupData(backupId, dataList, 1);
}
function ReadBackupData16(backupId, dataList) {
	return __ReadBackupData(backupId, dataList, 2);
}
function ReadBackupData32(backupId, dataList) {
	return __ReadBackupData(backupId, dataList, 4);
}

/*****************************************************************************
 * バックアップデータを読み込む（CP向け）
 * @param: バックアップID
 * @param: データ受け取り配列
 * @param: 読み出し単位 [byte]
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function __ReadBackupDataCP(backupId, dataList, readingUnitByte)
{
	var ret = true;

	if( !Connect() ) {
		return false;
	}

	// BackUp read
	try {
		AdjustCmd.DataSize = 8;
		AdjustCmd.SetParam32(0, backupId);
		AdjustCmd.SetParam32(1, 0x01);

		if (! AdjustCmd.CmdIssue(CMD_ISSUE_RD_BKUP_CP.blk, CMD_ISSUE_RD_BKUP_CP.cd)) {
			mintole.error("__ReadBackupDataCP: Read Backup on CP FAIL");
			throw "error";
		}

		var readNum = AdjustCmd.ResSize / readingUnitByte;
		var GET_RESPONSE_FUNC_LIST = new Array(
			null,
			function(i) {return AdjustCmd.GetResponse8(i)},
			function(i) {return AdjustCmd.GetResponse16(i)},
			null,
			function(i) {return AdjustCmd.GetResponse32(i)}
		);
		if( GET_RESPONSE_FUNC_LIST[readingUnitByte] ) {
			for( var i = 0; i < readNum; i++ ) {
				dataList.push(GET_RESPONSE_FUNC_LIST[readingUnitByte](i));
			}
		}
	}
	catch(e) {
		ret = false;
	}

	Disconnect();
	return ret;
}

/*****************************************************************************
 * バックアップデータを 1 / 2 / 4 byteずつ読み込む（CP向け）
 * @param: バックアップID
 * @param: データ受け取り配列
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function ReadBackupDataCP8(backupId, dataList) {
	return __ReadBackupDataCP(backupId, dataList, 1);
}
function ReadBackupDataCP16(backupId, dataList) {
	return __ReadBackupDataCP(backupId, dataList, 2);
}
function ReadBackupDataCP32(backupId, dataList) {
	return __ReadBackupDataCP(backupId, dataList, 4);
}

/*****************************************************************************
 * バックアップデータを書き込む
 * @param: バックアップID
 * @param: 送るデータ配列
 * @param: 書き込み単位 [byte]
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function __WriteBackupData(backupId, dataList, writingUnitByte)
{
	var ret = true;
	var HEAD_OFFSET = 4;

	if( !Connect() ) {
		return false;
	}

	var data_len = dataList.length;

	// Write bakcup
	try {
		AdjustCmd.DataSize = HEAD_OFFSET + data_len;
		AdjustCmd.SetParam32(0, backupId);

		var GET_SET_FUNC_LIST = new Array(
			null,
			function(i, d) {return AdjustCmd.SetParam8(i, d)},
			function(i, d) {return AdjustCmd.SetParam16(i, d)},
			null,
			function(i, d) {return AdjustCmd.SetParam32(i, d)}
		);
		if( GET_SET_FUNC_LIST[writingUnitByte] ) {
			for( var i = 0; i < data_len; i++ ) {
				GET_SET_FUNC_LIST[writingUnitByte](HEAD_OFFSET/writingUnitByte + i, dataList[i]);
			}
		}

		if( !AdjustCmd.CmdIssue(CMD_ISSUE_WR_BKUP.blk, CMD_ISSUE_WR_BKUP.cd) ) {
			mintole.error("Write Backup FAIL !");
			throw "error";
		}
	}
	catch(e) {
		ret = false;
	}

	Disconnect();
	return ret;
}

/*****************************************************************************
 * バックアップデータを 1 / 2 / 4 byteずつ書き込む
 * @param: バックアップID
 * @param: 送るデータ配列
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function WriteBackupData8(backupId, dataList) {
	return __WriteBackupData(backupId, dataList, 1);
}
function WriteBackupData16(backupId, dataList) {
	return __WriteBackupData(backupId, dataList, 2);
}
function WriteBackupData32(backupId, dataList) {
	return __WriteBackupData(backupId, dataList, 4);
}

/*****************************************************************************
 * バックアップデータを書き込む（CP向け）
 * @param: バックアップID
 * @param: 送るデータ配列
 * @param: 書き込み単位 [byte]
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function __WriteBackupDataCP(backupId, dataList, writingUnitByte)
{
	var ret = true;
	var HEAD_OFFSET = 8;

	if( !Connect() ) {
		return false;
	}

	var data_len = dataList.length;

	// Write bakcup
	try {
		AdjustCmd.DataSize = HEAD_OFFSET + data_len;
		AdjustCmd.SetParam32(0, backupId);
		AdjustCmd.SetParam32(1, 0x01);

		var GET_SET_FUNC_LIST = new Array(
			null,
			function(i, d) {return AdjustCmd.SetParam8(i, d)},
			function(i, d) {return AdjustCmd.SetParam16(i, d)},
			null,
			function(i, d) {return AdjustCmd.SetParam32(i, d)}
		);
		if( GET_SET_FUNC_LIST[writingUnitByte] ) {
			for( var i = 0; i < data_len; i++ ) {
				GET_SET_FUNC_LIST[writingUnitByte](HEAD_OFFSET/writingUnitByte + i, dataList[i]);
			}
		}

		if( !AdjustCmd.CmdIssue(CMD_ISSUE_WR_BKUP_CP.blk, CMD_ISSUE_WR_BKUP_CP.cd) ) {
			mintole.error("Write Backup FAIL");
			throw "error";
		}
	}
	catch(e) {
		ret = false;
	}

	Disconnect();
	return ret;
}

/*****************************************************************************
 * バックアップデータを 1 / 2 / 4 byteずつ書き込む（CP向け）
 * @param: バックアップID
 * @param: 送るデータ配列
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function WriteBackupDataCP8(backupId, dataList) {
	return __WriteBackupDataCP(backupId, dataList, 1);
}
function WriteBackupDataCP16(backupId, dataList) {
	return __WriteBackupDataCP(backupId, dataList, 2);
}
function WriteBackupDataCP32(backupId, dataList) {
	return __WriteBackupDataCP(backupId, dataList, 4);
}

/*****************************************************************************
 * バックアップデータ保存
 * @param: void
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function SaveBackupData()
{
	var ret = true;

	if( !Connect() ) {
		return false;
	}

	// Save backup
	AdjustCmd.DataSize = 2;
	AdjustCmd.SetParam16(0, 0x0000);

	if( !AdjustCmd.CmdIssue(CMD_ISSUE_SAVE_BKUP.blk, CMD_ISSUE_SAVE_BKUP.cd) ) {
		mintole.error("SaveBackupData: Save Backup FAIL");
		ret = false;
	}

	Disconnect();
	return ret;
}

/*****************************************************************************
 * バックアップデータ更新
 * @param: バックアップID
 * @param: データ
 * @param: オフセット
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function UpdateBackupData8(backupId, data, offset)
{
	var ret = true;
	var backupData = new Array(0);

	try {
		// Read backup
		if( !ReadBackupData8(backupId, backupData) ) {
			throw "error";
		}

		// Overwrite
		backupData[offset] = data;

		// Write bakcup
		if( !WriteBackupData8(backupId, backupData) ) {
			throw "error";
		}

		// Save backup
		if( !SaveBackupData() ) {
			throw "error";
		}
	}
	catch(e) {
		ret = false;
	}

	delete backupData;
	return ret;
}

/*****************************************************************************
 * バックアップデータ更新（CP向け）
 * @param: バックアップID
 * @param: データ
 * @param: オフセット
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function UpdateBackupData8CP(backupId, data, offset)
{
	var ret = true;
	var backupData = new Array(0);

	try {
		// Read backup
		if( !ReadBackupDataCP8(backupId, backupData) ) {
			throw "error";
		}

		// Overwrite
		backupData[offset] = data;

		// Write bakcup
		if( !WriteBackupDataCP8(backupId, backupData) ) {
			throw "error";
		}

		// Save backup
		if( !SaveBackupData() ) {
			throw "error";
		}
	}
	catch(e) {
		ret = false;
	}

	delete backupData;
	return ret;
}

/*****************************************************************************
 * バックアップデータ更新（エラーでもアラート出さない版）
 * エラーでも処理を続ける特殊用途用
 * ★エラーでもDisconnect()処理呼んでいないので必ず呼び元側でDisconnect処理して下さい。
 * @param: バックアップID
 * @param: データ
 * @param: オフセット
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function UpdateBackupData8_noalert(backupId, data, offset)
{
	var ret = true;

	if( !Connect() ) {
		return false;
	}

	var backupData = new Array(0);

	try {
		// BackUp read
		AdjustCmd.DataSize = 4 ;
		AdjustCmd.SetParam32(0, backupId);

		if( !AdjustCmd.CmdIssue(CMD_ISSUE_RD_BKUP.blk, CMD_ISSUE_RD_BKUP.cd) ) {
			// Backupが存在しない場合でもalert画面を表示しない Disconnect()もしない
			throw "error";
		}

		var resSize = AdjustCmd.ResSize;

		for (var cnt = 0; cnt < resSize; cnt++) {
			backupData.push(AdjustCmd.GetResponse8(cnt));
		}
		
		Disconnect();

		backupData[offset] = data;

		// Write bakcup
		if( !WriteBackupData8(backupId, backupData) ) {
			throw "error";
		}

		// Save backup
		if( !SaveBackupData() ) {
			throw "error";
		}
	}
	catch(e) {
		ret = false;
	}

	delete backupData;
	return ret;
}

/*****************************************************************************
 * 指定したbackupIdにオフセット指定でアクセスし更新する
 * @param: バックアップID
 * @param: オフセット
 * @param: 書き込むデータサイズ
 * @param: データ
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function UpdateBackupDataOffset(backupId, offset, size, data)
{
	var ret = true;

	if( !Connect() ) {
		return false;
	}

	try {
		// BackUp Write
		AdjustCmd.DataSize = 16 + size;
		AdjustCmd.SetParam32(0, 0x00000001);	// WRITE
		AdjustCmd.SetParam32(1, backupId);		// BackupID
		AdjustCmd.SetParam32(2, offset);		// Offset
		AdjustCmd.SetParam32(3, size);			// size

		for( var i = 0; i < size; i++ ) {
			AdjustCmd.SetParam8(i + 16, data[i]);
		}

		if( !AdjustCmd.CmdIssue(CMD_ISSUE_WR_BKUP_OFFSET.blk, CMD_ISSUE_WR_BKUP_OFFSET.cd) ) {
			mintole.error("UpdateBackupDataOffset: Write Backup FAIL");
			Disconnect();
			throw "error";
		}
		Disconnect();

		// Save backup
		if( !SaveBackupData() ) {
			throw "error";
		}
	}
	catch(e) {
		ret = false;
	}

	return ret;
}

/*****************************************************************************
 * 指定したbackupIdにオフセット指定でアクセスし更新する（CP向け）
 * @param: バックアップID
 * @param: オフセット
 * @param: 書き込むデータサイズ
 * @param: データ
 * @return: true（成功） / false（失敗）
*****************************************************************************/
function UpdateBackupDataOffsetCP(backupId, offset, size, data)
{
	var ret = true;

	if( !Connect() ) {
		return false;
	}

	try {
		// BackUp Write
		AdjustCmd.DataSize = 20 + size;
		AdjustCmd.SetParam32(0, 0x00000001);	// WRITE
		AdjustCmd.SetParam32(1, backupId);		// BackupID
		AdjustCmd.SetParam32(2, offset);		// Offset
		AdjustCmd.SetParam32(3, size);			// size
		AdjustCmd.SetParam32(4, 0x00000001);	// CPU ID=00000001

		for( var i = 0; i < size; i++ ) {
			AdjustCmd.SetParam8(i + 20, data[i]);
		}

		if( !AdjustCmd.CmdIssue(CMD_ISSUE_WR_BKUP_OFFSET_CP.blk, CMD_ISSUE_WR_BKUP_OFFSET_CP.cd) ) {
			mintole.error("UpdateBackupDataOffsetCP: Write Backup FAIL");
			Disconnect();
			throw "error";
		}
		Disconnect();

		// Save backup
		if( !SaveBackupData() ) {
			throw "error";
		}
	}
	catch(e) {
		ret = false;
	}

	return ret;
}
