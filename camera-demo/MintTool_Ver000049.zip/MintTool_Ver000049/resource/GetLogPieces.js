
/*================================================================================
 * Get log Pieces class
================================================================================*/
var GetLogPieces = function() {
	this.init();

	this.processList = new Array(
		{
			"name" : "Mint Tool Ver.",
			"func" : this.getToolVer,
		},
		{
			"name" : "Setting Info.",
			"func" : this.getSettingInfo,
		},
		{
			"name" : "klog",
			"func" : this.getklog,
			"errExit" : true,
		},
		{
			"name" : "Boot log",
			"func" : this.getBootlog,
			"errExit" : true,
		},
		{
			"name" : "ULOGIO log",
			"func" : this.getULOGIOlog,
			"errExit" : true,
		},
		{
			"name" : "DMM log",
			"func" : this.getDMMlog,
		},
		{
			"name" : "Firmware Ver.",
			"func" : this.getFirmVer,
		},
		{
			"name" : "Adjust Backup",
			"func" : this.getAdjustBackup,
		},
		{
			"name" : "Model Data",
			"func" : this.getModelData,
		},
		{
			"name" : "blog info.",
			"func" : this.getBlogInfo,
		},
		{
			"name" : "Loader log",
			"func" : this.getLoaderLog,
		},
		{
			"name" : "Front Esc log",
			"func" : this.getFrontEscLog,
		},
		{
			"name" : "Front Con log",
			"func" : this.getFrontConLog,
		},
		// 確認中
		// {
		// 	"func" : this.getImolaLog,
		// },
		{
			"name" : "Esc log",
			"func" : this.getEscLog,
			"errExit" : true,
		},
		{
			"name" : "Thread monitor log (MP)",
			"func" : this.getTmonLogMP,
		},
		{
			"name" : "blog",
			"func" : this.getblog,
		},
		{
			"name" : "UIPC log",
			"func" : this.getUIPCLog,
		},
		{
			"name" : "Esc log (CP)",
			"func" : this.getEscLogCP,
		},
		{
			"name" : "Core file",
			"func" : this.getCoreFile,
			"notForSelect" : true,
		},
		{
			"name" : "Codec log",
			"func" : this.getCodecLog,
			"notForSelect" : true,
		},
		{
			"name" : "Front Ini log",
			"func" : this.getFrontIniLog,
		},
		{
			"name" : "CP log",
			"func" : this.getCPLog,
		},
		{
			"name" : "Zynq log",
			"func" : this.getZynqLog,
		},
		{
			"name" : "Esc log (zynq)",
			"func" : this.getEscLogZynq,
		},
		{
			"name" : "Wait for making core file",
			"func" : this.waitMakingCoreFile,
			"notForSelect" : true,
		},
		{
			"name" : "Packing log as ZIP",
			"func" : this.packLogAsZIP,
			"noErrExec" : true,
			"notForSelect" : true,
		}
	);
}


/*================================================================================
 * Initialize
 * (System function, DO NOT EDIT)
================================================================================*/
GetLogPieces.prototype.init = function()
{
	this.hasErr = false;
	this.escLogFol = "";
	this.isGetCPLog = false;
	this.CPLogDir = "";
	this.ZynqLogDir = "";
	this.corelogfilezip = "";
}


/*================================================================================
 * Pre-process
 * (System function, DO NOT EDIT)
================================================================================*/
GetLogPieces.prototype.preProc = function()
{
	if( !Connect() ) {
		return false;
	}

	this.init();

	RamSet(0x0404,0x000300AB,0x01); // EC Blog Write 禁止

	return true;
}


/*================================================================================
 * Execute process of getting log pieces
 * (System function, DO NOT EDIT)
================================================================================*/
GetLogPieces.prototype.exec = function(DirectroyName)
{
	try {
		for( var i = 0; i < this.processList.length; i++ )
		{
			var procObj = this.processList[i];
			if( !procObj["func"] ) { continue; }
			if( procObj["noErrExec"] && this.hasErr ) { continue; }
			if( !procObj["enabled"] && !procObj["notForSelect"] ) { continue; }

			var result = procObj["func"].bind(this)(DirectroyName);
			mintole.debug("Get log: " + procObj["name"]);
			
			if( result == false ) {
				mintole.debug("Fail to Get log piece");

				if( this.hasErr == false ) {
					this.hasErr = true;
				}
				if( procObj["errExit"] ) {
					mintole.debug("Break Get log because of fail");
					break;
				}
			}
		}
	}
	catch(e) {
		mintole.alert("System error: [" + e + "]");
		this.hasErr = true;
	}
}


/*================================================================================
 * Post-process
 * (System function, DO NOT EDIT)
================================================================================*/
GetLogPieces.prototype.postProc = function()
{
	Disconnect();

	RamSet(0x0404,0x000300AB,0x00); // EC Blog Write 許可

	return true;
}


/*================================================================================
 * Get process name
 * (System function, DO NOT EDIT)
================================================================================*/
GetLogPieces.prototype.getProcName = function(i)
{
	return this.processList[i].name;
}


/*================================================================================
 * Get process name for ID
 * (System function, DO NOT EDIT)
================================================================================*/
GetLogPieces.prototype.getProcNameForID = function(i)
{
	return this.processList[i].name ? this.processList[i].name.replace(/[^a-zA-Z0-9]/g, "_") : "";
}


/*================================================================================
 * Get process length
 * (System function, DO NOT EDIT)
================================================================================*/
GetLogPieces.prototype.getProcLen = function()
{
	return this.processList.length;
}


/*================================================================================
 * Get process is not for select
 * (System function, DO NOT EDIT)
================================================================================*/
GetLogPieces.prototype.isNotForSelect = function(i)
{
	return this.processList[i]["notForSelect"];
}


/*================================================================================
 * Get process is not for select
 * (System function, DO NOT EDIT)
================================================================================*/
GetLogPieces.prototype.switchEnable = function(i, e)
{
	return this.processList[i]["enabled"] = e;
}


/***********************************************************************************************
 ***********************************************************************************************
 * YOU CAN ADD / DELETE / EDIT FOLLOW FUNCTIONS, BUT DO NOT DO THEM BELOW.
 ***********************************************************************************************
 ***********************************************************************************************/


/*================================================================================
 * Get Tool version
================================================================================*/
GetLogPieces.prototype.getToolVer = function(DirectroyName)
{
	var tool_verfile = DirectroyName + "\\ToolVersion.txt";

	var fso = new ActiveXObject("Scripting.FileSystemObject");
	var wStream = fso.CreateTextFile(tool_verfile);
	wStream.WriteLine(ToolVersion);
	wStream.Close();

	return true;
}


/*================================================================================
 * Get Setting Info
================================================================================*/
GetLogPieces.prototype.getSettingInfo = function(DirectroyName)
{
	if( settingInfo.read() == false ) {
		return false;
	}

	var settinginfo_file = DirectroyName + "\\SettingInfo.txt";
	
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	var wStream = fso.CreateTextFile(settinginfo_file);
	wStream.WriteLine("Senser Mode           = " + settingInfo.getSenserModeStr());
	wStream.WriteLine("Escape Log Function   = " + settingInfo.getEscapeLogModeStr());
	wStream.WriteLine("Emargency Reboot Mode = " + settingInfo.getExceptionRebootModeStr());
	wStream.WriteLine("UART Comm Mode        = " + settingInfo.getUARTModeStr());
	wStream.Close();
	
	return true;
}


/*================================================================================
 * Get klog
================================================================================*/
GetLogPieces.prototype.getklog = function(DirectroyName)
{
	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x00);
	if( !AdjustCmd.CmdIssue(0x0601, 0x4023) ) {
		mintole.alert("Get klog FAIL");
		return false;
	}

	if( !AdjustCmd.SavetoFile(DirectroyName + "\\GetLog_klog.txt", AdjustCmd.ResSize, 0, 1) ) {
		mintole.alert("Save klog FAIL");
		return false;
	}
	
	return true;
}


/*================================================================================
 * Get bootlog
================================================================================*/
GetLogPieces.prototype.getBootlog = function(DirectroyName)
{
	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x01);
	if( !AdjustCmd.CmdIssue(0x0601, 0x4023) ) {
		mintole.alert("Get bootlog FAIL");
		return false;
	}

	if( !AdjustCmd.SavetoFile(DirectroyName + "\\GetLog_bootlog.txt", AdjustCmd.ResSize, 0, 1) ) {
		mintole.alert("Save bootlog FAIL");
		return false;
	}
	
	return true;
}


/*================================================================================
 * Get ULOGIO Log
================================================================================*/
GetLogPieces.prototype.getULOGIOlog = function(DirectroyName)
{
	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x02);
	if( !AdjustCmd.CmdIssue(0x0601, 0x4023) ) {
		mintole.alert("Get ULOGIO FAIL");
		return false;
	}

	if( !AdjustCmd.SavetoFile(DirectroyName + "\\GetLog_ULOGIO.bin", AdjustCmd.ResSize, 0, 1) ) {
		mintole.alert("Save ULOGIO FAIL");
		return false;
	}
	
	return true;
}


/*================================================================================
 * Get DMM Log
================================================================================*/
GetLogPieces.prototype.getDMMlog = function(DirectroyName)
{
	if( AdjustCmd.CmdIssue(0x0e01, 0x0000) ) {
		AdjustCmd.SavetoFile(DirectroyName + "\\Dmm_log.txt", AdjustCmd.ResSize, 0, 1);
	}
	else {
		mintole.alert("Get DMM Log ERROR");
		return false;
	}

	return true;
}


/*================================================================================
 * Get Firm Ver
================================================================================*/
GetLogPieces.prototype.getFirmVer = function(DirectroyName)
{
	if( setVer.readFirmwareVer() ) {
		prm = setVer.getFirmwareVer();

		var firm_verfile = DirectroyName + "\\version.txt";

		var fso = new ActiveXObject("Scripting.FileSystemObject");
		var wStream = fso.CreateTextFile(firm_verfile);
		wStream.WriteLine(setVer.getFirmwareVer());
		wStream.Close();
		return true;
	}
	else {
		return false;
	}
}


/*================================================================================
 * Get Adjust Backup
================================================================================*/
GetLogPieces.prototype.getAdjustBackup = function(DirectroyName)
{
	var path = DirectroyName + "\\" + "AdjustData.bin";
	
	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x00);
	if( AdjustCmd.CmdIssue(0x0603, 0x0005) ) {
		if( !AdjustCmd.SavetoFile(path, AdjustCmd.ResSize, 0, 1) ) {
			mintole.error("Get Adjust Backup FAIL !");
			return false;
		}
	}
	else {
		mintole.error("Get Adjust Backup FAIL !");
		return false;
	}

	return true;
}


/*================================================================================
 * Get Model Data
================================================================================*/
GetLogPieces.prototype.getModelData = function(DirectroyName)
{
	if( AdjustCmd.CmdIssue(0x0104, 0x0001) ) {
		AdjustCmd.SavetoFile(DirectroyName + "\\ModelData.bin", AdjustCmd.ResSize, 0, 1);
	}
//	else {
//		mintole.alert("Get Model Data FAIL");
//	}
	return true;
}


/*================================================================================
 * Get BLOG INFO
================================================================================*/
GetLogPieces.prototype.getBlogInfo = function(DirectroyName)
{
	if( AdjustCmd.CmdIssue(0x0104, 0x0002) ) {
		AdjustCmd.SavetoFile(DirectroyName + "\\BlogInfo.bin", AdjustCmd.ResSize, 0, 1);
	}
//	else {
//		mintole.alert("Get BLOG INFO FAIL");
//	}
	return true;
}


/*================================================================================
 * Get Loader log
================================================================================*/
GetLogPieces.prototype.getLoaderLog = function(DirectroyName)
{
	//BKID_RAM_ADDR_LOADER_LOG : 0x00FA016D
	//BKID_RAM_SIZE_LOADER_LOG : 0x00FA016E
	MemDumpSaveToFileByBackupId( DirectroyName + "\\Loader.log", 0x00FA016D, 0x00FA016E );

	return true;
}


/*================================================================================
 * Get FrontEsc log
================================================================================*/
GetLogPieces.prototype.getFrontEscLog = function(DirectroyName)
{
	// BKID_RAM_ADDR_LOADER_FRONTCON_WORKAREA : 0x00FA0022
	// BKID_RAM_SIZE_LOADER_FRONTCON_WORKAREA : 0x00FA0057
	var charon_file = DirectroyName + "\\" + "FrontEsc.log";
	MemDumpSaveToFileByBackupId(charon_file, 0x00FA0022, 0x00FA0057);
	
	return true;
}


/*================================================================================
 * Get FrontCon log
================================================================================*/
GetLogPieces.prototype.getFrontConLog = function(DirectroyName)
{
	var darwin_file = DirectroyName + "\\" + "FrontCon.log";
	var icType = new Array();

	// Darwinがついているかを判定する
	// BKID_LDR_CFG_PWR_TYPE : 0x00510001
	if( ReadBackupData8(0x00510001, icType) ) {
		if( icType.pop() == 7 ) {	// LDR_POWER_IC_TYPE_DARWIN = 7
			comGetDarwinLog( darwin_file );
		}
	}

	delete icType;
	return true;
}


/*================================================================================
 * Get Imola log
================================================================================*/
// GetLogPieces.prototype.getImolaLog = function(DirectroyName)
// {
// 	AdjustCmd.DataSize = 4; 		// パラメータのバイト数.
// 	AdjustCmd.SetParam8(0, 0x02);	// IMOLA.
// 	AdjustCmd.SetParam8(1, 0x00);	// Not Use.
// 	AdjustCmd.SetParam8(2, 0x00);	// ログが残っていたら取得する.
// 	AdjustCmd.SetParam8(3, 0x00);	// Not Use.

// 	if( AdjustCmd.CmdIssue(0x0502, 0x0020) ) {
// 		if( !AdjustCmd.SavetoFile(DirectroyName + "\\GetLog_Imola.bin", AdjustCmd.ResSize, 0, 1) ) {
// 			mintole.error("Get ImolaLog ERROR");
// 			return false;
// 		}
// 	}

// 	return true;
// }


/*================================================================================
 * Get Esc log
================================================================================*/
GetLogPieces.prototype.getEscLog = function(DirectroyName)
{
	this.escLogFol = DirectroyName + "\\escapelog\\";
	
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	if( !fso.FolderExists(this.escLogFol) ) {
		if( !fso.CreateFolder(this.escLogFol) ) {
			mintole.alert("Fail to create directory: " + fso.ErrMsg);
			return false;
		}
	}

	// klog
	var logfilename = this.escLogFol + "ulogio_klog.txt";
	if( !FileCtl.FileRead(logfilename, "/log/ulogio_klog.txt") ) {
		FileCtl.FileRead(logfilename, "/tmp/ulogio_klog.txt");
	}

	// tlog
	logfilename = this.escLogFol + "ulogio_tlog.txt";
	if( !FileCtl.FileRead(logfilename, "/log/ulogio_tlog.txt") ) {
		FileCtl.FileRead(logfilename, "/tmp/ulogio_tlog.txt");
	}

	// escapelog
	logfilename = this.escLogFol + "escapelog.bin";
	if( !FileCtl.FileRead(logfilename, "/log/escapelog.bin") ) {
		FileCtl.FileRead(logfilename, "/tmp/escapelog.bin");
	}

	delete fso;

	return true;
}


/*================================================================================
 * Get Thread monitor Log for MP
================================================================================*/
GetLogPieces.prototype.getTmonLogMP = function(DirectroyName)
{
	logfilename = this.escLogFol + "ThreadMonitor.bin";
	if( !FileCtl.FileRead(logfilename, "/log/ThreadMonitor.bin") ) {
		FileCtl.FileRead(logfilename, "/tmp/ThreadMonitor.bin");
	}

	return true;
}


/*================================================================================
 * Get blog
================================================================================*/
GetLogPieces.prototype.getblog = function(DirectroyName)
{
	logfilename = this.escLogFol + "ldr_escapelog.bin";
	MemDumpSaveToFileByBackupId(logfilename, 0x00FA006E, 0x00FA0085);
}


/*================================================================================
 * Get UIPC Log
================================================================================*/
GetLogPieces.prototype.getUIPCLog = function(DirectroyName)
{

	// uipc_stat_kernel.txt
	logfilename = DirectroyName + "\\uipc_stat_kernel.txt";
	if( FileCtl.FileRead(logfilename, "/tmp/uipc_stat_kernel.txt") ) {
		FileCtl.FileDelete("/tmp/uipc_stat_kernel.txt");
	}

	// uipc_stat_user.txt
	logfilename = DirectroyName + "\\uipc_stat_user.txt";
	if( FileCtl.FileRead(logfilename, "/tmp/uipc_stat_user.txt") ) {
		FileCtl.FileDelete("/tmp/uipc_stat_user.txt");
	}

	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x03);
	if( !AdjustCmd.CmdIssue(0x0601, 0x4023) ) {
		mintole.alert("Get uipc log FAIL");
		return false;
	}
	else {
		if( !AdjustCmd.SavetoFile(DirectroyName + "\\GetLog_uipc.txt", AdjustCmd.ResSize, 0, 1) ) {
			mintole.alert("Save uipc FAIL");
			return false;
		}
	}

	return true;
}


/*================================================================================
 * Get Esc log for CP
================================================================================*/
GetLogPieces.prototype.getEscLogCP = function(DirectroyName)
{
	var CPDirName = DirectroyName + "\\escapelog\\";

	var fso = new ActiveXObject("Scripting.FileSystemObject");
	if( !fso.FolderExists(CPDirName) ) {
		if( !fso.CreateFolder(CPDirName) ) {
			mintole.alert("Fail to create directory: " + fso.ErrMsg);
			return false;
		}
	}

	CPDirName = CPDirName + "\\cp\\";

	var fso = new ActiveXObject("Scripting.FileSystemObject");
	if( !fso.FolderExists(CPDirName) ) {
		if( !fso.CreateFolder(CPDirName) ) {
			mintole.alert("Fail to create directory: " + fso.ErrMsg);
			return false;
		}
	}

	// klog
	logfilename = CPDirName + "ulogio_klog.bin";
	if( !FileCtl.FileRead(logfilename, "/log/cp/ulogio_klog.bin") ) {
		FileCtl.FileRead(logfilename, "/tmp/cp/ulogio_klog.bin");
	}

	// tlog
	logfilename = CPDirName + "ulogio_tlog.bin";
	if( !FileCtl.FileRead(logfilename, "/log/cp/ulogio_tlog.bin") ) {
		FileCtl.FileRead(logfilename, "/tmp/cp/ulogio_tlog.bin");
	}

	// escapelog
	logfilename = CPDirName + "escapelog.bin";
	if( !FileCtl.FileRead(logfilename, "/log/cp/escapelog.bin") ) {
		FileCtl.FileRead(logfilename, "/tmp/cp/escapelog.bin");
	}

	return true;
}

/*================================================================================
 * Get Esc log for zynq
================================================================================*/
GetLogPieces.prototype.getEscLogZynq = function(DirectroyName)
{
	var ZynqDirName = DirectroyName + "\\escapelog\\";

	var fso = new ActiveXObject("Scripting.FileSystemObject");
	if( !fso.FolderExists(ZynqDirName) ) {
		if( !fso.CreateFolder(ZynqDirName) ) {
			mintole.alert("Fail to create directory: " + fso.ErrMsg);
			return false;
		}
	}

	ZynqDirName = ZynqDirName + "\\zynq\\";

	var fso = new ActiveXObject("Scripting.FileSystemObject");
	if( !fso.FolderExists(ZynqDirName) ) {
		if( !fso.CreateFolder(ZynqDirName) ) {
			mintole.alert("Fail to create directory: " + fso.ErrMsg);
			return false;
		}
	}

	// A53 escapelog
	logfilename = ZynqDirName + "escapelog_a53.bin";
	if( !FileCtl.FileRead(logfilename, "/log/zynq/escapelog_a53.bin") ) {
		FileCtl.FileRead(logfilename, "/tmp/zynq/escapelog_a53.bin");
	}

	// R5_0 escapelog
	logfilename = ZynqDirName + "escapelog_r5-0.bin";
	if( !FileCtl.FileRead(logfilename, "/log/zynq/escapelog_r5-0.bin") ) {
		FileCtl.FileRead(logfilename, "/tmp/zynq/escapelog_r5-0.bin");
	}

	// FSBL escapelog
	logfilename = ZynqDirName + "escapelog_fsbl.bin";
	if( !FileCtl.FileRead(logfilename, "/log/zynq/escapelog_fsbl.bin") ) {
		FileCtl.FileRead(logfilename, "/tmp/zynq/escapelog_fsbl.bin");
	}

	return true;
}

/*================================================================================
 * Get Core file
================================================================================*/
GetLogPieces.prototype.corefiles = new Array(
	// files listed bellow is from as in /usr/bin of KT:37111_00.2016082401
	"adjstctl.elf",
	"appdbglv.sh",
	"bk.elf",
	"bootin.elf",
	"bsa_server",
	"btblog.elf",
	"bt_firm.hcd",
	"btRFTest.elf",
	"busybox",
	"change_mode.sh",
	"common.src",
	"compat_firmware.sh",
	"crypter.elf",
	"dhd",
	"doemparse.sh",
	"GPIO2SDIO.elf",
	"im.elf",
	"iw",
	"launch_shell.elf",
	"mkfifo",
	"mpr_monio.elf",
	"mpr_viewLog.elf",
	"mwf_monio.elf",
	"netblog.elf",
	"network.sh",
	"NsBkSet.elf",
	"openssl",
	"orb-server",
	"rcvcmd.elf",
	"scenario.elf",
	"SDIO2GPIO.elf",
	"sen.elf",
	"SetPort.elf",
	"sndcmd.elf",
	"startBTCore.sh",
	"testcmd.elf",
	"top",
	"ud_datcnv.elf",
	"ud_send_lsi.elf",
	"udtrbody.bin",
	"ujlog.elf",
	"ulogio",
	"ulogio.elf",
	"up.sh",
	"usb_insmod.sh",
	"uuidgen",
	"VerifyHostCert.elf",
	"WebApiLauncher.sh",
	"wl",
	"Wltestcmd",
	"wpa_cli",
	"wpa_supplicant",
	"WS_SubProcess.elf"
);
GetLogPieces.prototype.getCoreFile = function(DirectroyName)
{
	if( settings.get("getLogCore") != true ) {
		return true;
	}

	var coreDir = this.escLogFol;
	this.corelogfilezip = coreDir + "corefile.zip";
	var nnames = this.corefiles.length;
	var zipf = false;
	var i;
	var corelogfilename;
	var filef;
	var zipAsFolder;
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	var wshapp = new ActiveXObject("Shell.Application");
	for (i = 0; i < nnames; i++) {
		filef = false;
		var corefile = this.corefiles[i];
		corelogfilename = coreDir + corefile + ".core.lz77";
		if (FileCtl.FileRead(corelogfilename, "/log/" + corefile + ".core.lz77")) {
			filef = true;
		}
		else if (FileCtl.FileRead(corelogfilename, "/tmp/" + corefile + ".core.lz77")) {
			filef = true;
		}

		if (! filef) {
			corelogfilename = coreDir + corefile + ".core";
			if (FileCtl.FileRead(corelogfilename, "/log/" + corefile + ".core")) {
				filef = true;
			}
			else if (FileCtl.FileRead(corelogfilename, "/tmp/" + corefile + ".core")) {
				filef = true;
			}
		}

		if (filef) {
			Sleep(1);
		}

		if (! fso.FileExists(corelogfilename)) {
			continue;
		}

		// coreファイルが取得されていれば
		// zipの処理
		if (! zipf) {
			// ZIPファイルの箱を作る
			var targetZip = fso.CreateTextFile(this.corelogfilezip, true);
			targetZip.Write("PK" + String.fromCharCode(5,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0));
			targetZip.Close();
			zipf = true;
			// ファイルを追加する
			zipAsFolder = wshapp.NameSpace(fso.GetAbsolutePathName(this.corelogfilezip));
		}

		// ZIPファイルに追加
		zipAsFolder.MoveHere(fso.GetAbsolutePathName(corelogfilename));
		while (fso.FileExists(corelogfilename)) {
			Sleep( 1 );
		}
	}
	delete wshapp;

	return true;
}


/*================================================================================
 * Remove Core file
================================================================================*/
GetLogPieces.prototype.removeCoreFile = function(DirectroyName)
{
	var nnames = this.corefiles.length;
	var i = 0;
	for (i = 0; i < nnames; i++) {
		var corefile = this.corefiles[i];
		FileCtl.FileDelete("/log/" + corefile + ".core.lz77");
		FileCtl.FileDelete("/log/" + corefile + ".core");
	}
}

/*================================================================================
 * Get Codec Log
================================================================================*/
GetLogPieces.prototype.getCodecLog = function(DirectroyName)
{
	if( settings.get("getLogCodec") != true ) {
		return true;
	}

	// ImolaPictureReportログの取得
	AdjustCmd.DataSize = 4;			// パラメータのバイト数
	AdjustCmd.SetParam8(0, 0x02);    // 
	AdjustCmd.SetParam8(1, 0x00);    // 
	AdjustCmd.SetParam8(2, 0x00);    // 
	AdjustCmd.SetParam8(3, 0x00);    // 

	// コマンド発行
	if( AdjustCmd.CmdIssue(0x0502, 0x0030) ) {
		if( !AdjustCmd.SavetoFile(DirectroyName + "\\GetLog_ImolaPicReport.bin", AdjustCmd.ResSize, 0, 1) ) {
			mintole.error("Get ImolaPicReportLog ERROR");
			return false;
		}
	}

	// Imolaログの取得
	AdjustCmd.DataSize = 4; 		// パラメータのバイト数
	AdjustCmd.SetParam8(0, 0x02);	// 
	AdjustCmd.SetParam8(1, 0x00);	// 
	AdjustCmd.SetParam8(2, 0x01);	// 
	AdjustCmd.SetParam8(3, 0x00);	// 

	// コマンド発行
	if( AdjustCmd.CmdIssue(0x0502, 0x0020) ) {
		if( !AdjustCmd.SavetoFile(DirectroyName + "\\GetLog_Imola.bin", AdjustCmd.ResSize, 0, 1) ) {
			mintole.error("Get ImolaLog ERROR");
			return false;
		}
	}

	return true;
}


/*================================================================================
 * Get FrontIni Log
================================================================================*/
GetLogPieces.prototype.getFrontIniLog = function(DirectroyName)
{
	// BKID_RAM_ADDR_FRONTCON_INIT_DATA : 0x00FA0018
	// BKID_RAM_SIZE_FRONTCON_INIT_DATA : 0x00FA004D
	var frontcon_file = DirectroyName + "\\" + "FrontIni.log";
	MemDumpSaveToFileByBackupIdCP(frontcon_file, 0x00FA0018, 0x00FA004D);

	return true;
}

/*================================================================================
 * Get Zynq Log
================================================================================*/
GetLogPieces.prototype.getZynqLog = function(DirectroyName)
{
	// BackupでZynq起動を確認する。
	var fmt = new Array();
	if( ReadBackupData32(0x1CF0116 , fmt) ) {
		if(fmt[0] != 0x0011){
			return true;
		}
	}
	else{
		return true;
	}

	this.ZynqLogDir = DirectroyName + "\\zynq";
	if( !WshFs.FolderExists(this.ZynqLogDir) ) {
		if( !WshFs.CreateFolder(this.ZynqLogDir) ) {
			this.isGetCPLog = false;
			this.ynqLogDir = "";
			mintole.error("Get zynq Log ERROR: " + WshFs.ErrMsg);
			return false;
		}
	}

	this.getFSBLLog(this.ZynqLogDir);
	this.getA53Log(this.ZynqLogDir);
	this.getR5_0Log(this.ZynqLogDir);
	//this.getR5_1Log(this.ZynqLogDir);

	return true;
}


/*================================================================================
 * Get A53 log
================================================================================*/
GetLogPieces.prototype.getA53Log = function(DirectroyName)
{
	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x08);
	if( !AdjustCmd.CmdIssue(0x0601, 0x4023) ) {
		mintole.alert("Get GetLog_A53log FAIL");
		return false;
	}
	else {
		if( !AdjustCmd.SavetoFile(DirectroyName + "\\GetLog_A53.bin", AdjustCmd.ResSize, 0, 1) ) {
			mintole.alert("Save uipc FAIL");
			return false;
		}
	}
	return true;
}

/*================================================================================
 * Get R5_0 log
================================================================================*/
GetLogPieces.prototype.getR5_0Log = function(DirectroyName)
{
	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x09);
	if( !AdjustCmd.CmdIssue(0x0601, 0x4023) ) {
		mintole.alert("Get GetLog_R5_0 log FAIL");
		return false;
	}
	else {
		if( !AdjustCmd.SavetoFile(DirectroyName + "\\GetLog_R5-0.bin", AdjustCmd.ResSize, 0, 1) ) {
			mintole.alert("Save uipc FAIL");
			return false;
		}
	}
	return true;
}

/*================================================================================
 * Get R5_1 log
================================================================================*/
GetLogPieces.prototype.getR5_1Log = function(DirectroyName)
{
	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x0a);
	if( !AdjustCmd.CmdIssue(0x0601, 0x4023) ) {
		mintole.alert("Get GetLog_R5_1 log FAIL");
		return false;
	}
	else {
		if( !AdjustCmd.SavetoFile(DirectroyName + "\\GetLog_R5-1.bin", AdjustCmd.ResSize, 0, 1) ) {
			mintole.alert("Save uipc FAIL");
			return false;
		}
	}
	return true;
}

/*================================================================================
 * Get FSBL log
================================================================================*/
GetLogPieces.prototype.getFSBLLog = function(DirectroyName)
{
	AdjustCmd.DataSize = 1;
	AdjustCmd.SetParam8(0, 0x0b);
	if( !AdjustCmd.CmdIssue(0x0601, 0x4023) ) {
		mintole.alert("Get GetLog_FSBL log FAIL");
		return false;
	}
	else {
		if( !AdjustCmd.SavetoFile(DirectroyName + "\\GetLog_FSBL.bin", AdjustCmd.ResSize, 0, 1) ) {
			mintole.alert("Save uipc FAIL");
			return false;
		}
	}
	return true;
}

/*================================================================================
 * Get CP Log
================================================================================*/
GetLogPieces.prototype.getCPLog = function(DirectroyName)
{
	var system = new Array();
	// BKID_SYS_LSI_NUM_TYPE : 0x10D000A
	if( ReadBackupData8(0x10D000A, system) ) {
		if( system.pop() != 7 ) {	// SYS_OT_MIRA以外はCPログを取得する
			this.isGetCPLog = true;
			this.CPLogDir = DirectroyName + "\\CP";
		
			if( !WshFs.FolderExists(this.CPLogDir) ) {
				if( !WshFs.CreateFolder(this.CPLogDir) ) {
					this.isGetCPLog = false;
					this.CPLogDir = "";
					mintole.error("Get CP Log ERROR: " + WshFs.ErrMsg);
					return false;
				}
			}
		}
	}

	this.getCPbLog(DirectroyName);
	this.getCPtLog(DirectroyName);
	this.getCPEscbLog(DirectroyName);
	this.getCPkLog(DirectroyName);
	this.getCPLoaderLog(DirectroyName);

	// Snapshot Debug Image
	this.getCPSSDI(DirectroyName);

	this.getCPEsctlog(DirectroyName);
	this.getCPEscklog(DirectroyName);
	this.getCPEscblog(DirectroyName);
	this.getCPUIPCLog(DirectroyName);
	this.getCPTmonLog(DirectroyName);
	this.getCPDMMLog(DirectroyName);
	this.getCPLensLog(DirectroyName);
	this.getCPVPHLog(DirectroyName);

	return true;
}


/*================================================================================
 * Get CP blog
================================================================================*/
GetLogPieces.prototype.getCPbLog = function(DirectroyName)
{
	if( this.isGetCPLog == false ) { return true; }
	
	//BKID_RAM_ADDR_ULOGIO, BKID_RAM_SIZE_ULOGIO
	MemDumpSaveToFileByBackupIdCP(this.CPLogDir + "\\blog.bin", 0xFA0034, 0xFA0069);
	
	return true;
}


/*================================================================================
 * Get CP tlog
================================================================================*/
GetLogPieces.prototype.getCPtLog = function(DirectroyName)
{
	if( this.isGetCPLog == false ) { return true; }
	
	//BKID_RAM_ADDR_BOOT_TIME, BKID_RAM_ADDR_BOOT_TIME
	MemDumpSaveToFileByBackupIdCP(this.CPLogDir + "\\tlog.bin", 0xFA000B, 0xFA0040);
	ConvertBoottimeLogBin2Text(this.CPLogDir + "\\tlog.txt", this.CPLogDir + "\\tlog.bin");

	return true;
}


/*================================================================================
 * Get CP Esc blog
================================================================================*/
GetLogPieces.prototype.getCPEscbLog = function(DirectroyName)
{
	if( this.isGetCPLog == false ) { return true; }
	
	//BKID_RAM_ADDR_ESCAPE, BKID_RAM_SIZE_ESCAPE
	MemDumpSaveToFileByBackupIdCP(this.CPLogDir + "\\escape_blog.bin", 0xFA006E, 0xFA0085);

	return true;
}


/*================================================================================
 * Get CP klog
================================================================================*/
GetLogPieces.prototype.getCPkLog = function(DirectroyName)
{
	if( this.isGetCPLog == false ) { return true; }
	
	//BKID_RAM_ADDR_KLOG, BKID_RAM_SIZE_KLOG
	MemDumpSaveToFileByBackupIdCP(this.CPLogDir + "\\klog.txt", 0xFA001F, 0xFA0054);

	return true;
}


/*================================================================================
 * Get CP loader Log
================================================================================*/
GetLogPieces.prototype.getCPLoaderLog = function(DirectroyName)
{
	if( this.isGetCPLog == false ) { return true; }
	
	//BKID_RAM_ADDR_LOADER_LOG, BKID_RAM_SIZE_LOADER_LOG
	MemDumpSaveToFileByBackupIdCP( this.CPLogDir + "\\Loader.log", 0x00FA016D, 0x00FA016E );

	return true;
}


/*================================================================================
 * Get CP Snapshot debug image
================================================================================*/
GetLogPieces.prototype.getCPSSDI = function(DirectroyName)
{
	if( this.isGetCPLog == false ) { return true; }
	if( settings.get("getLogSSDI") != true ) {
		return true;
	}
	
	GetSnapshotDebugImageCP(this.CPLogDir + "\\snapshot_debug.sdmp");
	RemoveSSDIMagic();

	return true;
}


/*================================================================================
 * Get CP Esc tlog
================================================================================*/
GetLogPieces.prototype.getCPEsctlog = function(DirectroyName)
{
	if( this.isGetCPLog == false ) { return true; }
	
	//BKID_RAM_ADDR_CP_ESCAPE_BOOT_TIME : 0x00FA01CA
	//BKID_RAM_SIZE_BOOT_TIME           : 0x00FA0040
	MemDumpSaveToFileByBackupIdForSusLog( this.CPLogDir + "\\sus_tlog.bin", 0x00FA01CA, 0x00FA0040 );
	ConvertBoottimeLogBin2Text(this.CPLogDir + "\\sus_tlog.txt", this.CPLogDir + "\\sus_tlog.bin");

	return true;
}


/*================================================================================
 * Get CP Esc klog
================================================================================*/
GetLogPieces.prototype.getCPEscklog = function(DirectroyName)
{
	if( this.isGetCPLog == false ) { return true; }
	
	//BKID_RAM_ADDR_CP_ESCAPE_KLOG : 0x00FA01CD
	//BKID_RAM_SIZE_KLOG           : 0x00FA0054
	MemDumpSaveToFileByBackupIdForSusLog( this.CPLogDir + "\\sus_klog.txt", 0x00FA01CD, 0x00FA0054 );
	
	return true;
}


/*================================================================================
 * Get CP Esc blog
================================================================================*/
GetLogPieces.prototype.getCPEscblog = function(DirectroyName)
{
	if( this.isGetCPLog == false ) { return true; }

	//BKID_RAM_ADDR_CP_ESCAPE_LOG : 0x00FA01C7
	//BKID_RAM_SIZE_ULOGIO        : 0x00FA0069
	MemDumpSaveToFileByBackupIdForSusLog( this.CPLogDir + "\\sus_blog.bin", 0x00FA01C7, 0x00FA0069 );

	return true;
}


/*================================================================================
 * Get CP UIPC Log
================================================================================*/
GetLogPieces.prototype.getCPUIPCLog = function(DirectroyName)
{
	if( this.isGetCPLog == false ) { return true; }

	// UIPC OOM
	AdjustCmd.DataSize = 0;	// parameter size.
	if( AdjustCmd.CmdIssue(0x060B, 0x0011) ) {	// [0011] GET_UIPC_OOM
		AdjustCmd.SavetoFile(this.CPLogDir + "\\uipc_stat_kernel.txt", AdjustCmd.ResSize, 0, 1);
	}
	else {
		mintole.error("Fail to get uipc_stat_kernel.txt on CP");
	}

	// UIPC Log
	AdjustCmd.DataSize = 0;	// parameter size.
	if( AdjustCmd.CmdIssue(0x060B, 0x0012) ) {	// [0012] GET_UIPC_LOG
		AdjustCmd.SavetoFile(this.CPLogDir + "\\GetLog_uipc.txt", AdjustCmd.ResSize, 0, 1);
	}
	else {
		mintole.error("Fail to get GetLog_uipc.txt on CP");
	}

	return true;
}


/*================================================================================
 * Get CP Thread monitor Log
================================================================================*/
GetLogPieces.prototype.getCPTmonLog = function(DirectroyName)
{
	if( this.isGetCPLog == false ) { return true; }

	var binFileName = this.CPLogDir + "\\tmon.bin";
	var txtFileName = this.CPLogDir + "\\tmon.txt";

	AdjustCmd.DataSize = 0;	// parameter size.
	if( AdjustCmd.CmdIssue(0x060B, 0x0021) ) {	// [0021] GET_THREAD_MONITOR_LOG
		AdjustCmd.SavetoFile(binFileName, AdjustCmd.ResSize, 0, 1);
		ConvertThreadMonitorBin2Text(txtFileName, binFileName);
	}
	else {
		mintole.error("Fail to get Thread monitor log on CP");
		return false;
	}

	return true;
}


/*================================================================================
 * Get CP DMM Log
================================================================================*/
GetLogPieces.prototype.getCPDMMLog = function(DirectroyName)
{
	if( this.isGetCPLog == false ) { return true; }

	if( AdjustCmd.CmdIssue(0x0e02, 0x0000) ) {
		AdjustCmd.SavetoFile(this.CPLogDir + "\\Dmm_log.txt", AdjustCmd.ResSize, 0, 1);
	}
	else {
		mintole.error("Fail to get Thread monitor log on CP");
		return false;
	}

	return true;
}


/*================================================================================
 * Get CP Lens Log
================================================================================*/
GetLogPieces.prototype.getCPLensLog = function(DirectroyName)
{
	if( this.isGetCPLog == false ) { return true; }

	if( !comGetLensData(this.CPLogDir, true) ) {
		mintole.error("Get Lenslog ERROR");
		return false;
	}

	return true;
}


/*================================================================================
 * Get CP VPH Log
================================================================================*/
GetLogPieces.prototype.getCPVPHLog = function(DirectroyName)
{
	if( this.isGetCPLog == false ) { return true; }

	MemDumpSaveToFileCP(this.CPLogDir + "\\VPHreg.bin", 0xF42A0000, 0x10000);

	return true;
}


/*================================================================================
 * Wait for process of making core file
================================================================================*/
GetLogPieces.prototype.waitMakingCoreFile = function(DirectroyName)
{
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	if (fso.FileExists(this.corelogfilezip)) {
		// core.zipファイルが作られていれば
		var zipWaitTimer = 0;
		while (true) {
			Sleep(1);
			if (zipWaitTimer > 60) {
				// 保険のタイマー処理 完了ダイアログ抑制は1分までとする
				break;
			}
			++zipWaitTimer;
			try {
				fso.OpenTextFile(this.corelogfilezip, 8, false).Close();
				break;
			}
			catch (e) { // writing
			}
		}
	}
}


/*================================================================================
 * Pack log as ZIP
================================================================================*/
GetLogPieces.prototype.packLogAsZIP = function(DirectroyName)
{
	var GetLog_makeZip = document.getElementById("GetLog_makeZip");
	if( GetLog_makeZip.checked != "" ) {
		var wsh = new ActiveXObject("WScript.Shell");
		wsh.Run("powershell compress-archive " + DirectroyName + " " + DirectroyName + ".zip", 0, true);
		delete wsh;
		
		mintole.info("Pack Log as ZIP");
	}

	return true;
}


/*================================================================================
 * Get Lens Log
================================================================================*/
function comGetLensData(
	DirectroyName,
	isEx
)
{
	// Lens情報取得
	// 情報が格納されているRAMの先頭アドレス取ってきて
	// メモリダンプする サイズは 350000 byte
	// アドレスがNULLの場合はEマウントレンズ無しの機種なので
	// ダンプしない
	// 第2引数isExがtrueの場合はCPから取得.
	var lensdata_file = DirectroyName + "\\" + "LensData.dat";
	var lensdata_axi_file = DirectroyName + "\\" + "LensData_AXI.dat";
	var lensdata_ddr_file = DirectroyName + "\\" + "LensData_DDR.dat";

	AdjustCmd.DataSize = 8;
	AdjustCmd.SetParam32(0, 0x000A0018);
	AdjustCmd.SetParam32(1, 4);

	if (AdjustCmd.CmdIssue(0x0404, 0x00FE)) {
		var lensAdd1 = AdjustCmd.GetResponse8(0);
		var lensAdd2 = AdjustCmd.GetResponse8(1);
		var lensAdd3 = AdjustCmd.GetResponse8(2);
		var lensAdd4 = AdjustCmd.GetResponse8(3);
		//alert(lensAdd1.toString(16) + lensAdd2.toString(16) + lensAdd3.toString(16) + lensAdd4.toString(16));
		var lensAdd = lensAdd1;
		lensAdd |= (lensAdd2 << 8);
		lensAdd |= (lensAdd3 << 16);
		lensAdd |= (lensAdd4 << 24);

		if (lensAdd != 0) {
			if (isEx) {
				MemDumpSaveToFileCP(lensdata_file, lensAdd, 35000);
			}
			else {
				MemDumpSaveToFile(lensdata_file, lensAdd, 35000);
			}

			//----------------------------------------------------------------
			// Astraの場合は追加で2領域ダンプする.
			//----------------------------------------------------------------
			// AXIRAM (AXIRAMは非キャッシュで使用).
			if (isEx) {
				MemDumpSaveToFileByBackupIdCP(lensdata_axi_file, 0x00FA0149, 0x00FA014A);
			}
			else {
				MemDumpSaveToFileByBackupId(lensdata_axi_file, 0x00FA0149, 0x00FA014A);
			}

			// まずキャッシュを無効化する.
			AdjustCmd.DataSize = 12;
			AdjustCmd.SetParam32(0, 0x000A0030); // LIFの0x30に
			AdjustCmd.SetParam32(1, 0x00000001);
			AdjustCmd.SetParam32(2, 0x00000001); // 1を書き込むと、cache flushが走るはず.
			if (! AdjustCmd.CmdIssue( 0x0404, 0x00FF)) {
				mintole.alert("RAM write FAIL !");
			}

			AdjustCmd.S_Wait(50); // Vでラッチして動いているので、20ms待てば十分のはず.

			// LENS_DATA
			if (isEx) {
				MemDumpSaveToFileByBackupIdCP(lensdata_ddr_file, 0x00FA0112, 0x00FA00AB);
			}
			else {
				MemDumpSaveToFileByBackupId(lensdata_ddr_file, 0x00FA0112, 0x00FA00AB);
			}

			// LensDataの3ファイルを, LensData.datにまとめる.
			if (WshFs.FileExists(lensdata_axi_file) && WshFs.FileExists(lensdata_ddr_file)) {
				var inputStream  = new ActiveXObject("ADODB.Stream");
				var outputStream = new ActiveXObject("ADODB.Stream");

				inputStream.Open();
				outputStream.Open();

				// for Binary
				inputStream.Type  = 1;
				outputStream.Type = 1;

				inputStream.LoadFromFile(lensdata_file);
				inputStream.CopyTo(outputStream);
				outputStream.SetEOS();

				inputStream.LoadFromFile(lensdata_ddr_file);
				inputStream.CopyTo(outputStream);
				outputStream.SetEOS();

				inputStream.LoadFromFile(lensdata_axi_file);
				inputStream.CopyTo(outputStream);

				// Overwrite LensData.dat
				outputStream.SaveToFile(lensdata_file, 2);
				//outputStream.SaveToFile(DirectroyName + "\\" + "LensDataTEST.bin");

				inputStream.Close();
				outputStream.Close();

				WshFs.DeleteFile(lensdata_ddr_file);
				WshFs.DeleteFile(lensdata_axi_file);
			}
		}
	}
	else {
		return false;
	}

	return true;
}


/*================================================================================
 * Get Darwin Log
================================================================================*/
function comGetDarwinLog(
	fileName
)
{
	if( !Connect() ) {
		return false;
	}

	// Darwinのログをロックする
	AdjustCmd.DataSize = 0;
	if (AdjustCmd.CmdIssue(0x0D20, 0x00C0)) {
		// ロックに成功したらログを取得する
		var File = WshFs.OpenTextFile(fileName, 2, true);
		var MaxReadSize = 0xFF;
		var StartAddress = 0x20000800;
		var TotalReadSize = 0x800;
		var Offset = 0;

		for (i = 0; i < TotalReadSize / MaxReadSize; i++) {
			var ReadSize = 0;
			if (TotalReadSize - Offset >= MaxReadSize) {
				ReadSize = MaxReadSize;
			}
			else {
				ReadSize = TotalReadSize - Offset;
			}

			AdjustCmd.DataSize = 8; 						// parameter size
			AdjustCmd.SetParam32(0, StartAddress + Offset);	// DataOffset
			AdjustCmd.SetParam32(1, ReadSize);				// DataSize
			AdjustCmd.CmdIssue(0x0D20, 0x00FE);				// Code, Command
			AdjustCmd.S_Wait(200);							// Wait (とりあえず待ち)

			for (j = 0; j < ReadSize; j++) {
				var val =  AdjustCmd.GetResponse8(j).toString(16);
				if (val.length == 1) {
					val = '0' + val;
				}
				File.Write(val);
			}
			Offset += ReadSize;
		}
		File.Close();
	}
	else {
		mintole.alert("Darwin Log Feeze FAIL !");
	}

	// Darwinのログをロックする
	AdjustCmd.DataSize = 0;
	if (! AdjustCmd.CmdIssue(0x0D20, 0x00C1)) {
		mintole.alert("Darwin Log UnFreeze FAIL !");
	}

	Disconnect();

	return true;
}


/*================================================================================
 * Camera-ECのBlog書き込みを止める
================================================================================*/
function RamSet(p_blk, p_off, p_data)
{
	AdjustCmd.DataSize = 12;
	AdjustCmd.SetParam32(0, p_off);
	AdjustCmd.SetParam32(1, 1);
	AdjustCmd.SetParam32(2, p_data);
	AdjustCmd.CmdIssue(p_blk, 0xFF);
}
