var WshFs = new ActiveXObject("Scripting.FileSystemObject");

var ToolVersion = "";

// Memory dump max size
var MemDumpMaxSize = 10 *1024*1024;

window.addEventListener("load", function() {
	var baseElm = document.querySelector("base");

	ToolVersion = GetToolVersion("DiademToolVer.txt");
	
	mintole = new ConsoleManager( !baseElm );

	if( !baseElm ) {
		window.resizeTo(1024, 900);
		document.getElementById("ver").innerHTML = ToolVersion + document.getElementById("ver").innerHTML;
	}

	mintole.debug("Mint Tool Ver: " + ToolVersion.replace("Ver ", ""));
	mintole.debug("Current Dir : " + CurrentDir);
});

////////////////////////////////////////////////////////////////////////////////
// Senser �W�Ƃ��m�F
////////////////////////////////////////////////////////////////////////////////
function isDisableSenserIF(isDialog)
{
	// BKID_SYS_SENSER_DEVELOPER_IF  : 0x010d0275
	// Disable = 2
	var disableSenserIF = false;
	var SenserIF = new Array();
	if( ReadBackupData8(0x010d0275, SenserIF) ) {
		if( SenserIF.pop() == 2 ) {
			disableSenserIF = true;
		}
	}
	delete SenserIF;
	if(isDialog && disableSenserIF){
		mintole.alert("This function is not available due to security measures.");
	}
	return disableSenserIF;
}


///////////////////////////////////////////////////////////////////////////////
// �c�[���o�[�W�����擾
///////////////////////////////////////////////////////////////////////////////
function GetToolVersion(
	verfile
)
{
	var rStream = WshFs.OpenTextFile([CurrentDir, verfile].join("\\"));
	var ver = rStream.ReadLine();
	rStream.Close();

	return ver;
}

///////////////////////////////////////////////////////////////////////////////
// Get Date Str for file name
///////////////////////////////////////////////////////////////////////////////
function GetDateStrForFileName()
{
	var now = new Date();
	return now.getFullYear() + "-"
		+ zerofillBefore(now.getMonth()+1, 2) + "-"
			+ zerofillBefore(now.getDate(), 2) + "_"
				+ zerofillBefore(now.getHours(), 2)
					+ zerofillBefore(now.getMinutes(), 2)
						+ zerofillBefore(now.getSeconds(), 2);
}

///////////////////////////////////////////////////////////////////////////////
// ������N����0���߂���
///////////////////////////////////////////////////////////////////////////////
function zerofillBefore(num, dig) {
	if( !num && num != 0 ) { return "0"; }
	if( !dig ) { return "0"; }

	return (("0" * dig) + String(num)).slice(-dig);
}

///////////////////////////////////////////////////////////////////////////////
// �X���[�v
///////////////////////////////////////////////////////////////////////////////
function Sleep(
	T
)
{
	var d1 = new Date().getTime();
	var d2 = new Date().getTime();

	while (d2 < d1 + 1000 * T) {    // T�b�҂�
		d2 = new Date().getTime();
	}

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// ���W�I�{�^���̒l���擾����
///////////////////////////////////////////////////////////////////////////////
function GetRadioBtnValue(
	radioButton
)
{
	var i = 0;

	for (i = 0; i < radioButton.length; i++) {
		if (radioButton[i].checked == true) {
			break;
		}
	}

	return radioButton[i].value;
}

///////////////////////////////////////////////////////////////////////////////
// Edit value in "ulogio.bin" Function
///////////////////////////////////////////////////////////////////////////////
function ChangeUlogioTermMode( 
	ulogioMode		//mode("-1": get value, "0": Disable, "1": UART, "2": USB, "4": Ether)
)
{
	var modFilePath = CurrentDir + "\\resource\\" + "ulogio_mod.bin";

	if (! Connect()) {
		return false;
	}

	// ulogio_mod�t�@�C�������݂���ꍇ�͍폜����
	if (WshFs.FileExists(modFilePath)) {
		WshFs.DeleteFile(modFilePath);
	}

	if (! FileCtl.FileRead(modFilePath, "/setting/ulogio.bin")) {
		Disconnect();
		alert("Read ulogio.bin Error !");
		return false;
	}

	var result = UlogioDoChangeTerm(modFilePath, ulogioMode);

	if (result != 0) {
		WshFs.DeleteFile(modFilePath);
		Disconnect();
		alert("Edit ulogio.bin Error !");
		return false;
	}

	if (! FileCtl.FileWrite("/setting/ulogio.bin", modFilePath)) {
		WshFs.DeleteFile(modFilePath);
		Disconnect();
		alert("Write ulogio.bin Error !");
		return false;
	}

	WshFs.DeleteFile(modFilePath);
	Disconnect();

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// Get value in "ulogio.bin" Function
///////////////////////////////////////////////////////////////////////////////
function GetUlogioTermMode()
{
	var modFilePath = CurrentDir + "\\resource\\" + "ulogio_mod.bin";

	if (! Connect()) {
		return false;
	}

	// ulogio_mod�t�@�C�������݂���ꍇ�͍폜����
	if (WshFs.FileExists(modFilePath)) {
		WshFs.DeleteFile(modFilePath);
	}

	if (! FileCtl.FileRead(modFilePath, "/setting/ulogio.bin")) {
		Disconnect();
		alert("Read ulogio.bin Error !");
		return -1;
	}

	var result = UlogioDoChangeTerm(modFilePath, -1);

	if (result < 0) {
		alert("Get the value Error !");
	}

	WshFs.DeleteFile(modFilePath);
	Disconnect();

	return result;
}

///////////////////////////////////////////////////////////////////////////////
// Edit/Get value in "ulogio.bin" Function
///////////////////////////////////////////////////////////////////////////////
function UlogioDoChangeTerm(
	ulogioFilePath,		// filepath of ulogio.bin
	ulogioMode			// mode: "-1": get value, "0": Disable, "1": UART, "2": USB, "4": Ether
)
{
	var ulogioEditFilePath = CurrentDir + "\\resource\\" + "ulogio_edit.exe";
	var ulogioEditCmd = "\"" + ulogioEditFilePath + "\"" + " " + "\"" + ulogioFilePath + "\"" + " CHAN ";

	// Ulogio Edit Tool Path
	if (! WshFs.FileExists(ulogioEditFilePath)) {
		alert("ulogio Edit Tool is not exist!");
		return -1;
	}

	// get current value
	var WshShell = new ActiveXObject("WScript.Shell");
	var ret = WshShell.run(ulogioEditCmd + "-1", 0, true);
	if ((ret < 0) || (ret > 7)) { 
		// check if valiad current value
		alert("Terminal Invalid Value: " + ret);
		ret = -1;
	}
	else if (ulogioMode != "-1") {
		ret = WshShell.run(ulogioEditCmd + ulogioMode, 0, true);
		if (ret < 0) {
			alert("Change terminal error: " + ret);
			ret = -1;
		}
	}

	delete WshShell;

	return ret;
}
