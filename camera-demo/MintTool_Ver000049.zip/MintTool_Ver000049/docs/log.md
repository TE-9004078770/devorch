# 「ログとりツール」で取れるログについて
## ファイルツリー
```
./log/
└── YYYY-MM-DD_HHMMSS_IPSX
    ├── AdjustData.bin
    ├── CP
    │   ├── blog.bin
    │   ├── Dmm_log.txt
    │   ├── escape_blog.bin
    │   ├── GetLog_uipc.txt
    │   ├── klog.txt
    │   ├── LensData.dat
    │   ├── Loader.log
    │   ├── snapshot_debug.sdmp
    │   ├── sus_blog.bin
    │   ├── sus_klog.txt
    │   ├── sus_tlog.bin
    │   ├── sus_tlog.txt
    │   ├── tlog.bin
    │   ├── tlog.txt
    │   ├── tmon.bin
    │   ├── tmon.txt
    │   ├── uipc_stat_kernel.txt
    │   └── VPHreg.bin
    ├── Dmm_log.txt
    ├── escapelog
    │   ├── cp
    │   ├── corefile.zip
    │   ├── ulogio_klog.txt
    │   ├── ulogio_tlog.txt
    │   ├── escapelog.bin
    │   └── ldr_escapelog.bin
    ├── FrontCon.log
    ├── FrontEsc.log
    ├── FrontIni.log
    ├── GetLog_bootlog.txt
    ├── GetLog_klog.txt
    ├── GetLog_uipc.txt
    ├── GetLog_ULOGIO.bin
    ├── Loader.log
    ├── SettingInfo.txt
    ├── ToolVersion.txt
    ├── uipc_stat_kernel.txt
    └── version.txt
```

`YYYY-MM-DD_HHMMSS_IPSX` には、取得時の日時が入ります。  

## 各ファイルの説明
### MP側のログ
* `AdjustData.bin` ：Backupデータ(eMMC上のBackup.bin)
* `Dmm_log.txt` ：DMMログ
* `FrontCon.log` ：Darwinのログ
* `FrontEsc.log` ：Frontコンのログ
* `FrontIni.log` ：Frontコンとの初期更新データ
* `GetLog_bootlog.txt` ：osal_timetagの出力結果
* `GetLog_Imola.bin` ：Codecのログ
* `GetLog_klog.txt` ：カーネルのログ出力
* `GetLog_uipc.txt` ：/proc/osal/uipcの結果
* `GetLog_ULOGIO.bin` ：osal_recordの出力
* `Loader.log` ：MP側Loaderのログ
* `SettingInfo.txt` ：量産設定・USB/SENSERモード設定状態
* `uipc_stat_kernel.txt` ：UIPC枯渇ログ（UIPC枯渇発生時）
* `escapelog/corefile.zip` ：Coredump情報
* `escapelog/escapelog.bin` ：リセット前の osal_recordの出力
* `escapelog/ldr_escapelog.bin` ：リセット前の osal_recordの出力　★量産設定時も残る
* `escapelog/ulogio_klog.txt` ：リセット前の カーネルのログ出力
* `escapelog/ulogio_tlog.txt` ：リセット前の osal_timetagの出力

### CP側のログ
* `CP/blog.bin` ：osal_recordの出力
* `CP/Dmm_log.txt` ：DMMログ
* `CP/escape_blog.bin` ：osal_recordの出力
* `GetLog_uipc.txt` ：UIPCログ
* `CP/klog.txt` ：kprintfの出力（CPのバージョン含む）
* `CP/LensData.dat` ：レンズデータ
* `CP/Loader.log` ：CP側Loaderのログ
* `CP/snapshot_debug.sdmp` ：スナップショットデバッグイメージ
* `CP/sus_blog.bin` ：電源OFF一個前のblog
* `CP/sus_klog.txt` ：電源OFF一個前のklog
* `CP/sus_tlog.bin` ：電源OFF一個前のtlog（バイナリ）
* `CP/sus_tlog.txt` ：電源OFF一個前のtlog（テキスト）
* `CP/tlog.bin` ：osal_timetagの出力結果（バイナリ）
* `CP/tlog.txt` ：osal_timetagの出力結果（テキスト）
* `CP/tmon.bin` ：Thread monitorログ（バイナリ）
* `CP/tmon.txt` ：Thread monitorログ（テキスト）
* `CP/uipc_stat_kernel.txt` ：UIPC枯渇ログ
* `CP/VPHreg.bin` ：VPHのレジスタ情報

### ツールのログ
* `SubMiconVersion.txt` ：マイコンのバージョン情報
* `ToolVersion.txt` ：MintToolのバージョン
* `version.txt` ：Firmwareのバージョン
