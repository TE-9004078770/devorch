# セットのバージョン情報取得

## 表記
### 年
例：191H→ `91`

### カテゴリ番号と名称

| 番号 | 名称 |
|---|---|
| `01` | `CAM` |
| `02` | `DSC` |
| `03` | `DSLR` |
| `04` | `CAM` |
| `05` | `VSS` |

## 使い方
### ファームウェアバージョンの読み込み
Backupに記録されたファームウェアバージョンを読み出します。  
```js
setVer.readFirmwareVer();
```
**【引数】**
なし

**【戻り値】**
* `true`：成功
* `false`：失敗

### defhd.datの読み込み
defhd.datの情報を読み出します。  
```js
setVer.readDefhd();
```
**【引数】**
なし

**【戻り値】**
* `true`：成功
* `false`：失敗

### ファームウェアバージョンの取得
```js
setVer.getFirmwareVer();
```
**【引数】**
なし

**【戻り値】**
* 成功時：`cyyaa_nn.YYYYmmddrr`  
	例：`39193_00.2020032601`
* 失敗時：空文字

### ファームウェアバージョンの共通部分のみ取得
ファームウェアバージョンから、マイナーバージョンと日付以下を抜いたものを取得します。  
```js
setVer.getFirmwareVerHead();
```
**【引数】**
なし

**【戻り値】**
* 成功時：`cyyaa`  
	例：`39193`
* 失敗時：空文字

### ユーザバージョンの取得
```js
setVer.getUsrVer();
```
**【引数】**
なし

**【戻り値】**
* 成功時：  
	```js
	{
		"major" : MAJOR,
		"minor" : MINOR
	}
	```
	* `MAJOR`：メジャーバージョン
	* `MINOR`：マイナーバージョン
* 失敗時：`null`

### 機種情報の取得
```js
setVer.getModelInfo();
```
**【引数】**
なし

**【戻り値】**
* 成功時：  
	```js
	{
		"year" : YEAR,
		"category" : CATEGORY,
		"major" : MAJOR,
		"minor" : MINOR
	}
	```
	* `YEAR`：年
	* `CATEGORY`：カテゴリー
	* `MAJOR`：メジャーバージョン
	* `MINOR`：マイナーバージョン
* 失敗時：`null`

### 機種情報の年部分の取得
```js
setVer.getModelInfoYear();
```
**【引数】**
なし

**【戻り値】**
* 成功時：年
* 失敗時：空文字

### 機種情報のカテゴリー部分の取得
```js
setVer.getModelInfoCategory();
```
**【引数】**
なし

**【戻り値】**
* 成功時：カテゴリー
* 失敗時：空文字

### 機種情報のカテゴリー名称の取得
```js
setVer.getModelInfoCategoryName();
```
**【引数】**
なし

**【戻り値】**
* 成功時：カテゴリー名称
* 失敗時：空文字

### 機種情報から作成したファームウェアバージョンの共通部分の取得
機種情報から得られるファームウェアバージョンから、マイナーバージョンと日付以下を抜いたものを取得します。  
```js
setVer.getModelInfoSetName();
```
**【引数】**
なし

**【戻り値】**
* 成功時：`cyyaa`  
	例：`39193`
* 失敗時：空文字

### 仕向け情報の取得
```js
setVer.getDestInfo();
```
**【引数】**
なし

**【戻り値】**
* 成功時：`AA.BB.CC.DD`  
* 失敗時：空文字

### カテゴリ番号の取得
レガシーコード向け  
内部的には、`setVer.readDefhd()`と`setVer.getModelInfoCategory()`の組み合わせ。  
```js
GetCategoryNum();
```
**【引数】**
なし

**【戻り値】**
* 成功時：カテゴリ番号  
* 失敗時：`00`

### カテゴリ名の取得
レガシーコード向け  
内部的には、`setVer.readDefhd()`と`setVer.getModelInfoCategoryName()`の組み合わせ。  
```js
GetCategoryName();
```
**【引数】**
なし

**【戻り値】**
* 成功時：カテゴリ名称  
* 失敗時：`Unknown`

### ファームウェアバージョンの共通部分の取得
レガシーコード向け  
内部的には、`setVer.readFirmwareVer()`と`setVer.getFirmwareVerHead()`の組み合わせ。  
```js
GetHeadVersion();
```
**【引数】**
なし

**【戻り値】**
* 成功時：ファームウェアバージョンの共通部  
* 失敗時：空文字
