## 使い方

### 接続する
```js
Connect();
```
セットに接続します。  
入れ子で呼んでも問題ありません。  

**【戻り値】**
* `true`：成功
* `false`：失敗

### 切断する
```js
Disconnect();
```
セットから切断します。  
入れ子で呼んだ場合、 `Connect()` と同じ回数呼ばれた段階で、切断処理を行います。  

**【戻り値】**
* `true`：成功

### 接続中を確認する
```js
IsConnected();
```
**【戻り値】**
* `true`：接続中
* `false`：未接続

### Adjust Controlコマンド
```js
AdjustCmd.xxx();
```

### File Control
```js
FileCtl.xxx();
```

### Firmup Control
```js
FirmUpCtl.xxx();
```

### Memory Dump
```js
MemDump.xxx();
```
