# セットの設定情報取得

## 設定情報
* SENSERモード
	* 通常
	* 強制USB
* 退避ログモード
	* ON
	* OFF
* 緊急再起動モード
	* ON
	* OFF
* UARTモード
	* CPのみ
	* MPのみ
	* CP + MP
	* OFF

## 使い方
### 設定情報を読み込む
```js
settingInfo.read();
```
**【引数】**
なし

**【戻り値】**
* `true`：成功  
	但し、個別の情報一つ一つが失敗した場合はログ出力のみ。
* `false`：接続失敗

### SENSERモードを文字列で取得
```js
settingInfo.getSenserModeStr();
```
**【引数】**
なし

**【戻り値】**
* `NORMAL`：通常
* `Force USB`：強制USB
* `Error!!`：エラー

### 退避ログモードを文字列で取得
```js
settingInfo.getEscapeLogModeStr();
```
**【引数】**
なし

**【戻り値】**
* `OFF`：OFF
* `ON`：ON
* `Error!!`：エラー

### 緊急再起動モードを文字列で取得
```js
settingInfo.getExceptionRebootModeStr();
```
**【引数】**
なし

**【戻り値】**
* `Exception Reboot OFF`：OFF
* `Exception Reboot ON`：ON
* `Error!!`：エラー

### UARTモードを文字列で取得
```js
settingInfo.getUARTModeStr();
```
**【引数】**
なし

**【戻り値】**
* `MP+CP`：MP + CP
* `CP ON`：CPのみ
* `MP ON`：MPのみ
* `OFF`：OFF
* `Error!!`：エラー
