# 設定ファイルについて
設定ファイル `settings.json` はJSON形式で記載されています。  

## 設定一覧
* `lang` ：表示言語設定
	* `ja` ：日本語
	* `en` ：英語
* `console` ：コンソール出力の制御
	* `0` ：コンソール非表示、メッセージ出力なし
	* `1` ：criticalのみ
	* `2` ： `1` + alert
	* `3` ： `2` + error
	* `4` ： `3` + warning
	* `5` ： `4` + info
	* `6` ： `5` + debug
* `firmSrc` ：ファームウェアの選択先のチェック
	* `local` ：ローカル
	* `rts` ：RTS
* `firmKeep` ：RTSファームの保持をするか否かのチェック
	* `true` ：保持する
	* `false` ：保持しない
* `packLogZip` ：ログ取得時にZIP化するか否かのチェック
	* `true` ：ZIP化する
	* `false` ：ZIP化しない

## APIの使い方
### ファイル読み込み
```js
settings.read();
```
設定ファイルを読み込みます。  
起動時には自動的に読み込みが走ります。  

### ファイル書き出し
```js
settings.write();
```
設定ファイルに書き出します。  

### 設定値の取得
```js
settings.get(KEY);
```
* `KEY`：設定値のキー

### 設定値の設定
```js
settings.set(KEY, VALUE);
```
* `KEY`：設定値のキー
* `VALUE`：設定値

### HTML要素指定による設定値の設定
```js
settings.setByElm(KEY, ELEMENT);
```
* `KEY`：設定値のキー
* `VALUE`：HTML要素Object

### HTML要素に対する設定値の反映
```js
settings.setToElm(KEY, ELEMENT);
```
* `KEY`：設定値のキー
* `VALUE`：HTML要素Object

### HTML要素と設定値の紐づけ
```js
settings.linkElmToKey(KEY, ELEMENT);
```
* `KEY`：設定値のキー
* `VALUE`：HTML要素Object
