# Consoleについて
## 表示レベル
設定した表示レベル以下のメッセージのみを出力します。  
1. Critical： `mintole.LEVEL.critical`
1. Alert： `mintole.LEVEL.alert`
1. Error： `mintole.LEVEL.error`
1. Warning： `mintole.LEVEL.warning`
1. Info： `mintole.LEVEL.info`
1. debug： `mintole.LEVEL.debug`

## API一覧
### コンソールを開く
表示レベルは `info` に設定されます。  
```js
mintole.open();
```
**【引数】**
なし

**【戻り値】**
なし

### コンソールを閉じる
```js
mintole.close();
```
**【引数】**
なし

**【戻り値】**
なし

### 表示レベルを設定する
設定ファイルの表示レベルも変更されます。  
```js
mintole.setLevel(level);
```
**【引数】**
* 表示レベル

**【戻り値】**
なし

### 表示レベルを取得する
```js
mintole.getLevel();
```
**【引数】**
なし

**【戻り値】**
* 現在の表示レベル

### 表示レベルを保存する
```js
mintole.saveLevel();
```
**【引数】**
なし

**【戻り値】**
なし

### レベル毎の書き込み
`alert` のみ、alert時のポップアップを有効であれば、表示レベルに関係なくプロンプトによるメッセージ表示も行います。  
```js
mintole.debug(msg);
mintole.info(msg);
mintole.warning(msg);
mintole.error(msg);
mintole.alert(msg[, popup]);
mintole.critical(msg);
```
**【引数】**
* `msg`：メッセージ
* `popup`：ポップアップするか否か（`false`：しない、省略時はする）

**【戻り値】**
なし

### レベル関係なしのRAWな書き込み
```js
mintole.write(msg);
```
**【引数】**
* メッセージ

**【戻り値】**
なし
