# Mint Tool
## How to Use
1. executing "regist.bat" in the folder that installed AresDdm  
　　*Please execute "regist.bat" as administrator.  
　　*If you executed "regist.bat" once after installing AresDdm, you don't have to re-execute it.  
1. Execute on DiademMintTool.hta  
1. Execute disable_ie_warning.reg  
	**if you're bothered by the caution, `Do you want to abort the script?`, in IE.**

## Usable System
IPS-X

## About Add-on
### How to use add-on
1. Set external script by "Brows" button.
1. Edit "Title" and "Memo".
1. Select "Exec" button in connecting with SET.

**※Attention  
If you don't execute the script setting as add-on, Title, File and Memo which set as add-on is not saved.**

### Attention for makeing add-on
When add-on is exexuted, current directory is MintTool's one. Please attend in specifing a relative path.

## History
| Version | Date | Update |
|---|---|---|
| 00.00.49 | 2023/01/18 | * Added processing to display an error dialog when a command using SENSER IF is issued with SENSER IF disabled.<br>|
| 00.00.48 | 2022/11/06 | * [re-request] DFE:LOKI mounted Model's behavior is changed.(Cetus PG->DFE:LOKI PG) #DFE:LOKI non-mounted Model's behavior is not changed.<br>|
| 00.00.47 | 2022/11/04 | * DFE:LOKI mounted Model's behavior is changed.(Cetus PG->DFE:LOKI PG) #DFE:LOKI non-mounted Model's behavior is not changed.<br> * Zynq log Support.<br>|
| 00.00.46 | 2022/10/21 | * Prohibit response across signatures such as unsigned → signed signed → unsigned<br>|
| 00.00.45 | 2022/10/14 | * Zynq log Support.<br>|
| 00.00.44 | 2022/09/22 | * [SubMicon → Darwin Mecha Setting] Added shutter type settings.<br> * 1/4000 less-1C eshutter<br> * 1/8000 less-1C hybrid shutter<br> * Blackout curtain<br>|
| 00.00.43 | 2022/07/28 | * add UIBiz tab |
| 00.00.42 | 2022/06/30 | * Fix GetLog operation, try with AdjustControl(0x060f, 0x0001) on RC/GM. |
| 00.00.41 | 2022/06/02 | * Fix SSBI operation, retry with AdjustControl(0x0601,0x0031/0x0032) on FileControl failure |
| 00.00.40 | 2022/06/01 | * Delete Operation Environment |
| 00.00.39 | 2022/02/24 | * Fix BACKUP AdjustCodes for INTERCHIP 0x8040-0x8042 whose security attribute are not limited for developers; they shall be 0x0040-0x0042. |
| 00.00.38 | 2021/10/07 | * Call AdjCmd to suspend/resume log recording on reading Thread Monitor Log (CP) in Debug1 tab (continue reading even if the AdjCmd fails). |
| 00.00.37 | 2021/07/07 | * Fix bug which all GetLog options are ON, if their settings doesn't exist in setting file |
| 00.00.36 | 2021/06/15 | * Fix bug which cannot display caution when firmware for different setname from current firmware<br>* Fix bug which cannot firmup with firmware including space in filename<br>* Add logging selection on GetLog<br>* Refactoring Backup read/write<br>* Refactoring Memory Dump<br>* Refactoring for reading data of Backup/Mario/Defdet |
| 00.00.35 | 2021/05/21 | * Enabled the setting for the "Deadlock monitoring" setting on the Debug 1 tab.|
| 00.00.34 | 2021/04/20 | * Fix bug popping-up debug console when fail to get tomco.txt<br>* Fix bug generating incorrect SSDI binary by using button on getting log form |
| 00.00.33 | 2021/03/19 | * Fixed to be able to get PictureReport log at the same time when getting Codec log |
| 00.00.32 | 2020/12/22 | * Fix indication in English<br>* Fix bug which cannot create SSBI |
| 00.00.31 | 2020/12/03 | * Fix bug which cannot update firmware |
| 00.00.30 | 2020/11/26 | * Add setting menu that SSDI creation by Reset<br>* Add getting SSDI option in getting log<br>* Fix bug which cannot get Snapshotboot Image<br>* Change implementation of page transition<br>* Optimize connect process |
| 00.00.29 | 2020/11/26 | * Get Model Date <br>・Get BLOG INFO |
| 00.00.28 | 2020/06/30 | * Fix zero-fill process<br>* Reduce error pop-up when error occurred in getting Thread monitor log<br>* Add Camera-EC modification<br>* Refactoring in getting log<br>* Modify design of getting log & read/write backup |
| 00.00.27 | 2020/06/08 | * Revise Connect / Diconnect process |
| 00.00.26 | 2020/05/19 | * Add error check to text conversion of Boottime log & Thread monitor<br>* Add error check to getting version information<br>* Change order of getting log |
| 00.00.25 | 2020/03/25 | * Fix bug which appears runtime error on error screen of updating firmware for Sys-kaku which is different set<br>* Fix lack of changing language<br>* Support saving&restoring firmware update settings<br>* Suppress pop-up at getting log<br>* Support changing language on error screen of updating firmware for Sys-kaku which is different set<br>* Fix design broken in a part of environments<br>* Support packing log as a ZIP option |
| 00.00.24 | 2020/03/17 | * Change error message at Thread monitor/tlog binary convertion to prompt<br>* Move files & adding error message etc. |
| 00.00.23 | 2020/03/05 | * Support firmware on RTS when update<br>* Add progress bar while firmware updating<br>* Refactoring in firmwrae update<br>* Refactoring around setting language<br>* Add error avoidance at Thread monitor translation with character corruption |
| 00.00.22 | 2020/02/19 | * Add deleting Snapshot Debug Image |
| 00.00.21 | 2020/02/12 | * add macro to write backup for main destination with SENSER |
| 00.00.19 | 2020/01/16 | * tlog/Thread monitor log of CP Convert to text<br>* delete tmp file when the process to get snapshot debug image failed |
| 00.00.18 | 2020/01/14 | * Support getting Snapshot debug (handling of core dump for SOLID) image |
| 00.00.17 | 2019/12/20 | * coredump ON/OFF bugfix |
| 00.00.16 | 2019/12/13 | * Title Add "Defdet Data" to Mint Tool<br>* Button "UART INPUT ENABLE" added |
| 00.00.15 | 2019/10/10 | * misdescription modified ('*UDG-1003' --> 'DBG-1003') |
| 00.00.14 | 2019/10/09 | * cp sus_log size reduction<br>* modify the escape-log of Darwin |
| 00.00.13 | 2019/09/20 | * Rough handling for the outside of IPSX added<br>* Parameters for threadmonitor (threadmonitor_addressNum and threadmonitor_sizeNum) updated |
| 00.00.12 | 2019/09/04 | * To get log of CP in suspend(klog, blog, tlog) |
| 00.00.11 | 2019/08/29 | * UART ON/OFF<br>* escapelog delete<br>* coredump |
| 00.00.10 | 2019/08/23 | * Chip support added when reading Backup |
| 00.00.09 | 2019/07/31 | * Darwin version extension (IPS-X) |
| 00.00.08 | 2019/07/12 | * Support CP ThreadMonitor log<br>* Support UART ON/OFF<br>* Support Exception Reboot ON/OFF |
| 00.00.07 | 2019/07/11 | * Darwin log |
| 00.00.06 | 2019/05/27 | * PG ON/OFF<br>* Loader log  |
| 00.00.05 | 2019/05/22 | * CP OSAL log  |
| 00.00.04 | 2019/04/26 | * VPH register dump |
| 00.00.03 | 2019/03/29 | * CP log |
| 00.00.02 | 2019/03/08 | * escape log |
| 00.00.01 | 2019/02/28 | * First release |

## Contact
SCM Team(dig-diad-scm@jp.sony.com)
